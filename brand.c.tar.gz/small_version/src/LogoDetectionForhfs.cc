// Copyright 2016
// #include "include/logo_detection_merge.h"
#include "include/logo_detection_localini.h"
#include "include/Utility.h"
#include "include/LogoDetectionForhfs.h"
#include "include/function.h"

#include "rapidjson/document.h"
#include "rapidjson/writer.h"
#include "rapidjson/stringbuffer.h"
using rapidjson::Document;
using rapidjson::StringBuffer;
using rapidjson::Writer;
using rapidjson::Value;
using rapidjson::kArrayType;
using rapidjson::kObjectType;

using std::cout;
using std::endl;
// RestClient LogoDetectionForhfs::restclient_;
using cv::imread;
using cv::imdecode;

// static _SIMPLE_LOGGER_INIT_V1 _simple_logger_init_V1("stdout");
LogoDetectionForhfs::LogoDetectionForhfs() {
  flag_initial_ = 1;
  flag_setup_ = 1;
  impl_ = shared_ptr<LogoDetectionIniFromLocal>(new LogoDetectionIniFromLocal);
  // algodate_ = impl_->algodate_;
  // restclient_.initialize("restful-store.vip.tbsite.net:3800",
  // "52413f88bcefe");
  // restclient_.set_request_timeout(1);
}

LogoDetectionForhfs::~LogoDetectionForhfs() {
}

Mat ReadFromLocal(string imgloc) {
  Mat logo = imread(imgloc, CV_LOAD_IMAGE_COLOR);
  return logo;
}
/*
Mat ReadFromTfs(string tfs) {
    
    const int64_t BUFFER_SIZE = 10000000;
    static vector<unsigned char> buf(BUFFER_SIZE);
    int64_t ret_count = 0;
    int ret = LogoDetectionForhfs::restclient_.fetch_buf(
        ret_count, reinterpret_cast<char*>(&buf[0]), BUFFER_SIZE, tfs.c_str());
    if (ret != 0) {
        cout <<"fail to read tfs " + tfs<<endl;
        return Mat();
    }
    Mat logo = imdecode(buf, CV_LOAD_IMAGE_UNCHANGED);
    return logo;
}*/
int LogoDetectionForhfs::SetAlgoVersion(string algoversion) {
  impl_->algodate_ = algoversion;
  return 0;
}

string LogoDetectionForhfs::GetAlgoVersion() {
  return impl_->algodate_;
}

int LogoDetectionForhfs::InitialFromConfFile(
    string logoconffiledir,
    string imgdir) {
  int setupflag = impl_->InitialFromLocalFilecont(logoconffiledir);
  impl_->algodate_ = impl_-> last_version_;
  SIMPLE_LOG_V1("Setupflag: %d", setupflag);
  SIMPLE_LOG_V1("algodate_: %s", impl_->algodate_.c_str());
  flag_initial_ = setupflag;
  flag_setup_ = setupflag;
  return setupflag;
}

int LogoDetectionForhfs::InitialFromConfFileSlow(
    string logoconffiledir,
    string imgdir) {
  confinfo.clear();
  flag_setup_ = 1;
  flag_initial_ = 1;
  string delim = "";
  confinfo = ReadConfFile(logoconffiledir, delim);
  if (confinfo.size() == 0) {
    SIMPLE_LOG_V1("Error: %s have no file.", logoconffiledir.c_str());
    flag_initial_ = 2;
    return 1;
  }
  for (int i = 0 ; i < static_cast<int>(confinfo.size()); i++) {
    string imgpath = imgdir + confinfo[i][3];
    string tfs =  confinfo[i][3];
    // cout<<"imgpath: "<<imgpath<<endl;
    /*const int64_t BUFFER_SIZE = 10000000;
    static vector<unsigned char> buf(BUFFER_SIZE);
    int64_t ret_count = 0;
    int ret = restclient_.fetch_buf(
        ret_count, reinterpret_cast<char*>(&buf[0]), BUFFER_SIZE, tfs.c_str());
    if (ret != 0) {
        cout <<"fail to read tfs " + tfs<<endl;
        continue;
    }
    Mat logo = imdecode(buf, CV_LOAD_IMAGE_UNCHANGED);*/
    // Mat logo = ReadFromTfs(tfs)
    Mat logo = imread(imgpath, CV_LOAD_IMAGE_COLOR);
    string logo_index = confinfo[i][0];
    cout << "logo_index: " << logo_index << endl;
    string logo_name = confinfo[i][6];
    cout << "logo_name: " << logo_name << endl;
    string brand_name = confinfo[i][4];
    cout << "brand_name: " << brand_name << endl;
    string brand_id = confinfo[i][5];
    cout << "brand_id: " << brand_id << endl;
    string corr_thresh = confinfo[i][7];
    cout << " corr_thresh: " << corr_thresh << endl;
    // string neg_corr_thresh = confinfo[i][7];
    string cover_ratio_thresh = confinfo[i][8];
    cout << "cover_ratio_thresh: " << cover_ratio_thresh << endl;
    double dcorr_thresh = Str2Num(corr_thresh);
    // double dneg_corr_thresh = Str2Num(neg_corr_thresh);
    double dcover_ratio_thresh = Str2Num(cover_ratio_thresh);

    impl_->InitialFromString(logo, logo_name, brand_name,
    brand_id, logo_index, dcorr_thresh, dcover_ratio_thresh);
  }
  flag_initial_ = 0;
  return 0;
}

string LogoDetectionForhfs::LogoDet(const vector<unsigned char> &buf) {
  if (flag_initial_ != 0) {
    return string("{\"exception\": \"InitialError\"}");
  }
  if (flag_initial_ == 2) {
    return string("{\"exception\": \"InitialErrorNoConffile\"}");
  }
  if (flag_setup_ != 0) {
    return string("{\"exception\": \"SetupError\"}");
  }
  string strres;

  Document document;
  document.SetObject();
  Document::AllocatorType& allocator = document.GetAllocator();
  Value ret(kObjectType);

  try {
    Mat queryimg = imdecode(buf, CV_LOAD_IMAGE_UNCHANGED);
    SIMPLE_LOG_V1("buf size: %d", static_cast<int>(buf.size()));
    SIMPLE_LOG_V1("Process start!");
    vector<LogoDetResult> multiredet = impl_->RunDet(queryimg);
    SIMPLE_LOG_V1("Process done!");
    strres = impl_->LogoRst2Json(multiredet, queryimg);
  } catch (...) {
    SIMPLE_LOG_V1("Process exception!\n");
    Value exception(kArrayType);
    Value logoinfo(kObjectType);
    Value emptyresult(kArrayType);

    string hfsmsg = string("HSF Process exception");
    // exception.PushBack(Value(hfsmsg.c_str(), allocator).Move(), allocator);

    ret.AddMember("exception", Value(hfsmsg.c_str(),
      allocator).Move(), allocator);
    ret.AddMember("algodate", Value(impl_->algodate_.c_str(),
      allocator).Move(), allocator);

    StringBuffer buffer;
    Writer<StringBuffer> writer(buffer);
    ret.Accept(writer);
    strres = buffer.GetString();
  }
  return strres;
}

int LogoDetectionForhfs::Setup() {
  if (flag_initial_ == 0) {
    SIMPLE_LOG_V1("No LogoConf initial");
    return 1;
  }
  if (flag_setup_ == 0) {
    SIMPLE_LOG_V1("LogoConf is already setup...");
    return 1;
  }
  if (impl_->Setup() == 1) {
    flag_setup_ = 0;
    return 0;
  }
  SIMPLE_LOG_V1("Setup Fail")
  return 1;
}
