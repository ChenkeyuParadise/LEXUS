// Copyright 2016
#include<time.h>
#include <stdio.h>

#include <iostream>
#include <fstream>
#include <vector>

#include "include/logo_detection.h"
#include "include/function.h"
#include "include/Utility.h"
#include "include/MatrixIO.h"

#include "include/LogoDetectionForhfs.h"
#include "include/logo_detection_localini.h"

#define eps 2.2204e-16
// #include "profiler.h"
using std::string;
// 用于DEBUG读写字符串和矩阵的功能 历史文件予以保留
int main(int argc, char* argv[]) {
    if (argc != 1) {
        cout << "Usage: " << argv[0]
            << " conf_path" << endl;
        return -1;
    }
    // string conf_path = argv[1];
    // string img_dir_path = argv[2];
    // string cached_conf_path = argv[3];
    // string cache_feature_path = argv[4];
    // clock_t start;
    string strdir = "/disk/tiezheng.gtz/ImageData/logo/pos/newbalance0/";
    string strfilelist = "/disk/keyu.cky/ImageRepresentation/"
        "logo_detection_algo_explore/newbalancelist.txt";

    string outputfile = "test_readwrite.bin";
    FILE *filewrite = fopen(outputfile.c_str(), "wb");
    string msg = "My Name is Sky  haha 柯宇";
    cout << msg << endl;
    cout << msg.size() << endl;
    WriteStringBincont(filewrite, msg);
    WriteStringBincont(filewrite, string("Next 2 is my wrong!"));
    fclose(filewrite);
    FILE *fileread = fopen(outputfile.c_str(), "rb");
    string inmsg;
    ReadStringBincont(fileread, &inmsg);
    cout << inmsg << endl;
    cout << inmsg.size() << endl;
    ReadStringBincont(fileread, &inmsg);
    cout << inmsg << endl;
    cout << inmsg.size() << endl;

    fclose(fileread);
    return -1;
}

