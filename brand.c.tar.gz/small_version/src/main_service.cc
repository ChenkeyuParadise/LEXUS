// Copyright 2016
#include <stdio.h>
#include<time.h>

#include <iostream>
#include <fstream>
#include <vector>
#include "rapidjson/document.h"

#include "include/function.h"
#include "include/Utility.h"
#include "include/logo_detection.h"
#include "include/logo_detection_localini.h"
#include "include/LogoDetectionForhfs.h"

#define eps 2.2204e-16
// #include "gperftools/profiler.h"
using std::string;
using std::filebuf;
using cv::Point;

int main(int argc, char* argv[]) {
    if (argc != 4) {
        cout << "Usage: " << argv[0]
          << " conf_path"
          << " query_img_path"
          << " query_img_file_list" << endl;
        return -1;
    }
    string conf_path = argv[1];
    string query_img_path = argv[2];
    string query_img_file_list = argv[3];

    clock_t start;
    start = clock();
    // double totaltime;
    //  string strdir = "/disk/tiezheng.gtz/ImageData/logo/pos/newbalance0/";
    //  string strdir = "/home/zhongjun.wzj/project/new_logo/"
    //    "logo_detection_c/pos/newbalance0/";
    // string strdir = "./v3_union_v2_minus_v2/";
    // string strdir = "/home/xilou.zy/logo_detection_testset/query_img/";
    //  string strfilelist = "/disk/keyu.cky/ImageRepresentation/"
    //  "logo_detection_algo_explore/newbalancelist.txt";
    //  string strfilelist = "/home/zhongjun.wzj/project/new_logo/"
    //  "logo_detection_c/probe_txt/newbalance0.txt";
    string strdir = query_img_path;
    // string strfilelist = "/home/xilou.zy/logo_detection_testset/query_set1";
    string strfilelist = query_img_file_list;
    vector<string> vecfilelist;
    GetFileList(strfilelist, &vecfilelist);
    for (int i_cnt=0;
         i_cnt < static_cast<int>(vecfilelist.size()); i_cnt++) {
      cout << vecfilelist[i_cnt] << endl;
    }
    LogoDetectionForhfs test;

    // string strname = "logo_conf_file.txt";
    //  string strname = "brand_v1-v12_conf.bin";
    //  string strname = "v1-v10_NEWBALANCE.bin";
    //  string strdirin = "brand_img_model/";
    // string strdirin = "/home/zhongjun.wzj/project/new_logo/"
    //  "logo_detection_c/gallery744/";
    string strdirin = "";
    test.InitialFromConfFile(conf_path, strdirin);
    test.Setup();
    clock_t Setuptime = clock() - start;
    cout << "Setup时间为"
      << static_cast<double>(Setuptime)/CLOCKS_PER_SEC << endl;
    start = clock();
    string algo_version = test.GetAlgoVersion();
    cout << "algo_version:"
      << algo_version << endl;
    // string inpudir = "/disk/tiezheng.gtz/ImageData/logo/pos/";
    // inpudir = "/home/keyu.cky/svn_project/logo_det/"
    //  "logo_detection_daily_ex_Cversion/logo_cversion/";
    string inputtest;
    cout << "flat1" << endl;
    int imgcnt = 0;
    int havelogocnt = 0;
    // ProfilerStart("CPUProfile");
    int start_run = clock();
    cout << "flag2" << endl;
    cout << "vecfilelist: " << vecfilelist[0] << endl;
    for (int i_cnt=0;
         i_cnt <  static_cast<int>(vecfilelist.size());
         i_cnt += 1) {
      printf("---------------i_cnt = %d----------------\n", i_cnt);
      test.impl_->input_test_ = vecfilelist[i_cnt];
      test.impl_->cur_query_cnt_ = i_cnt;
      inputtest = strdir + vecfilelist[i_cnt];
  //    inputtest = strdir +
  //    "BAPE_TB1n1ztKVXXXXaaXVXXXXXXXXXX_!!0-item_pic.jpg";
      cout << inputtest << endl;
      std::filebuf *pbuf;
      std::ifstream filestr;
      char *buffer;
      int64 size;

      filestr.open(inputtest.c_str(), std::ios::binary);
      if (filestr == NULL) {
        cout<< "不存在文件" << endl;
        return -1;
      }
      pbuf = filestr.rdbuf();
      size = pbuf->pubseekoff(0, std::ios::end, std::ios::in);
      cout << "size is " << size << endl;
      pbuf->pubseekpos(0, std::ios::in);

      buffer = new char[size];
      pbuf->sgetn(buffer, size);
      filestr.close();
      Mat imgtest = cv::imread(inputtest);
      // ProfilerStart("CPUProfile");
      vector<unsigned char> imgbuffer(size);
      std::copy((const unsigned char *)buffer,
        (const unsigned char *)buffer + size, imgbuffer.begin());
      cout << imgbuffer.size() <<endl;
      delete buffer;
      string redet = test.LogoDet(imgbuffer);
      rapidjson::Document confdoc;
      confdoc.Parse(redet.c_str());
      if (confdoc.HasParseError()) {
        cout << "Error in conf file parse" << endl;
      }
      rapidjson::Value::ConstMemberIterator itr =
        confdoc.FindMember("results");
      rapidjson::Value results;
      if (itr != confdoc.MemberEnd() && itr->value.IsArray()) {
        // results = itr->value.GetObject();
        results = confdoc["results"];
      } else {
        continue;
      }
      cout << "rapidjson parse" << endl;
      // cout <<"test:"<<results[0]["loc"][0].GetInt()<<endl;
      cv::Point rook_points[1][4];
      if (results.Size() > 0) {
        havelogocnt++;
      }
      for (int logo_cnt=0;
           logo_cnt < static_cast<int>(results.Size());
           logo_cnt++) {
        rook_points[0][0] = Point(results[logo_cnt]["loc"][0].GetInt(),
          results[logo_cnt]["loc"][1].GetInt());
        rook_points[0][1] = Point(results[logo_cnt]["loc"][2].GetInt(),
          results[logo_cnt]["loc"][3].GetInt());
        rook_points[0][2] = Point(results[logo_cnt]["loc"][4].GetInt(),
          results[logo_cnt]["loc"][5].GetInt());
        rook_points[0][3] = Point(results[logo_cnt]["loc"][6].GetInt(),
          results[logo_cnt]["loc"][7].GetInt());
        const Point* ppt[1] = { rook_points[0] };
        int npt[] = {4};
        polylines(imgtest, ppt, npt, 1, 1, CV_RGB(0, 255, 0), 2, 8, 0);
      }
      if (results.Size() > 0) {
        int iidx = inputtest.find_first_of("0", 0);
        cout << "debug: " << inputtest.substr(iidx + 1) << endl;
      //  imwrite("prelocate_img_line1/test" + Num2Str(i_cnt) + "_got_"
      //          + inputtest.substr(iidx + 2),
      //          imgtest);
      } else {
      //  imwrite("results_missed_recall/test" + Num2Str(i_cnt) + "_"
      //          + inputtest.substr(12),
      //        imgtest);
      }
      cout << "Logo Det Result: " << redet << endl;
      // ProfilerStop();
      imgcnt++;
    }

    int64 end_run = clock();
    cout << "运行时间为:"
      << static_cast<double>(end_run-start_run)/CLOCKS_PER_SEC
      << "s" << endl;
    cout << "havelogocnt:" << havelogocnt << endl;
    cout << "imgcnt:" << imgcnt << endl;
    cout << "Recall:" << static_cast<double>(havelogocnt)/imgcnt << endl;
    return 0;
}

