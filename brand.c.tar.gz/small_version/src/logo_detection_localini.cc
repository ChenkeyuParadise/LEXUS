// Copyright 2016
#include <unistd.h>
#include<fstream>

#include "include/logo_detection_localini.h"
#include "include/MatrixIO.h"
#include "include/function.h"
#include "include/Utility.h"

#include "rapidjson/document.h"
#include "rapidjson/writer.h"
#include "rapidjson/stringbuffer.h"

using rapidjson::Document;
using rapidjson::StringBuffer;
using rapidjson::Writer;
using rapidjson::Value;
using rapidjson::kArrayType;
using rapidjson::kObjectType;


LogoDetectionIniFromLocal::LogoDetectionIniFromLocal() {
}

LogoDetectionIniFromLocal::~LogoDetectionIniFromLocal() {
}

int LogoDetectionIniFromLocal::ReadFromLocal(string confdir, Mat *inputmat) {
  if (ReadMatrixBin(confdir, inputmat)) {
    return 1;
  }
  return 0;
}

int LogoDetectionIniFromLocal::WriteToLocal(
    string confdir, const Mat &outputmat) {
  if (WriteMatrixBin(confdir, outputmat)) {
    return 1;
  }
  return 0;
}
/*
 
 */
int LogoDetectionIniFromLocal::ReadFeature(
    string confdir, vector<KeyPoint> *inputkeypointvector) {
  Mat inputfeature;
  float x, y, size, angle, response, octave, class_id;
  if (ReadFromLocal(confdir, &inputfeature) == 1) {
    if (inputfeature.cols == 7) {
      for (int i_cnt = 0; i_cnt < inputfeature.rows; i_cnt++) {
        x = inputfeature.ptr<float>(i_cnt)[0];
        y = inputfeature.ptr<float>(i_cnt)[1];
        size = inputfeature.ptr<float>(i_cnt)[2];
        angle = inputfeature.ptr<float>(i_cnt)[3];
        response = inputfeature.ptr<float>(i_cnt)[4];
        octave = inputfeature.ptr<float>(i_cnt)[5];
        class_id = inputfeature.ptr<float>(i_cnt)[6];
        (*inputkeypointvector).push_back(
            KeyPoint(x, y, size, angle, response, octave, class_id));
      }
      return 1;
    } else {
      SIMPLE_LOG_V1("SIFT feature cols must be 7");
      return 0;
    }
  }
  return 1;
}

int LogoDetectionIniFromLocal::WriteFeature(
    string confdir,
    const vector<KeyPoint> &outputkeypoint) {
  Mat outputfeature = Mat::zeros(Size(7, outputkeypoint.size()), CV_32F);
  for (int i_cnt = 0; i_cnt < outputfeature.rows; i_cnt++) {
    outputfeature.ptr<float>(i_cnt)[0] = outputkeypoint[i_cnt].pt.x;
    outputfeature.ptr<float>(i_cnt)[1] = outputkeypoint[i_cnt].pt.y;
    outputfeature.ptr<float>(i_cnt)[2] = outputkeypoint[i_cnt].size;
    outputfeature.ptr<float>(i_cnt)[3] = outputkeypoint[i_cnt].angle;
    outputfeature.ptr<float>(i_cnt)[4] = outputkeypoint[i_cnt].response;
    outputfeature.ptr<float>(i_cnt)[5] = outputkeypoint[i_cnt].octave;
    outputfeature.ptr<float>(i_cnt)[6] = outputkeypoint[i_cnt].class_id;
  }
  if (WriteToLocal(confdir, outputfeature) == 1) {
    return 1;
  }
  return 0;
}

int LogoDetectionIniFromLocal::ReadDescription(
    string confdir,
    Mat *inputdescription) {
  if (ReadFromLocal(confdir, inputdescription) == 1) {
    return 1;
  }
  return 0;
}

int LogoDetectionIniFromLocal::WriteDescription(
    string confdir,
    const Mat &outputdescription) {
  if (WriteToLocal(confdir, outputdescription) == 1) {
    return 1;
  }
  return 0;
}

int LogoDetectionIniFromLocal::ReadFromLocalcont(
    FILE *infile,
    Mat *inputmat) {
  if (ReadMatrixBincont(infile, inputmat)) {
    return 1;
  }
  return 0;
}

int LogoDetectionIniFromLocal::WriteToLocalcont(
    FILE *outfile,
    const Mat &outputmat) {
  if (WriteMatrixBincont(outfile, outputmat)) {
    return 1;
  }
  return 0;
}

int LogoDetectionIniFromLocal::ReadFeaturecont(
    FILE *infile,
    vector<KeyPoint> *inputkeypointvector) {
  Mat inputfeature;
  float x, y, size, angle, response, octave, class_id;
  if (ReadFromLocalcont(infile, &inputfeature) == 1) {
    if (inputfeature.cols == 7) {
      for (int i_cnt=0; i_cnt < inputfeature.rows; i_cnt++) {
        x = inputfeature.ptr<float>(i_cnt)[0];
        y = inputfeature.ptr<float>(i_cnt)[1];
        size = inputfeature.ptr<float>(i_cnt)[2];
        angle = inputfeature.ptr<float>(i_cnt)[3];
        response = inputfeature.ptr<float>(i_cnt)[4];
        octave = inputfeature.ptr<float>(i_cnt)[5];
        class_id = inputfeature.ptr<float>(i_cnt)[6];
        (*inputkeypointvector).push_back(KeyPoint(x, y, size, angle,
            response, octave, class_id));
      }
      return 1;
    } else {
      SIMPLE_LOG_V1("Feature cols must be 7");
      return 0;
    }
  }
  return 1;
}

int LogoDetectionIniFromLocal::WriteFeaturecont(
    FILE *outfile,
    const vector<KeyPoint> &outputkeypoint) {
  Mat outputfeature = Mat::zeros(Size(7, outputkeypoint.size()), CV_32F);
  for (int i_cnt = 0; i_cnt < outputfeature.rows; i_cnt++) {
    outputfeature.ptr<float>(i_cnt)[0] = outputkeypoint[i_cnt].pt.x;
    outputfeature.ptr<float>(i_cnt)[1] = outputkeypoint[i_cnt].pt.y;
    outputfeature.ptr<float>(i_cnt)[2] = outputkeypoint[i_cnt].size;
    outputfeature.ptr<float>(i_cnt)[3] = outputkeypoint[i_cnt].angle;
    outputfeature.ptr<float>(i_cnt)[4] = outputkeypoint[i_cnt].response;
    outputfeature.ptr<float>(i_cnt)[5] = outputkeypoint[i_cnt].octave;
    outputfeature.ptr<float>(i_cnt)[6] = outputkeypoint[i_cnt].class_id;
  }
  if (WriteToLocalcont(outfile, outputfeature) == 1) {
    return 1;
  }
  return 0;
}

int LogoDetectionIniFromLocal::ReadDescriptioncont(
    FILE *infile,
    Mat *inputdescription) {
  if (ReadFromLocalcont(infile, inputdescription) == 1) {
    return 1;
  }
  return 0;
}

int LogoDetectionIniFromLocal::WriteDescriptioncont(
    FILE *outfile,
    const Mat &outputdescription) {
  if (WriteToLocalcont(outfile, outputdescription) == 1) {
    return 1;
  }
  return 0;
}

int LogoDetectionIniFromLocal::InitialToLocalFilecont(
    string conf, bool tfs_enable) {
  char buffer[999];
  getcwd(buffer, 999);
  time_t current_time = time(0);
  char strmodel_version[999];
  strftime(strmodel_version, sizeof(strmodel_version),
      "%Y%m%d%H%M", localtime(&current_time));
  last_version_ = algodate_ + string(".") + string(strmodel_version);
  printf("Model version: %s \n", strmodel_version);
  printf("Algo_Model version: %s \n", last_version_.c_str());
  printf("The current directory : %s \n", buffer);
  string confstring;
  std::ifstream cf(conf.c_str());
  if (!cf.is_open()) {
    SIMPLE_LOG_V1("Can't Open file %s", conf.c_str());
    return -1;
  }
  cf.seekg(0, std::ios::end);
  confstring.reserve(cf.tellg());
  cf.seekg(0, std::ios::beg);
  confstring.assign((std::istreambuf_iterator<char>(cf)),
                     std::istreambuf_iterator<char>());
  rapidjson::Document confdoc;
  confdoc.Parse(confstring.c_str());
  if (confdoc.HasParseError()) {
    SIMPLE_LOG_V1("Error in conf file parse");
    return -1;
  }
  rapidjson::Value::ConstMemberIterator itr =
    confdoc.FindMember("logodet");
  if (itr == confdoc.MemberEnd() || !itr->value.IsObject()) {
    SIMPLE_LOG_V1("Error in conf entry for logodet");
    return -1;
  }
  const rapidjson::Value &logodetconf = itr->value;
  itr = logodetconf.FindMember("meta_conf");
  if (itr == confdoc.MemberEnd() || !itr->value.IsString()) {
    SIMPLE_LOG_V1("Error in conf entry for meta_conf");
    return -1;
  }
  string meta_conf = itr->value.GetString();
  itr = logodetconf.FindMember("feature_cache_conf");
  if (itr == confdoc.MemberEnd() || !itr->value.IsString()) {
    SIMPLE_LOG_V1("Error in conf entry for feature_cache_conf");
    return -1;
  }
  string feature_cache_conf = itr->value.GetString();

  itr = logodetconf.FindMember("flann_tree_index_conf");
  if (itr == confdoc.MemberEnd() || !itr->value.IsString()) {
    SIMPLE_LOG_V1("Error in conf entry for flann_tree_index_conf");
    return -1;
  }
  string flann_tree_index_conf = itr->value.GetString();

  itr = logodetconf.FindMember("tfs_enable");
  if (itr == confdoc.MemberEnd() || !itr->value.IsBool()) {
    SIMPLE_LOG_V1("Error in conf entry for tfs_enable");
  } else {
    tfs_enable = itr->value.GetBool();
  }
  itr = logodetconf.FindMember("img_dir");
  if (itr == confdoc.MemberEnd() || !itr->value.IsString()) {
    SIMPLE_LOG_V1("Error in conf entry for img_dir");
    return -1;
  }
  string img_dir = itr->value.GetString();

  SIMPLE_LOG_V1("meta_conf: \n %s", meta_conf.c_str());
  SIMPLE_LOG_V1("feature_cache_conf: \n %s", feature_cache_conf.c_str());
  SIMPLE_LOG_V1("flann_tree_index_conf: \n %s", flann_tree_index_conf.c_str());
  SIMPLE_LOG_V1("tfs_enable: \n %d", tfs_enable);
  SIMPLE_LOG_V1("img_dir: \n %s", img_dir.c_str());

  vector<vector<string> > confcontext;
  confcontext = ReadConfFile(meta_conf, string(""));
  if (confcontext.size() > 0) {
    if (confcontext[0].size() != 9) {
      SIMPLE_LOG_V1("Conf context is not true...");
      return -1;
    }
  } else {
    SIMPLE_LOG_V1("File %s context is null.", meta_conf.c_str());
    return -1;
  }
  // string imgdir = "";
  for (int i_cnt=0; i_cnt < static_cast<int>(confcontext.size()); i_cnt ++) {
    string tfs = confcontext[i_cnt][3];
    string imgpath = img_dir + "/" + tfs;
    Mat logo;
    if (tfs_enable && (tfs_ini_flag_ == 0)) {
      const int64_t BUFFER_SIZE = 10000000;
      int64_t ret_count = 0;
      static vector<unsigned char> buf(BUFFER_SIZE);
      int ret;
      for (int try_cnt = 0; try_cnt < 2; try_cnt++) {
        ret = restclient_.fetch_buf(
        ret_count,
        reinterpret_cast<char*>(&buf[0]),
        BUFFER_SIZE,
        tfs.c_str());
        if (ret == 0) {
          break;
        }
        sleep(1);
      }
      if (ret != 0) {
        SIMPLE_LOG_V1("Read tfs %s fail",  tfs.c_str());
        // tfs长期会失效,通过tfs读取失效不退出
        // return -1;
        logo = Mat::zeros(1, 1, CV_8U);
      } else {
        logo = cv::imdecode(buf, CV_LOAD_IMAGE_UNCHANGED);
      }
    } else {
      logo = cv::imread(imgpath, CV_LOAD_IMAGE_COLOR);
    }
    string logo_id = confcontext[i_cnt][0];
    string brand_name = confcontext[i_cnt][4];
    string brand_id = confcontext[i_cnt][5];
    string logo_name = confcontext[i_cnt][6];
    string similarity_thresh = confcontext[i_cnt][7];
    string cover_ratio_thresh = confcontext[i_cnt][8];
    double dsimilarity_thresh = Str2Num(similarity_thresh);
    double dcover_ratio_thresh = Str2Num(cover_ratio_thresh);
    int intialreadconfflag = InitialFromString(logo, logo_name, brand_name,
        brand_id, logo_id, dsimilarity_thresh, dcover_ratio_thresh);
    if (intialreadconfflag == 0) {
      SIMPLE_LOG_V1("tfs: %s 加载初始化配置失败", tfs.c_str());
      return -1;
    }
  }

  if (Setup() != 1) {
    SIMPLE_LOG_V1("Setup fail...");
    return -1;
  } else {
    SIMPLE_LOG_V1("Setup success...");
  }

  FILE *filewrite = fopen(feature_cache_conf.c_str(), "wb");
  if (filewrite == NULL) {
    SIMPLE_LOG_V1("打开文件 %s 失败", feature_cache_conf.c_str());
  }
  int irowconf, icolconf;
  irowconf = confcontext.size();
  if (irowconf > 0) {
    if (confcontext[0].size() != 9) {
      icolconf = confcontext[0].size();
    }
  }
  WriteStringBincont(filewrite, last_version_);
  fwrite(&irowconf, sizeof(int), 1, filewrite);
  fwrite(&icolconf, sizeof(int), 1, filewrite);
  for (int i_row = 0; i_row < static_cast<int>(confcontext.size()); i_row++) {
    if (confcontext[i_row].size() != 9) {
      SIMPLE_LOG_V1("Conf Format Error... in Lines %d", i_row);
      return -1;
    }
    for (int j_col = 0;
        j_col < static_cast<int>(confcontext[i_row].size());
        j_col++) {
      WriteStringBincont(filewrite, confcontext[i_row][j_col]);
    }
  }
  int mapsize = logo_feature_list_.size();
  fwrite(&mapsize, sizeof(int), 1, filewrite);

  Mat logodesccombine;
  int ind_logo = 0;
  SIMPLE_LOG_V1("Total logo num =  %d",
      static_cast<int>(logo_feature_list_.size()));
  for (map<string, LogoFeature>::iterator it = logo_feature_list_.begin();
      it != logo_feature_list_.end(); it++) {
    ind_logo++;
    vector<KeyPoint> tmpkeypointvec = it->second.keypoints_logo_;
    Mat tmpdescriptions = it->second.descriptors_logo_;
    // add each desc to Combine and convert to 8UC1
    tmpdescriptions.convertTo(tmpdescriptions, CV_8UC1);
    logodesccombine.push_back(tmpdescriptions);
    // Mat tmpimg = it->second.logoimg;
    WriteFeaturecont(filewrite, tmpkeypointvec);
    WriteDescriptioncont(filewrite, tmpdescriptions);

    int img_row, img_col;
    img_row = it->second.logoimg_.rows;
    img_col = it->second.logoimg_.cols;
    fwrite(&img_row, sizeof(int), 1, filewrite);
    fwrite(&img_col, sizeof(int), 1, filewrite);
    WriteToLocalcont(filewrite, it->second.logoimg_);
    int featureindex = Str2Num(it->first);
    int logoindex = it->second.logo_info_.logo_index_;
    fwrite(&featureindex, sizeof(int), 1, filewrite);
    fwrite(&logoindex, sizeof(int), 1, filewrite);
  }
  // logodesccombine.convertTo(logodesccombine, CV_8UC1);
  SIMPLE_LOG_V1("Save tree to %s", flann_tree_index_conf.c_str());
  m_flann_->save(flann_tree_index_conf.c_str());
  SIMPLE_LOG_V1("Save tree OK");
  fclose(filewrite);
  return 0;
}

int LogoDetectionIniFromLocal::InitialFromLocalFilecont(
    string conf) {
  string confstring;
  std::ifstream cf(conf.c_str());
  if (!cf) {
    SIMPLE_LOG_V1("打开配置文件 %s 失败", conf.c_str());
    return -1;
  }
  cf.seekg(0, std::ios::end);
  confstring.reserve(cf.tellg());
  cf.seekg(0, std::ios::beg);
  confstring.assign((std::istreambuf_iterator<char>(cf)),
                     std::istreambuf_iterator<char>());
  rapidjson::Document confdoc;
  confdoc.Parse(confstring.c_str());
  if (confdoc.HasParseError()) {
    SIMPLE_LOG_V1("Error in conf file %s parse", conf.c_str());
    return -1;
  }
  rapidjson::Value::ConstMemberIterator itr =
    confdoc.FindMember("logodet");
  if (itr == confdoc.MemberEnd() || !itr->value.IsObject()) {
    SIMPLE_LOG_V1("Error in conf entry for logodet");
    return -1;
  }
  const Value &logodetconf = itr->value;
  itr = logodetconf.FindMember("meta_conf");
  if (itr == confdoc.MemberEnd() || !itr->value.IsString()) {
    SIMPLE_LOG_V1("Error in conf entry for meta_conf");
    return -1;
  }
  string meta_conf = itr->value.GetString();
  itr = logodetconf.FindMember("feature_cache_conf");
  if (itr == confdoc.MemberEnd() || !itr->value.IsString()) {
    SIMPLE_LOG_V1("Error in conf entry for feature_cache_conf");
    return -1;
  }
  string feature_cache_conf = itr->value.GetString();

  itr = logodetconf.FindMember("flann_tree_index_conf");
  if (itr == confdoc.MemberEnd() || !itr->value.IsString()) {
    SIMPLE_LOG_V1("Error in conf entry for flann_tree_index_conf");
    return -1;
  }
  string flann_tree_index_conf = itr->value.GetString();

  itr = logodetconf.FindMember("img_dir");
  if (itr == confdoc.MemberEnd() || !itr->value.IsString()) {
    SIMPLE_LOG_V1("Error in conf entry for img_dir");
    return -1;
  }
  string img_dir = itr->value.GetString();
  SIMPLE_LOG_V1("meta_conf: \n %s", meta_conf.c_str());
  SIMPLE_LOG_V1("feature_cache_conf: \n %s", feature_cache_conf.c_str());
  SIMPLE_LOG_V1("flann_tree_index_conf: \n %s", flann_tree_index_conf.c_str());
  SIMPLE_LOG_V1("img_dir: \n %s", img_dir.c_str());

  int irowconf, icolconf;
  FILE *fileread = fopen(feature_cache_conf.c_str(), "rb");
  if (fileread == NULL) {
    SIMPLE_LOG_V1("Error in read feature_cache_conf file: %s",
        feature_cache_conf.c_str());
    return -1;
  }
  FILE *fileread_tree_conf = fopen(flann_tree_index_conf.c_str(), "rb");
  if (fileread_tree_conf == NULL) {
    SIMPLE_LOG_V1("Error in read fileread_tree_conf file: %s",
        flann_tree_index_conf.c_str());
    return -1;
  }
  fclose(fileread_tree_conf);
  ReadStringBincont(fileread, &last_version_);
  SIMPLE_LOG_V1("Version: %s\n", last_version_.c_str());
  fread(&irowconf, sizeof(int), 1, fileread);
  fread(&icolconf, sizeof(int), 1, fileread);
  for (int i_row = 0; i_row < irowconf; i_row++) {
    string index, createtime, rectifytime;
    string tfs, brandname, brandid, logoname, similarthresh, coverthresh;
    ReadStringBincont(fileread, &index);
    ReadStringBincont(fileread, &createtime);
    ReadStringBincont(fileread, &rectifytime);
    ReadStringBincont(fileread, &tfs);
    ReadStringBincont(fileread, &brandname);
    ReadStringBincont(fileread, &brandid);
    ReadStringBincont(fileread, &logoname);
    ReadStringBincont(fileread, &similarthresh);
    ReadStringBincont(fileread, &coverthresh);
    double dsimilarthresh = Str2Num(similarthresh);
    double dcoverthresh = Str2Num(coverthresh);
    // string imgpath = imgdir + tfs;
    // Mat logo = cv::imread(imgpath, CV_LOAD_IMAGE_COLOR);
    Mat logo = Mat::zeros(1, 1, CV_8U);
    int intialreadconfflag = InitialFromString(logo, logoname, brandname,
        brandid, index, dsimilarthresh, dcoverthresh);
    if (intialreadconfflag == 0) {
      SIMPLE_LOG_V1("tfs: %s 读入本地初始化配置失败", tfs.c_str());
      return -1;
    }
  }
  int mapsize;
  fread(&mapsize, sizeof(int), 1, fileread);
  SIMPLE_LOG_V1("mapsize: %d", mapsize);
  // store all desc
  logo_desc_combine_.release();
  key_logo_name_.resize(0);
  key_logo_ind_.resize(0);
  for (int map_cnt = 0; map_cnt < mapsize; map_cnt++) {
    Mat tmpdescriptions;
    vector<KeyPoint> tmpkeypointvec;
    Mat tmplogoimg;
    ReadFeaturecont(fileread, &tmpkeypointvec);
    ReadDescriptioncont(fileread, &tmpdescriptions);
    // new need to convert
    tmpdescriptions.convertTo(tmpdescriptions, CV_8UC1);
    // tmpdescriptions.convertTo(tmpdescriptions, CV_32FC1);
    int img_row, img_col;
    fread(&img_row, sizeof(int), 1, fileread);
    fread(&img_col, sizeof(int), 1, fileread);
    ReadFromLocalcont(fileread, &tmplogoimg);
    int featureindex, logoindex;
    fread(&featureindex, sizeof(int), 1, fileread);
    fread(&logoindex, sizeof(int), 1, fileread);
    string strfeatureindex = Num2Str(featureindex);
    string strlogoindex = Num2Str(logoindex);
    if (logo_conf_list_.find(strlogoindex) != logo_conf_list_.end()) {
      LogoConf tmpconf = logo_conf_list_[strlogoindex];
      LogoFeature curlogofeature;
      curlogofeature.logoimg_ = tmplogoimg.clone();
      curlogofeature.logo_name_ = tmpconf.logo_name_;
      curlogofeature.keypoints_logo_ = tmpkeypointvec;
      if (curlogofeature.keypoints_logo_.size() == 0) {
        CoutToPc(string("LogoImg have no keypoints..."));
        continue;
      }
      curlogofeature.descriptors_logo_ = tmpdescriptions;
      // no need to save memory
      logo_desc_combine_.push_back(tmpdescriptions);
      for (int i = 0; i < tmpdescriptions.rows; i++) {
        key_logo_name_.push_back(strfeatureindex);
        key_logo_ind_.push_back(i);
      }

      Makelogocover(curlogofeature.logoimg_, &curlogofeature);
      ModeCoverInitial(&curlogofeature);

      curlogofeature.logo_info_ = tmpconf;
      logo_feature_list_.insert(map<string, LogoFeature>::value_type(
        strfeatureindex, curlogofeature));
    } else {
      SIMPLE_LOG_V1("featureindex: %s 没有对应的配置行",
          strfeatureindex.c_str());
      return -1;
    }
  }

  logo_desc_combine_.convertTo(logo_desc_combine_, CV_8UC1);
  // load tree
  // cv::flann::Distance dis_u8;
  m_flann_ = new cv::flann::GenericIndex<Distance_U8>(logo_desc_combine_,
    cvflann::SavedIndexParams(flann_tree_index_conf.c_str()));
  SIMPLE_LOG_V1("模型加载完毕");
  /*try {
    cout << "in" << endl;
    m_flann_->veclen();
    cout << "out" << endl;
  } catch (...) {
    cout << "错误的flann树文件"
      << flann_tree_index_conf
      << "或者不存在该文件" << endl;
  }*/
  /*if (!m_flann_->empty()) {
    cout << "加载模型文件" << flann_tree_index_conf << "失败" << endl;
    return -1;
  }*/
  // train tree
  // m_flann_ = new cv::flann::GenericIndex< Distance_U8 >
  //  (logo_desc_combine_, cvflann::KDTreeIndexParams(4));
  fclose(fileread);
  cf.close();
  cf.clear();
  return 0;
}

int LogoDetectionIniFromLocal::DisplayVersion(
    string conf) {
  string confstring;
  std::ifstream cf(conf.c_str());
  if (!cf) {
    SIMPLE_LOG_V1("打开配置文件 %s 失败", conf.c_str());
    return -1;
  }
  cf.seekg(0, std::ios::end);
  confstring.reserve(cf.tellg());
  cf.seekg(0, std::ios::beg);
  confstring.assign((std::istreambuf_iterator<char>(cf)),
                     std::istreambuf_iterator<char>());
  rapidjson::Document confdoc;
  confdoc.Parse(confstring.c_str());
  if (confdoc.HasParseError()) {
    SIMPLE_LOG_V1("Error in conf file %s parse", conf.c_str());
    return -1;
  }
  rapidjson::Value::ConstMemberIterator itr =
    confdoc.FindMember("logodet");
  if (itr == confdoc.MemberEnd() || !itr->value.IsObject()) {
    SIMPLE_LOG_V1("Error in conf entry for logodet");
    return -1;
  }
  const Value &logodetconf = itr->value;
  itr = logodetconf.FindMember("meta_conf");
  if (itr == confdoc.MemberEnd() || !itr->value.IsString()) {
    SIMPLE_LOG_V1("Error in conf entry for meta_conf");
    return -1;
  }
  string meta_conf = itr->value.GetString();
  itr = logodetconf.FindMember("feature_cache_conf");
  if (itr == confdoc.MemberEnd() || !itr->value.IsString()) {
    SIMPLE_LOG_V1("Error in conf entry for feature_cache_conf");
    return -1;
  }
  string feature_cache_conf = itr->value.GetString();

  itr = logodetconf.FindMember("flann_tree_index_conf");
  if (itr == confdoc.MemberEnd() || !itr->value.IsString()) {
    SIMPLE_LOG_V1("Error in conf entry for flann_tree_index_conf");
    return -1;
  }
  string flann_tree_index_conf = itr->value.GetString();

  itr = logodetconf.FindMember("img_dir");
  if (itr == confdoc.MemberEnd() || !itr->value.IsString()) {
    SIMPLE_LOG_V1("Error in conf entry for img_dir");
    return -1;
  }
  string img_dir = itr->value.GetString();

  FILE *fileread = fopen(feature_cache_conf.c_str(), "rb");
  if (fileread == NULL) {
    SIMPLE_LOG_V1("Error in read feature_cache_conf file: %s",
        feature_cache_conf.c_str());
    return -1;
  }
  FILE *fileread_tree_conf = fopen(flann_tree_index_conf.c_str(), "rb");
  if (fileread_tree_conf == NULL) {
    SIMPLE_LOG_V1("Error in read fileread_tree_conf file: %s",
        flann_tree_index_conf.c_str());
    return -1;
  }
  string last_version;
  ReadStringBincont(fileread, &last_version);
  printf("%s", last_version.c_str());

  fclose(fileread_tree_conf);
  fclose(fileread);

  cf.close();
  cf.clear();
  return 0;
}
// hold on demand
int LogoDetectionIniFromLocal::InitialFromLocalFile2Byte(
    string conf,
    vector<unsigned char> *output) {
  std::filebuf *pbuf;
  std::ifstream filestr;
  unsigned char *buffer;
  int64 size;

  filestr.open(conf.c_str(), std::ios::binary);

  if (filestr == NULL) {
    SIMPLE_LOG_V1("不存在文件 %s", conf.c_str());
    return -1;
  }
  pbuf = filestr.rdbuf();
  size = pbuf->pubseekoff(0, std::ios::end, std::ios::in);
  SIMPLE_LOG_V1("size is %d", static_cast<int>(size));
  pbuf->pubseekpos(0, std::ios::in);

  buffer = new unsigned char[size];
  pbuf->sgetn(reinterpret_cast<char*>(buffer), size);
  // output = reinterpret_cast<unsigned char*>(buffer);
  std::copy((const unsigned char *)buffer,
        (const unsigned char *)buffer + size, (*output).begin());
  filestr.close();
  return 1;
}
// hold on demand
int LogoDetectionIniFromLocal::InitialFromByte(
    vector<unsigned char> * output) {
  return 1;
}
