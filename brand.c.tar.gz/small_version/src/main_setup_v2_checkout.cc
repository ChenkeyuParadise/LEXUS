// Copyright 2016
#include <stdio.h>
#include <time.h>

#include <iostream>
#include <fstream>
#include <vector>

// #include "../include/selective_search.h"
#include "include/logo_detection.h"
#include "include/function.h"
#include "include/Utility.h"

#include "include/LogoDetectionForhfs.h"
#include "include/logo_detection_localini.h"

#define eps 2.2204e-16
// #include "profiler.h"
using std::string;

int main(int argc, char** argv) {
    if (argc != 2) {
        cout << "Usage: " << argv[0]
          << " conf_path" << endl;
        return -1;
    }
    string conf_path = string(argv[1]);

    int checkflag = LogoDetectionIniFromLocal::DisplayVersion(conf_path);
    if (checkflag != 0) {
      SIMPLE_LOG_V1("版本检查失败...");
      return -1;
    }
    // ProfilerStart("CPUProfile");
    return 0;
}

