// Copyright 2016
#include "MatrixIO.h"

using std::string;
using cv::Mat;

// Currently only support CV_32F
bool WriteMatrixBinVector(string strname, vector<Mat> vecmat) {
  FILE* file = fopen(strname.c_str(), "wb");
  if (file == NULL) {
    printf("Fail to write %s\n", strname.c_str());
    return false;
  }
  for (int i_cnt=0; i_cnt < static_cast<int>(vecmat.size()); i_cnt++) {
    int icol = vecmat[i_cnt].cols;
    int irow = vecmat[i_cnt].rows;

    const float *pdata = reinterpret_cast<float *>(vecmat[i_cnt].ptr());
    fwrite(&irow, sizeof(int), 1, file);
    fwrite(&icol, sizeof(int), 1, file);
    fwrite(pdata, sizeof(float), icol * irow, file);
  }
  fclose(file);
  return true;
}

bool WriteMatrixBin(string strname, const Mat& matdata) {
  FILE* file = fopen(strname.c_str(), "wb");
  if (file == NULL) {
    printf("Fail to write %s\n", strname.c_str());
    return false;
  }

  int icol = matdata.cols;
  int irow = matdata.rows;
  int elemsize = matdata.elemSize();
  int type = matdata.depth();
  const void *pdata = reinterpret_cast<const void *>(matdata.ptr());
  // cout <<"this elemsize is "<< elemsize <<endl;
  // cout << "this type is " << type << endl;
  fwrite(&irow, sizeof(int), 1, file);
  fwrite(&icol, sizeof(int), 1, file);
  fwrite(&elemsize, sizeof(int), 1, file);
  fwrite(&type, sizeof(int), 1, file);
  fwrite(pdata, elemsize, icol * irow, file);

  fclose(file);
  return true;
}

bool WriteMatrixBincont(FILE* file, const Mat& matdata) {
  if (file == NULL) {
    printf("Fail to write in %s\n", "WriteMatrixBincont");
    return false;
  }

  int icol = matdata.cols;
  int irow = matdata.rows;
  int elemsize = matdata.elemSize();
  int type = matdata.depth();
  const void *pdata = reinterpret_cast<const void *>(matdata.ptr());
  // cout <<"this elemsize is "<< elemsize <<endl;
  // cout << "this type is " << type << endl;
  fwrite(&irow, sizeof(int), 1, file);
  fwrite(&icol, sizeof(int), 1, file);
  fwrite(&elemsize, sizeof(int), 1, file);
  fwrite(&type, sizeof(int), 1, file);

  fwrite(pdata, elemsize, icol * irow, file);

  // fclose(file);
  return true;
}
// Currently only support CV_32F
bool ReadMatrixBin(string strname, Mat* matdata) {
  FILE* file = fopen(strname.c_str(), "rb");
  if (file == NULL) {
    printf("Fail to read %s\n", strname.c_str());
    return false;
  }

  int icol, irow, elemsize, type;

  fread(&irow, sizeof(int), 1, file);
  fread(&icol, sizeof(int), 1, file);
  fread(&elemsize, sizeof(int), 1, file);
  fread(&type, sizeof(int), 1, file);
  // cout <<"this elemsize is "<< elemsize <<endl;
  // cout << "this type is " << type << endl;
  // printf("irow = %d, icol = %d", irow, icol);
  // matdata = Mat(irow, icol, CV_32F);

  int64 ibytesize = 1;
  ibytesize *= icol * elemsize;
  ibytesize *= irow;

  unsigned char *ptr = new unsigned char[ibytesize];

  fread(ptr, sizeof(unsigned char), ibytesize, file);

  // float *pdata = (float *)matdata.ptr();
  Mat tmptmatdata = Mat(irow, icol, type, reinterpret_cast<void *>(ptr));
  // cout << "tmptmatdata is "<<tmptmatdata.isContinuous()<<endl;
  // cout << "this is a test" << tmptmatdata <<endl;
  (*matdata) = tmptmatdata.clone();

  // fread(pdata, sizeof(float), icol * irow, file);
  delete []ptr;
  fclose(file);


  return true;
}

bool ReadMatrixBincont(FILE* file, Mat* matdata) {
  if (file == NULL) {
    printf("Fail to read in %s\n", "ReadMatrixBincont");
    return false;
  }

  int icol, irow, elemsize, type;

  fread(&irow, sizeof(int), 1, file);
  fread(&icol, sizeof(int), 1, file);
  fread(&elemsize, sizeof(int), 1, file);
  fread(&type, sizeof(int), 1, file);
  // cout <<"this elemsize is "<< elemsize <<endl;
  // cout << "this type is " << type << endl;
  // printf("irow = %d, icol = %d", irow, icol);
  // matdata = Mat(irow, icol, CV_32F);

  int64 ibytesize = 1;
  ibytesize *= icol * elemsize;
  ibytesize *= irow;

  unsigned char *ptr = new unsigned char[ibytesize];

  fread(ptr, sizeof(unsigned char), ibytesize, file);

  // float *pdata = (float *)matdata.ptr();
  Mat tmptmatdata = Mat(irow, icol, type, reinterpret_cast<void *>(ptr));
  // cout << "tmptmatdata is "<<tmptmatdata.isContinuous()<<endl;
  // cout << "this is a test" << tmptmatdata <<endl;
  (*matdata) = tmptmatdata.clone();

  // fread(pdata, sizeof(float), icol * irow, file);
  delete []ptr;
  return true;
}

bool ReadStringBincont(FILE* file, string *outputstr) {
  char bufferoutput[2000];
  if (file == NULL) {
    printf("Fail to read %s\n", (*outputstr).c_str());
    return false;
  }
  int ilenghstr;
  fread(&ilenghstr, sizeof(int), 1, file);
  // cout<<"ilenghstr:"<<ilenghstr<<endl;
  fread(bufferoutput, sizeof(char), ilenghstr, file);
  bufferoutput[ilenghstr]= '\0';
  (*outputstr) = string(bufferoutput);
  return true;
}

bool WriteStringBincont(FILE* file, const string &outputstr) {
  if (file == NULL) {
    printf("Fail to write %s\n", outputstr.c_str());
    return false;
  }
  int ilenghstr = outputstr.size();
  fwrite(&ilenghstr, sizeof(int), 1, file);
  fwrite(outputstr.c_str(), sizeof(char), outputstr.size(), file);
  return true;
}

bool WriteMatrix(string strname,
                 const Mat& matdata) {
  FILE* file = fopen(strname.c_str(), "w");
  if (file == NULL) {
    printf("Fail to read%s\n", strname.c_str());
    return false;
  }

  int icols = matdata.cols;
  int irows = matdata.rows;

  fprintf(file, "Matrix: %d * %d", irows, icols);

  const float *pdata = reinterpret_cast<const float *>(matdata.ptr());
  for (int i = 0; i < irows; i++) {
    fprintf(file, "\n");
    for (int j = 0; j < icols; j++) {
      if (j != icols - 1) {
        fprintf(file, "%f ", *pdata);
      } else {
        fprintf(file, "%f", *pdata);
      }
      pdata++;
    }
  }
  fclose(file);

  return true;
}

bool ReadMatrix(string strname, Mat* matdata) {
  FILE* file = fopen(strname.c_str(), "r");
  if (file ==NULL) {
    printf("Fail to read%s\n", strname.c_str());
    return false;
  }

  int icols, irows;

  fscanf(file, "Matrix: %d * %d", &irows, &icols);

  // printf("%d * %d\n", irows, icols);

  (*matdata) = Mat(irows, icols, CV_32F);

  float *pdata = reinterpret_cast<float *>(matdata->ptr());

  for (int i = 0; i < irows; i++) {
    fscanf(file, "\n");
    for (int j = 0; j < icols; j++) {
      if (j != icols - 1) {
        fscanf(file, "%f ", pdata);
      } else {
        fscanf(file, "%f", pdata);
      }
      pdata++;
    }
  }

  fclose(file);

  return true;
}
