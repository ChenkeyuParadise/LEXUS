// Copyright 2016
#include<time.h>
#include <stdio.h>

#include <iostream>
#include <fstream>
#include <vector>

#include "include/logo_detection.h"
#include "include/function.h"
#include "include/Utility.h"

#include "include/LogoDetectionForhfs.h"
#include "include/logo_detection_localini.h"

#define eps 2.2204e-16
// #include "profiler.h"
using std::string;
using std::ios;

int main(int argc, char* argv[]) {
    if (argc != 4) {
        cout << "Usage: " << argv[0]
          << " conf_path"
          << " query_img_path"
          << " query_img_file_list" << endl;
        return -1;
    }
    string conf_path = argv[1];
    string query_img_path = argv[2];
    string query_img_file_list = argv[3];

    clock_t start;
    start = clock();
    // string strDir = "/home/xilou.zy/logo_detection_testset/query_img/";
    // string strFileList = "/home/xilou.zy/logo_detection_testset/query_set1";
    string strDir = query_img_path;
    string strFileList = query_img_file_list;
    vector<string> vecfilelist;
    GetFileList(strFileList, &vecfilelist);
    if (static_cast<int>(vecfilelist.size()) == 0) {
      cout << "不存在" << query_img_file_list << "文件或文件内容为空" << endl;
      return -1;
    }
    for (int i_cnt=0; i_cnt < static_cast<int>(vecfilelist.size()); i_cnt++) {
        cout << vecfilelist[i_cnt] << endl;
    }
    LogoDetectionForhfs test;
    LogoDetectionIniFromLocal localtestwrite;

    start = clock();
    localtestwrite.InitialFromLocalFilecont(conf_path);
    clock_t setuptime = clock() - start;
    cout << "初始化Setup时间为"
      << static_cast<double>(setuptime)/CLOCKS_PER_SEC<< endl;
    start = clock();

    string inputtest;
    int imgcnt = 0;
    int havelogocnt = 0;
    clock_t start_run = clock();
    cout << "vecfilelist: " << vecfilelist[0] << endl;
    for (int i_cnt = 0;
         i_cnt < static_cast<int>(vecfilelist.size());
         i_cnt += 1) {
      cout << "query ind=   " << i_cnt << endl;
      inputtest = strDir + vecfilelist[i_cnt];
      cout << inputtest << endl;

      std::filebuf *pbuf;
      std::ifstream filestr;
      char *buffer;
      int64 size;

      filestr.open(inputtest.c_str(), ios::binary);
      if (filestr == NULL) {
          cout << "不存在文件" << endl;
          continue;
      }
      pbuf = filestr.rdbuf();
      size = pbuf->pubseekoff(0, ios::end, ios::in);
      cout << "size is " << size << endl;
      pbuf->pubseekpos(0, ios::in);

      buffer = new char[size];
      pbuf->sgetn(buffer, size);
      filestr.close();
      // Mat imgtest = imread(inputtest);

      // ProfilerStart("CPUProfile");
      vector<unsigned char> imgbuffer(size);

      std::copy((const unsigned char *)buffer,
          (const unsigned char *)buffer + size, imgbuffer.begin());
      cout << imgbuffer.size() << endl;
      // string reDet = test.LogoDet(imgbuffer);
      // cout << "result: " << reDet << endl;
      delete [] buffer;
      Mat queryimg = cv::imdecode(imgbuffer, CV_LOAD_IMAGE_UNCHANGED);
      // string Res = LocalTestRead.RunDet(imgbuffer);
      // string Res = LocalTestRead.LogoDet(imgbuffer);
      // cout << Res << endl;
      vector<LogoDetResult> result = localtestwrite.RunDet(queryimg);
      for (int i_cnt=0;
           i_cnt< static_cast<int>(result.size());
           i_cnt ++) {
        cout << "Logo Name:" << result[i_cnt].metaconf_.logo_name_ << endl;
        cout << "Score:" << result[i_cnt].coveragerate_ << endl;
        cout << "Loc:" << result[i_cnt].topleft_x_ << ","
             << result[i_cnt].topleft_y_ << "," << result[i_cnt].topleft_y_
             << "," << result[i_cnt].topright_x_ << ","
             << result[i_cnt].topright_y_ << endl;
      }
      if (result[0].status_ == 1) {
        havelogocnt++;
      }

      imgcnt++;
      cout << "imgcnt=  " << imgcnt << "havelogocnt=    "
        << havelogocnt <<endl << endl;
    }
    clock_t End_Run = clock();
    cout << "运行时间为:"
      << static_cast<double>(End_Run-start_run)/CLOCKS_PER_SEC
      << "s" << endl;
    cout << "平均运行时间为:"
      << ((static_cast<double>(End_Run-start_run))
      /CLOCKS_PER_SEC/imgcnt) << endl;

    cout << "havelogocnt:" << havelogocnt << endl;
    cout << "imgcnt:" << imgcnt << endl;
    cout << "Recall:" << static_cast<double>(havelogocnt)/imgcnt << endl;
    return 0;
}

