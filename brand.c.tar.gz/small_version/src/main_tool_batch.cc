// Copyright 2016
#include<time.h>
#include <stdio.h>
#include <sys/stat.h>

#include <iostream>
#include <fstream>
#include <vector>
#include "rapidjson/document.h"

#include "include/logo_detection.h"
#include "include/function.h"
#include "include/Utility.h"

#include "include/LogoDetectionForhfs.h"
#include "include/logo_detection_localini.h"

#define eps 2.2204e-16
// #include "profiler.h"
using std::string;
using std::ios;
using cv::Point;

int main(int argc, char* argv[]) {
    if (argc != 3 && argc != 4) {
        cout << "Usage: " << argv[0]
          << " conf_path"
          << " query_img_path" << endl;
        cout << "or " << argv[0]
          << " conf_path"
          << " query_imgs_dir"
          << " query_imgs_listfile"
          << endl;
        return -1;
    }
    string conf_path = argv[1];
    string query_img_path = argv[2];
    string strFileList = "";
    if ( argc == 4 ) {
      strFileList = argv[3];
    }
    cout << "Batch start..." << endl;
    vector<string> vecfilelist;
    if (argc == 4) {
      GetFileList(strFileList, &vecfilelist);
    } else {
      vecfilelist.push_back(query_img_path);
    }
    clock_t start;
    start = clock();
    string strfile = query_img_path;
    LogoDetectionForhfs localtestwrite;

    start = clock();
    cout << "Initial Start..." << endl;
    int setupflag = localtestwrite.InitialFromConfFile(conf_path, string(""));
    if (setupflag != 0) {
      cout << "初始化失败" << endl;
      return -1;
    }
    clock_t setuptime = clock() - start;
    cout << "初始化Setup时间为"
      << static_cast<double>(setuptime)/CLOCKS_PER_SEC<< endl;
    start = clock();

    string inputtest;
    int imgcnt = 0;
    int havelogocnt = 0;
    clock_t start_run = clock();
    for (int i_cnt=0;
        i_cnt <  static_cast<int>(vecfilelist.size());
        i_cnt += 1) {
      if (argc == 4) {
        inputtest = strfile + vecfilelist[i_cnt];
      } else {
        inputtest = strfile;
      }
      cout << inputtest << endl;

      std::filebuf *pbuf;
      std::ifstream filestr;
      char *buffer;
      int64 size;

      filestr.open(inputtest.c_str(), ios::binary);
      if (filestr == NULL) {
          cout << "不存在文件" << inputtest << endl;
          return -1;
      }
      pbuf = filestr.rdbuf();
      size = pbuf->pubseekoff(0, ios::end, ios::in);
      cout << "size is " << size << endl;
      pbuf->pubseekpos(0, ios::in);

      buffer = new char[size];
      pbuf->sgetn(buffer, size);
      filestr.close();
      // Mat imgtest = imread(inputtest);

      // ProfilerStart("CPUProfile");
      vector<unsigned char> imgbuffer(size);

      std::copy((const unsigned char *)buffer,
          (const unsigned char *)buffer + size, imgbuffer.begin());
      cout << imgbuffer.size() << endl;
      // string reDet = test.LogoDet(imgbuffer);
      // cout << "result: " << reDet << endl;
      delete [] buffer;
      Mat queryimg = cv::imdecode(imgbuffer, CV_LOAD_IMAGE_UNCHANGED);
      // string Res = LocalTestRead.RunDet(imgbuffer);
      // string Res = LocalTestRead.LogoDet(imgbuffer);
      // cout << Res << endl;
      cout << "Queryimg channels: " << queryimg.channels() << endl;
      string redet = localtestwrite.LogoDet(imgbuffer);

      rapidjson::Document confdoc;
      confdoc.Parse(redet.c_str());
      if (confdoc.HasParseError()) {
        cout << "Error in conf file parse" << endl;
      }
      rapidjson::Value::ConstMemberIterator itr =
        confdoc.FindMember("results");
      rapidjson::Value results;
      if (itr != confdoc.MemberEnd() && itr->value.IsArray()) {
        // results = itr->value.GetObject();
        results = confdoc["results"];
      } else {
          cout << "results is not array" << endl;
          continue;
      }
      cout << "redet:" << redet << endl;
      cout << "rapidjson parse" << endl;
      // cout <<"test:"<<results[0]["loc"][0].GetInt()<<endl;
      cv::Point rook_points[1][4];
      if (itr->value.IsArray() && results.Size() > 0) {
        havelogocnt++;
      }
      for (int logo_cnt=0;
           logo_cnt < static_cast<int>(results.Size());
           logo_cnt++) {
        rook_points[0][0] = Point(results[logo_cnt]["loc"][0].GetInt(),
          results[logo_cnt]["loc"][1].GetInt());
        rook_points[0][1] = Point(results[logo_cnt]["loc"][2].GetInt(),
          results[logo_cnt]["loc"][3].GetInt());
        rook_points[0][2] = Point(results[logo_cnt]["loc"][4].GetInt(),
          results[logo_cnt]["loc"][5].GetInt());
        rook_points[0][3] = Point(results[logo_cnt]["loc"][6].GetInt(),
          results[logo_cnt]["loc"][7].GetInt());
        // const Point* ppt[1] = { rook_points[0] };
        // int npt[] = {4};
        // polylines(imgtest, ppt, npt, 1, 1, CV_RGB(0, 255, 0), 2, 8, 0);
    }
    cout << "Logo Det Result: " << redet << endl;
    // ProfilerStop();
    imgcnt++;
  }
  int end_run = clock();
  cout << "运行时间为:"
    << static_cast<double>(end_run-start_run)/CLOCKS_PER_SEC
    << "s" << endl;
  cout << "HaveLogoCnt:" << havelogocnt << endl;
  cout << "ImgCnt:" << imgcnt << endl;
  cout << "Recall:" << static_cast<double>(havelogocnt)/imgcnt << endl;
    return 0;
}

