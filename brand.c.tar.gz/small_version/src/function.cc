// Copyright 2016
#include "include/function.h"
#include <sys/time.h>
#include <time.h>
FILE *flog_V1 = NULL;
char* time_str_V1(char* buffer, size_t size) {
  timeval tv;
  gettimeofday(&tv, NULL);
  strftime(buffer, size, "%m%d %H:%M:%S", localtime(&tv.tv_sec));
  snprintf(buffer + 13, size - 13, ".%06zu", tv.tv_usec);
  return buffer;
}
char time_buf_V1[80];
