// Copyright 2016
#include "include/Imagealgo.h"

string PHashValue(const Mat &src) {
  Mat img, dst;
  string rst(64, '\0');
  double dindex[64];
  double mean = 0.0;
  int k = 0;
  if (src.channels() == 3) {
     cvtColor(src, src, CV_BGR2GRAY);
     img = Mat_<double>(src);
  } else {
     img = Mat_<double>(src);
  }

/* 第一步，缩放尺寸*/
  resize(img, img, Size(8, 8));

/* 第二步，离散余弦变换，DCT系数求取*/
  dct(img, dst);

/* 第三步，求取DCT系数均值（左上角8*8区块的DCT系数）*/
  for (int i = 0; i < 8; ++i) {
    for (int j = 0; j < 8; ++j) {
      dindex[k] = dst.at<double>(i, j);
      mean += dst.at<double>(i, j)/64;
      ++k;
    }
  }

/* 第四步，计算哈希值。*/
  for (int i = 0; i < 64; ++i) {
    if (dindex[i] >= mean) {
      rst[i]='1';
    } else {
      rst[i]='0';
    }
  }
  return rst;
}

int HanmingDistance(const string &str1, const string &str2) {
  if ((str1.size() != 64) || (str2.size() != 64))
    return -1;
  int difference = 0;
  for (int i = 0; i < 64; i++) {
    if (str1[i] != str2[i])
      difference++;
  }
  return difference;
}
