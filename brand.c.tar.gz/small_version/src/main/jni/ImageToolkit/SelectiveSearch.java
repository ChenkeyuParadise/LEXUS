package ImageToolkit;

public class SelectiveSearch{
    static {
        System.loadLibrary("selective_search_jni");
    }
    private long nativeHandle;
    public native int Init();
    public native int Init(int k, int min_size, float sigma, int histsize_color, int histsize_texture);
    public native String ProcessFromBuffer(byte[] buffer);
    public native int Destroy();
}
