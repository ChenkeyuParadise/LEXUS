package ImageToolkit;
import java.io.IOException;

import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.ByteArrayInputStream;
import java.text.SimpleDateFormat;

import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import java.util.Date;
import java.lang.Long;
import java.net.URL;
import java.net.URLConnection;
import java.net.Authenticator;
import java.net.PasswordAuthentication;

import java.lang.Thread; 
import javax.imageio.ImageIO;
import javax.imageio.stream.ImageInputStream;
import javax.imageio.stream.MemoryCacheImageInputStream;
import java.io.*;

import org.json.*;
import java.util.ArrayList;
import java.util.List;
//import com.taobao.common;
import ImageToolkit.*;
import BaseTool.FileDeal; 
import BaseFunction.RectCaculate;

import org.opencv.core.Point;
import org.opencv.core.Rect;

import org.opencv.core.*;
import org.opencv.core.Core;
import org.opencv.core.Core.*;
import org.opencv.core.Mat;
import org.opencv.core.Rect;
import org.opencv.core.Size;
import org.opencv.highgui.Highgui;

public class TestRun{
    static {
        //System.loadLibrary(Core.NATIVE_LIBRARY_NAME);
    }
    public static void main(String argv[])
        throws JSONException, IOException
    {
        System.loadLibrary(Core.NATIVE_LIBRARY_NAME);
        System.out.println("Init model");

        SelectiveSearch Detector = new SelectiveSearch(); 
        float a = 0.1f;
        Detector.Init(100, 100, 0.8f, 16, 16);

        System.out.println("Init done");

        //String strLocalFile = argv[0];
        String infofile = "/home/keyu.cky/svn_project/sex_img_project/sex_img_detection/inputImg/Test_self/label/SexImagelabeltxt.txt"; 
        String ImgfileDir = "/home/keyu.cky/svn_project/sex_img_project/sex_img_detection/inputImg/Test_self/label/";
        //全图检测
        String strLocalFile = "/home/keyu.cky/svn_project/selective_search/data/testimage/test3.jpg";
        String fileDir = "/home/keyu.cky/svn_project/sex_img_project/sex_img_detection/inputImg/";
        String OutDir = "./test_result/"; 
        List<String> eachline = new ArrayList();
        eachline = FileDeal.readFile(infofile);
        
        String resultfilename = "test_img.jpg";
        String strOutFile = OutDir + "ImgDet_stastic.txt";
        BufferedWriter bw = new BufferedWriter(new FileWriter(strOutFile)); 
        ArrayList<File> test_all_files = FileDeal.getListFiles(fileDir);
        for(int i_count=0; i_count<eachline.size(); i_count += 30){
        //for(int i_cnt=0;i_cnt<test_all_files.size();i_cnt++){
            //File curFile = test_all_files.get(i_cnt);
            //String curfilename = curFile.getPath();

            //if(curfilename.indexOf(".jpg") == -1){
            //    continue;
            //}
            String []segs = eachline.get(i_count).split(";");
            String curfilename = ImgfileDir + segs[0];
            System.out.println(curfilename);
            System.out.println("Load image " + curfilename);
            byte[] imageBuf = null;
            try{
                imageBuf = ReadFileToBuffer(curfilename);
            }
            catch (Exception e)
            {
                System.err.println("Load image fail: " + curfilename);
                return;
            }
            Mat jpegMat = new Mat(1, imageBuf.length, CvType.CV_8U);
            jpegMat.put(0, 0, imageBuf);

            Mat currenImg = Highgui.imdecode(jpegMat, Highgui.CV_LOAD_IMAGE_COLOR);
            System.out.println("Load image done");
            
            String outResult = Detector.ProcessFromBuffer(imageBuf);
            
            JSONObject resJson = new JSONObject(outResult);
            String strImg_width = resJson.getString("imgwidth");
            String strImg_height = resJson.getString("imgheight");
            int ImgWidth,ImgHeight;
            ImgWidth = Integer.parseInt(strImg_width);
            ImgHeight = Integer.parseInt(strImg_height);

            Rect imgRect = new Rect(0, 0, ImgWidth, ImgHeight);
            
            JSONArray tmpAllResultjson = resJson.getJSONArray("results");
            //System.out.println(tmpAllResultjson);
            for(int j_count=0; j_count<segs.length; j_count++){
                int ground_truth_x, ground_truth_y, ground_truth_width, ground_truth_height;
                if(j_count != 0){
                    String []sonsegs = segs[j_count].split(",");

                    ground_truth_x = Integer.parseInt(sonsegs[0]);
                    ground_truth_y = Integer.parseInt(sonsegs[1]);
                    ground_truth_width = Integer.parseInt(sonsegs[2]);
                    ground_truth_height = Integer.parseInt(sonsegs[3]);
                }
                else{
                    ground_truth_x = 0;
                    ground_truth_y = 0;
                    ground_truth_width = 99999;
                    ground_truth_height = 99999;
                    continue;
                }
                Rect GroundTruthRoi = new Rect(ground_truth_x, ground_truth_y, ground_truth_width, ground_truth_height);
                double MaxIOU = 0;
                Rect MaxRect = imgRect;
                for(int json_count=0; json_count<tmpAllResultjson.length(); json_count++){
                    JSONObject tmpResultjson = tmpAllResultjson.getJSONObject(json_count);
                    //System.out.println(tmpResultjson);
                    String X_st = tmpResultjson.getString("x");
                    String Y_st = tmpResultjson.getString("y");
                    String Width_st = tmpResultjson.getString("width");
                    String Height_st = tmpResultjson.getString("height");
                    //System.out.println(X_st + ";" + Y_st + ";" + Width_st);
                    int x,y,width,height;
                    x = Integer.parseInt(X_st);
                    y = Integer.parseInt(Y_st);
                    width = Integer.parseInt(Width_st);
                    height = Integer.parseInt(Height_st);
                    Rect imgRoi = new Rect(x, y, width, height);
                    Rect AdjustRect = RectCaculate.IntersectionRect(imgRect, imgRoi);
                    //System.out.println(AdjustRect.x + ";" +AdjustRect.y);
                    if(AdjustRect.area() > imgRect.area()/80.0){
                        //System.out.println(RectCaculate.IntersectionRect(imgRoi, GroundTruthRoi).area() + ";" + (imgRoi.area() + GroundTruthRoi.area()));
                        double currentIOU = RectCaculate.IntersectionRect(imgRoi, GroundTruthRoi).area()*1.0/ (imgRoi.area() + GroundTruthRoi.area() - RectCaculate.IntersectionRect(imgRoi, GroundTruthRoi).area());
                        if(currentIOU > MaxIOU){
                            MaxIOU = currentIOU;
                            MaxRect = imgRoi;
                        }
                    }  
                }
                Mat boundingboxImg = currenImg.clone();
                Core.rectangle(boundingboxImg, new Point(MaxRect.x, MaxRect.y), new Point(MaxRect.x + MaxRect.width, MaxRect.y + MaxRect.height), new Scalar(0, 0, 255), 3);
                Core.rectangle(boundingboxImg, new Point(GroundTruthRoi.x, GroundTruthRoi.y), new Point(GroundTruthRoi.x + GroundTruthRoi.width, GroundTruthRoi.y + GroundTruthRoi.height), new Scalar(0, 255, 0), 3);
                System.out.println(currenImg);  
                System.out.println( OutDir +"Img_" + segs[0] + "_" + MaxIOU +".jpg");
                Highgui.imwrite( OutDir + "Img_" + segs[0] + "_" + MaxIOU +".jpg", boundingboxImg);
                try{
                    bw.write("Img_" + segs[0] + "_" + MaxIOU +".jpg" + "" + MaxIOU + "\n");
                }
                catch (Exception e){
                }
            }
            System.out.println("Ocrdecoding done");

            //System.out.println("result = " + outResult);
            //return;

        }

        bw.close();
        Detector.Destroy();
    }

    public static byte[] ReadFileToBuffer(String fileName) throws Exception
    {
      
       File sf = null;
       FileInputStream in = null;
       sf =  new File(fileName);
       in = new FileInputStream(sf);

       int len =(int)sf.length();

       byte[] buf = new byte[len];


       int outLen = in.read(buf);

       in.close();

       if(outLen == len)
       {
         return buf;
       }
       else
       {
         System.out.println("outLen = " + outLen + " != len = " + len);
         byte[] outBuf = new byte[outLen];

         System.arraycopy(outBuf, 0, buf, 0, outLen);
         return outBuf;

       }

    }

}






