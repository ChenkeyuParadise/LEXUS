package BaseTool;

import java.util.ArrayList;
import java.util.List;
import java.io.File;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class FileDeal{
    public static List <String> readFile(String filePath) {
         FileReader fileReader = null;
         try {
             fileReader = new FileReader(filePath);
             BufferedReader reader = new BufferedReader(fileReader);
             return readAll(reader);
         } catch (Exception e) {
             e.printStackTrace();
             return null;
         } finally {
             try {
                 fileReader.close();
             } catch (Exception ex) {
             }
         }
     }


    public static List <String> readAll(BufferedReader br) throws IOException {
         StringBuilder sb = new StringBuilder();

         String line = null;
         List <String>  L = new ArrayList();
         int count =0;
         while ((line = br.readLine()) != null) {
             count++;
             if(count>1000){
                 break;
             }
             L.add(line);
             //sb.append(line).append("\r\n");
         }
         return L;
         //return sb.toString();
     }
    public static ArrayList<File> getListFiles(Object obj) {
        File directory = null;
        if (obj instanceof File) {
            directory = (File) obj;
        } else {
            directory = new File(obj.toString());
        }
        ArrayList<File> files = new ArrayList<File>();
        if (directory.isFile()) {
            files.add(directory);
            return files;
        } else if (directory.isDirectory()) {
            File[] fileArr = directory.listFiles();
            for (int i = 0; i < fileArr.length; i++) {
                File fileOne = fileArr[i];
                files.addAll(getListFiles(fileOne));
            }
        }
        return files;
    }

}
