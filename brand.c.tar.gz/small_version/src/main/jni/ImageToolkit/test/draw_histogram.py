#!/home/zhang.zhiqiang/anaconda/bin/python
# -*- coding: utf-8 -*-  
import os, sys, math
import numpy as np
import string

from sklearn import datasets, linear_model

import matplotlib as mpl
mpl.use('Agg')
import matplotlib.pyplot as plt

def draw_histogram(fig, Xvalue, Yvalue, labelname):
    #fig = plt.figure(figsize=(20,20))
    #for i_count, i_value in enumerate(Xvalue):
    #SumValue = sum(Yvalue)*1.0
    #plt.plot(Xvalue,  [y/SumValue for y in Yvalue], label=labelname)
    #ymax = max(Yvalue)
    ymax = 1;
    plt.plot(Xvalue,  [y/ymax for y in Yvalue], '-',label=labelname)
    #print Xvalue
    #print [y/ymax for y in Yvalue]
    title_name = 'ResponseTime'
    plt.title(title_name)
    plt.xlabel("Count")
    plt.ylabel("Time")

    ax = plt.gca();
    ax.set_xticks(np.linspace(0,max(Xvalue),21))
    ax.set_yticks(np.linspace(0,max(Yvalue),21))
    plt.grid(True)
    plt.legend(loc='best')

    #fig_name=SaveFileName
    #plt.savefig(fig_name, dpi=fig.dpi)
def linear_model_main(X_parameters, Y_parameters):
    # Create linear regression object
    regr = linear_model.LinearRegression()
    regr.fit(X_parameters, Y_parameters)
    return regr

def show_linear_line(regr, X_parameters, fig):
    # Create linear regression object
    plt.plot(X_parameters, regr.predict(X_parameters),linewidth=4);
if __name__ == '__main__':
    valueTest=[1,5,3,2,1,4,5,8,9,3]
    
    #Infile = "develop_sex_img_detection_rst.txt"
    #Infile = "develop_sex_img_detection_rst.txt"
    #Outfile = "All_model.jpg"

    #Infile = "php_stress_test.txt"
    #Outfile = "Positive_Huge_model.jpg"
    
    Infile = "ImgDet_stastic.txt"
    Outfile = "ImgDet_stastic.jpg"
    #OutDiffile = 'php_stress_test_tfs_count_15000_interval_0.2_core_10_queue_diff.jpg'
    
    fileRe = open(Infile, "r")
    maxTime = 0
    minTime = 99999999999
    maxCount = 0
    minCount = 99999999999
    static_data = [] 
    for count,eachline in enumerate(fileRe.readlines()):
        #print count,eachline
        eachfield = eachline.strip().split("")
        data_value = string.atof(eachfield[1])
        static_data.append(data_value)
    num_level = 50.0
    min_value = 0.0
    max_value = 1.0
    hist_data = [0] * int(num_level)
    for eachvalue in static_data:
        hist_data[int(round((eachvalue - min_value)/((max_value - min_value)/num_level)))] += 1.0
        #print time_count,begintime,endtime
    sumhist = 0
    culhist = []
    for eachvalue in hist_data:
        sumhist += eachvalue
        culhist.append(sumhist)
    culhist = [(max(culhist) - x)/max(culhist) for x in culhist]
    fig = plt.figure(figsize=(20,20))
    print "面积是:", sum(culhist)/len(culhist) 
        #print sortresult
    #Y_start_value_diff = list(map(lambda x: x[0]-x[1], zip(Y_start_value[1:], Y_start_value[0:-1])))
    #print X_start_value
    #print Y_start_value
    

    draw_histogram(fig, range(0, len(culhist)), culhist, 'start_time')
    #draw_histogram(fig, X_end_value[0:], Y_end_value[0:], 'end_time')
   
    plt.savefig(Outfile, dpi=fig.dpi)
    
    #X_input_value = [[x] for x in X_end_value]
    #linearmodel = linear_model_main(X_input_value[0:1000], Y_end_value[0:1000]) 
    #show_linear_line(linearmodel, X_input_value[0:1000], fig) 
    #print "每小时的处理能力是",3600.0/linearmodel.coef_[0],"张/时"
    #plt.savefig(Outfile, dpi=fig.dpi)
    
    #fig=plt.figure(figsize=(20,20))
    #Y_value_diff = list(map(lambda x: x[0]-x[1], zip(Y_end_value, Y_start_value)))
    #print "平均响应时间是",sum(Y_value_diff)*1.0/len(Y_value_diff),"s"
    #print "最大响应时间是",max(Y_value_diff),"s"
    #print "最小响应时间是",min(Y_value_diff),"s"
    #draw_histogram(fig, X_start_value, Y_value_diff, 'diff_time')
    #plt.savefig(OutDiffile, dpi=fig.dpi)
