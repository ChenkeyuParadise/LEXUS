javac -d . -cp json-org.jar:/home/keyu.cky/svn_project/selective_search/lib/opencv-2410.jar -sourcepath . *.java ../*.java

jar -cvf ImageToolkit.jar \
ImageToolkit/*.class BaseTool/*.class  \
BaseFunction/*.class \
json-org.jar \
/home/keyu.cky/svn_project/selective_search/lib/opencv-2410.jar

rm test_result/ -rf
mkdir test_result/
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/home/keyu.cky/svn_project/selective_search/build/:/home/keyu.cky/svn_project/selective_search/:/home/keyu.cky/svn_project/selective_search/lib
java -Xrunhprof:format=b,file=heapdump.hprof -cp ImageToolkit.jar:/home/keyu.cky/svn_project/selective_search/lib/opencv-2410.jar:json-org.jar:. -Djava.library.path=/home/keyu.cky/svn_project/selective_search/build:/home/keyu.cky/svn_project/selective_search/:/home/keyu.cky/svn_project/selective_search/lib:. ImageToolkit.TestRun
