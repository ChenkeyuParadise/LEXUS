package BaseFunction;

import org.opencv.core.Point;
import org.opencv.core.Rect;

public class RectCaculate {
	public static Rect IntersectionRect(Rect A, Rect B) {
		Rect C = new Rect();
		Point leftupPoint = new Point();
		Point rightdownPoint = new Point();
		
		leftupPoint.x = A.x>B.x ? A.x : B.x;
		leftupPoint.y = A.y>B.y ? A.y : B.y;
		
		rightdownPoint.x = (A.x + A.width) < (B.x + B.width)
				?  (A.x + A.width) : (B.x + B.width);
		rightdownPoint.y = (A.y + A.height) < (B.y + B.height)
				? (A.y + A.height) : (B.y + B.height);
		C.x = (int)leftupPoint.x;
		C.y = (int)leftupPoint.y;
		
		if(leftupPoint.x >= rightdownPoint.x || leftupPoint.y >= rightdownPoint.y){
			return new Rect(0,0,0,0);
		}
		
		C.width = (int)(rightdownPoint.x - leftupPoint.x + 1);
		C.height = (int)(rightdownPoint.y - leftupPoint.y + 1);
		return C; 
	}
	public static Rect UnionRect(Rect A, Rect B){
		Rect C = new Rect();
		Point leftupPoint = new Point();
		Point rightdownPoint = new Point();
		leftupPoint.x = A.x<B.x ? A.x : B.x;
		leftupPoint.y = A.y<B.y ? A.y : B.y;
		
		rightdownPoint.x = (A.x + A.width) > (B.x + B.width)
				?  (A.x + A.width) : (B.x + B.width);
		rightdownPoint.y = (A.y + A.height) > (B.y + B.height)
				? (A.y + A.height) : (B.y + B.height);
		C.x = (int)leftupPoint.x;
		C.y = (int)leftupPoint.y;
		
		C.width = (int)(rightdownPoint.x - leftupPoint.x + 1);
		C.height = (int)(rightdownPoint.y - leftupPoint.y + 1);
		return C; 
		
	}
}
