BUILD_DIR=./build
mkdir -p ${BUILD_DIR}
javac -d ${BUILD_DIR} ImageAlgo/*.java
javah -d ${BUILD_DIR} -classpath ${BUILD_DIR} -jni ImageAlgo.LogoDetection
