package ImageAlgo;

public class LogoDetection{
    static {
    }
    public int LoadUserLib(String LibName) {
        System.loadLibrary(LibName);
        return 1;
    }
    private long nativeHandle;
    private int flagSetup;
    public native int Setup();
    public native int InitLogo(byte[] buffer, String logo_name, String brand_name);
    public native int InitLogo(byte[] buffer, String logo_name, String brand_name, String brand_id, String logo_id, double corr_thresh, double cover_ratio_thresh);
    public native int InitNegLogo(byte[] buffer, String logo_name, String brand_name, double neg_corr_thresh);
    public native int Initial();
    public native int InitialSetupFromCacheBin(String Cachename);
    public native String ProcessFromBuffer(byte[] buffer);
    public native int ExportModelToCacheBin(String Cachename);
    //public native int Init(int k, int min_size, float sigma, int histsize_color, int histsize_texture);
    public native int Destroy();
}
