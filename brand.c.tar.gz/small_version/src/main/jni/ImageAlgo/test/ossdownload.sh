osscmd --host=cn-hangzhou.oss-cdn.aliyun-inc.com --id=xxxxxx --key=xxxxxx ls oss://t-fund-base-cv-logohourly/
