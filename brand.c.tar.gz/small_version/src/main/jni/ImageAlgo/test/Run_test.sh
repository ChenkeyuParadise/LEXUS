lib_so_dir=./../../../../../
javac -d . -cp json-org.jar:${lib_so_dir}/lib/opencv-2410.jar -sourcepath . *.java ../*.java

jar -cvf ImageAlgo.jar \
ImageAlgo/*.class BaseTool/*.class  \
BaseFunction/*.class \
json-org.jar \
${lib_so_dir}/lib/opencv-2410.jar


rm test_result/ -rf
mkdir test_result/
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:\
${lib_so_dir}:\
${lib_so_dir}:\
${lib_so_dir}/lib/:\
${lib_so_dir}/third-party/json-c-0.11/lib/

echo $LD_LIBRARY_PATH
#: << !
java -cp ImageAlgo.jar:${lib_so_dir}/lib/opencv-2410.jar:json-org.jar:. -Djava.library.path=:\
${lib_so_dir}/build:\
${lib_so_dir}:\
${lib_so_dir}/lib/:\
${lib_so_dir}/third-party/json-c-0.11/lib/:\
. ImageAlgo.TestRun
#!
