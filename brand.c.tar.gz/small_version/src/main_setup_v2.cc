// Copyright 2016
#include <stdio.h>
#include <time.h>

#include <iostream>
#include <fstream>
#include <vector>

// #include "../include/selective_search.h"
#include "include/logo_detection.h"
#include "include/function.h"
#include "include/Utility.h"

#include "include/LogoDetectionForhfs.h"
#include "include/logo_detection_localini.h"

#define eps 2.2204e-16
// #include "profiler.h"
using std::string;

int main(int argc, char** argv) {
    if (argc != 2) {
        cout << "Usage: " << argv[0]
          << " conf_path" << endl;
        return -1;
    }
    cout << "Setup Start" << endl;
    string conf_path = string(argv[1]);
    cout << "conf dir: " + conf_path << endl;

    clock_t start;
    start = clock();
    LogoDetectionIniFromLocal localtestwrite;
    LogoDetectionIniFromLocal localtestread;

    start = clock();
    cout << "写入本地开始" << endl;
    int iniflag = localtestwrite.InitialToLocalFilecont(conf_path);
    if (iniflag != 0) {
      SIMPLE_LOG_V1("模型生成失败...");
      return -1;
    }
    clock_t setuptime = clock() - start;
    cout << "写入本地结束" << endl;
    cout << "写入文件到本地时间为:" << endl;
    cout << static_cast<double>(setuptime)/CLOCKS_PER_SEC << "s" << endl;

    start = clock();
    cout << "读入本地开始" << endl;
    localtestread.InitialFromLocalFilecont(conf_path);
    cout << "读入本地结束" << endl;
    setuptime = clock() - start;
    cout << "读入本地初始化Setup时间:" << endl;
    cout << static_cast<double>(setuptime)/CLOCKS_PER_SEC << "s" << endl;

    // ProfilerStart("CPUProfile");
    SIMPLE_LOG_V1("模型生成成功...");
    return 0;
}

