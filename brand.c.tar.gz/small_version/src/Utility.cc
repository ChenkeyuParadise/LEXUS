// Copyright 2016
#include "Utility.h"
#include <fstream>
#include <iostream>

void GetFileList(const string strlistfile, std::vector<string>* vecfilelist) {
  (*vecfilelist).clear();
  string str;
  std::ifstream infile(strlistfile.c_str());

  if (!(infile.good())) {
    SIMPLE_LOG_V1("Can't open image list: %s\n", strlistfile.c_str());
  }
  SIMPLE_LOG_V1("File Name is %s", strlistfile.c_str());
  while (1) {
    std::getline(infile, str);
    if (!str.empty()) {
      if (*(str.end() - 1) == '\r') {
        str.erase(str.end() - 1);
      }
      (*vecfilelist).push_back(str);
    }
    if (!infile.good())
    break;
  }
  infile.close();
}

void WriteFileList(const string strlistfile,
                   const std::vector<string>& vecfilelist) {
  string str;

  std::ofstream outfile(strlistfile.c_str());

  if (!(outfile.good())) {
    outfile.close();
    return;
  }

  for (unsigned i = 0; i < vecfilelist.size(); i++) {
    if (i != vecfilelist.size() - 1) {
      outfile << vecfilelist[i] << std::endl;
    } else {
      outfile << vecfilelist[i];
    }
  }
  outfile.close();
}

void SplitStr(const string& s,
              const string& delim,
              std::vector< string >* ret) {
  size_t last = 0;
  size_t index = s.find_first_of(delim, last);
  while (index != string::npos) {
    ret->push_back(s.substr(last, index-last));
    last = index + 1;
    index = s.find_first_of(delim, last);
  }
  if (index-last > 0) {
    ret->push_back(s.substr(last, index-last));
  }
}
vector<vector<string> > ReadConfFile(string conffile, string delim) {
  ifstream myconffile(conffile.c_str());
  vector<vector<string> > allinfo;
  string eachline;
  if (!myconffile) {
    cout << "读取文件" + conffile + "失败" << endl;
    return allinfo;
  }
  vector<string> emptyinital;
  while (!myconffile.eof()) {
    // cout<<eachline<<endl;
    getline(myconffile, eachline);
    if (myconffile.fail()) {
      break;
    }
    allinfo.push_back(emptyinital);
    SplitStr(eachline, delim, &allinfo.back());
    cout << eachline << endl;
  }
  /*
  for(int i=0; i<allinfo.size(); i++){
      for(int j=0; j<allinfo[i].size(); j++){
          cout << allinfo[i][j] << endl;
      }
  }
  */
  myconffile.close();
  return allinfo;
}

int WriteFile(string conffile,
              string delim,
              vector<vector<string> > inputcontext) {
  ofstream myconf(conffile.c_str());
  string row_delim = "\n";
  for (int i_cnt=0; i_cnt < static_cast<int>(inputcontext.size()); i_cnt++) {
    for (int col_cnt=0;
         col_cnt < static_cast<int>(inputcontext[i_cnt].size());
         col_cnt++) {
      myconf.write(inputcontext[i_cnt][col_cnt].c_str(),
      inputcontext[i_cnt][col_cnt].length());
      if (col_cnt != (static_cast<int>(inputcontext[i_cnt].size()) -1)) {
        myconf.write(delim.c_str(), delim.length());
      }
    }

    if (i_cnt != (static_cast<int>(inputcontext.size()) - 1)) {
      myconf.write(row_delim.c_str(), row_delim.length());
    }
  }
  return 1;
}

int MkPath(std::string s, mode_t mode) {
  size_t pre = 0, pos;
  std::string dir;
  int mdret = 0;

  if (s[s.size()-1] != '/') {
    // force trailing / so we can handle everything in loop
    s+='/';
  }

  while ((pos=s.find_first_of('/', pre)) != std::string::npos) {
    dir = s.substr(0, pos++);
    pre = pos;
    if (dir.size() == 0) continue;  // if leading / first time is 0 length

    if ((mdret = ::mkdir(dir.c_str(), mode)) && errno != EEXIST) {
      return mdret;
    }
  }
    return mdret;
}
