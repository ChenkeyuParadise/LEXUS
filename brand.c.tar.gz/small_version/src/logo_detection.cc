// Copyright 2016
// add all logo matcher

// 54     model_maxwidth_size_ = 200;
// 1010   int stdthreshold = stdvector[floor(stdvector.size()*0.5)];   0.9 best
// 1896   //double match_thresh = 0.8;    0.6 best
// 1560   if(best_cover_ratio > logoimg_conf.cover_ratio_thresh){

#include "include/logo_detection.h"
// #include "include/function.h"

#include <math.h>
#include <tr1/unordered_set>
#include <iostream>
#include <string>
#include <vector>
#include <set>

#include "include/function.h"
// #include <opencv2/opencv.hpp>
// #include "profiler.h"

using std::string;
using cv::Mat;
using cv::DECOMP_SVD;
using cv::Point;
using cv::Scalar;
using std::tr1::unordered_set;
using std::set;
using std::max;
using std::min;

#include "rapidjson/document.h"
#include "rapidjson/writer.h"
#include "rapidjson/stringbuffer.h"
using rapidjson::Document;
using rapidjson::StringBuffer;
using rapidjson::Writer;
using rapidjson::Value;
using rapidjson::kArrayType;
using rapidjson::kObjectType;
// RestClient LogoDetection::restclient_;

LogoDetection::LogoDetection() {
  algodate_ = LOGODETECTION_ALGO_VERSION;
  last_version_ = "";
  initModule_nonfree();
  // const char *index_key = "IVF4096,Flat";

  // faiss::Index * index;
  // index = faiss::index_factory(128, index_key);
  // logo_detector_ = FeatureDetector::create("PyramidSIFT");
  // logo_detector_ = FeatureDetector::create("SIFT");
  logo_detector_ = new cv::PyramidAdaptedFeatureDetector(
      FeatureDetector::create("PyramidSIFT"),  5);
  query_detector_ = FeatureDetector::create("SIFT");
  // query_detector_ = FeatureDetector::create("PyramidSIFT"); //old
  // query_detector_ = new PyramidAdaptedFeatureDetector(
  // FeatureDetector::create("PyramidSIFT"),  5);

  // query_detector_ = new PyramidAdaptedFeatureDetector(
  // FeatureDetector::create("PyramidSIFT"),  3);
  descriptorextractor_ = DescriptorExtractor::create("SIFT");
  // descriptormatcher_ = DescriptorMatcher::create("FlannBased");

  // descriptormatcher_ = new cv::FlannBasedMatcher(
  //   new cv::flann::KDTreeIndexParams(1), new cv::flann::SearchParams(12));
  // NORM_L1, NORM_L2, NORM_HAMMING, NORM_HAMMING2.
  // descriptormatcher_ = new BFMatcher(cv::NORM_L1, false);

//  descriptormatcher1_ = new cv::FlannBasedMatcher(
//      new cv::flann::KDTreeIndexParams(1), new cv::flann::SearchParams(15));

  descriptormatcher1_ = new cv::BFMatcher(cv::NORM_L2, true);

  bsetupflag_ = false;

  siftcover_rate_ = 0.3;
  sum_cover_ = 1000;

  // logo_maxsize_ = 500;
  // for speed up
  logo_maxsize_ = 200;

  query_maxsize_ = 1500;
  // siftmatchdistance_threshold_ = 250;  //old
  // siftmatchdistance_threshold_ = 62500;  // 250*250
  siftmatchdistance_threshold_ = 160000;

  model_maxwidth_size_ = 200;
  // model_maxwidth_size_ = 100;  //for speed up

  max_model_coveriter_ = 30;
  model_cover_size_ = 10;
  // model_cover_threshratio_ = 0.6;
  model_cover_mincounttexture_ = 15;
  model_cover_stdthresh_ = 200;
  model_cover_stdminthresh_ = 10;
  model_cover_threshratio_ = 0.9;
  tfs_ini_flag_ = 100;
  // model_cover_threshratio_ =
  // pow(model_cover_stdminthresh_/model_cover_stdthresh_,
  // 1.0/max_model_coveriter_);
  InitialAffineMatchIndex();
  // cout<<"constructor running"<<endl;
  tfs_ini_flag_ = restclient_.initialize(
      "restful-store.vip.tbsite.net:3800",
      "52413f88bcefe");
  restclient_.set_request_timeout(1);
}

LogoDetection::~LogoDetection() {
}

int LogoDetection::InitialFromStringDefault(Mat logo,
                                            string logo_name,
                                            string brand_name) {
  if (CheckConfName(logo_name, brand_name) != 1) {
    return 0;
  }
  LogoConf curlogo_conf;
  curlogo_conf.logo_ = logo.clone();
  curlogo_conf.logo_name_ = logo_name;
  curlogo_conf.brand_name_ = brand_name;
  curlogo_conf.corr_thresh_ = 0.1;
  // curlogo_conf.neg_corr_thresh = 0.8;
  curlogo_conf.cover_ratio_thresh_ = 0.6;
  logo_conf_list_.insert(map<string, LogoConf>::value_type(
      Num2Str(logo_conf_list_.size()), curlogo_conf));
  return 1;
}
int LogoDetection::ShowLogoAllList() {
  for (map<string, LogoConf>::iterator it = logo_conf_list_.begin();
    it != logo_conf_list_.end(); it++) {
    cout << "key: " << it->first << " value:"<< it->second.logo_name_;
  }
  return 1;
}
int LogoDetection::InitialFromString(const Mat &logo,
                                     string logo_name,
                                     string brand_name,
                                     string brand_id,
                                     string logo_id,
                                     double corr_thresh,
                                     double cover_ratio_thresh) {
  if (CheckConfParam(corr_thresh, cover_ratio_thresh) != 1) {
    SIMPLE_LOG_V1("%s param is error...", logo_name.c_str());
    return 0;
  }
  if (logo.data == NULL || logo.empty()) {
    SIMPLE_LOG_V1("%s data is error...", logo_name.c_str());
    cout << logo << endl;
    cout << logo.empty() << endl;
    return 0;
  }
  LogoConf curlogo_conf;
  curlogo_conf.logo_ = logo.clone();
  curlogo_conf.logo_name_ = logo_name;
  curlogo_conf.brand_name_ = brand_name;
  curlogo_conf.brand_id_ = brand_id;
  curlogo_conf.logo_id_ = logo_id;
  curlogo_conf.corr_thresh_ = corr_thresh;
  curlogo_conf.cover_ratio_thresh_ = cover_ratio_thresh;
  curlogo_conf.logo_index_ = logo_conf_list_.size();
  logo_conf_list_.insert(map<string, LogoConf>::value_type(
      Num2Str(logo_conf_list_.size()), curlogo_conf));
  return 1;
}

int LogoDetection::SetupSingle() {
  if (bsetupflag_) {
    return 0;
  }
  for (map<string, LogoConf>::iterator it = logo_conf_list_.begin();
    it != logo_conf_list_.end(); it++) {
    // 转化成灰度图,并且控制logo图的大小
    Mat curimg_gray;

    cout << it->second.logo_name_ << " channels is "
         << it->second.logo_.channels() << endl;
    cout << "type is " << it->second.logo_.type() << endl;
    if (it->second.logo_.channels() == 3) {
      cvtColor(it->second.logo_, curimg_gray, CV_RGB2GRAY);
    } else if (it->second.logo_.channels() == 4) {
      cout << "4 channle" << endl;
      cvtColor(it->second.logo_, curimg_gray, CV_RGBA2RGB);
      cvtColor(curimg_gray, curimg_gray, CV_RGBA2GRAY);
    } else {
      curimg_gray = it->second.logo_.clone();
    }
    double zoom_scale = std::min(logo_maxsize_/curimg_gray.cols,
                                 logo_maxsize_/curimg_gray.rows);
    cv::resize(curimg_gray, curimg_gray,
               Size(zoom_scale*curimg_gray.cols, zoom_scale*curimg_gray.rows));
    LogoFeature curlogo_feature;

    curlogo_feature.logoimg_ = curimg_gray.clone();
    curlogo_feature.logo_name_ = it->second.logo_name_;

    logo_detector_->detect(curimg_gray,
                           curlogo_feature.keypoints_logo_);
    if (curlogo_feature.keypoints_logo_.size() == 0) {
      CoutToPc(string("logoimg have no keypoints..."));
      continue;
    }
    descriptorextractor_->compute(curimg_gray,
                                  curlogo_feature.keypoints_logo_,
                                  curlogo_feature.descriptors_logo_);
    Makelogocover(curimg_gray, &curlogo_feature);

    ModeCoverInitial(&curlogo_feature);
    // cout<< it->first << endl;
    logo_feature_list_.insert(
        map<string, LogoFeature>::value_type(Num2Str(logo_feature_list_.size()),
        curlogo_feature));
  }
  // 卸载conf结构中Mat内容以节省空间
  bsetupflag_ = true;
  return 1;
}

int LogoDetection::InverseSiftFeature(const Mat & Siftdescriptors) {
  Mat inversesiftfeature = Mat::zeros(Siftdescriptors.size(),
                                      Siftdescriptors.type());
  int block_size = 8;
  Mat tmpmiddle = Mat::zeros(Siftdescriptors.rows, 8, Siftdescriptors.type());
  for (int block_step = 0; block_step < 128/block_size; block_step++) {
    for (int i_step = 0; i_step < block_size; i_step++) {
      inversesiftfeature(Range::all(),
                         Range(block_step*block_size + i_step,
                               block_step*block_size + i_step + block_size));
      }
  }
  return 1;
}
int LogoDetection::Setup() {
  if (bsetupflag_) {
    return 0;
  }

  int countkey = 0;
  int countlogo = 0;
  vector <Mat>  alllogo_desc;
  key_logo_name_.resize(0);
  key_logo_ind_.resize(0);
  for (map<string, LogoConf>::iterator it = logo_conf_list_.begin();
       it != logo_conf_list_.end(); it++) {
    countlogo++;
    if (countlogo> 10) {
      // break;
    }
    if (countlogo < 0) {
      // continue;
    }
    // 转化成灰度图,并且控制logo图的大小
    Mat curimg_gray0;
    Mat curimg_gray;
    SIMPLE_LOG_V1("logo_name: %s",
        it->second.logo_name_.c_str());
    if (it->second.logo_.channels() == 3) {
      cvtColor(it->second.logo_, curimg_gray0, CV_RGB2GRAY);
    } else if (it->second.logo_.channels() == 4) {
      SIMPLE_LOG_V1("logo pic is 4 channle");
      cvtColor(it->second.logo_, curimg_gray0, CV_RGBA2RGB);
      cvtColor(curimg_gray0, curimg_gray0, CV_RGBA2GRAY);
    } else {
      curimg_gray0 = it->second.logo_.clone();
    }

    double detectzoom = std::min(logo_maxsize_/curimg_gray0.cols,
                                 logo_maxsize_/curimg_gray0.rows);
    if (detectzoom > 1) {
      detectzoom = 1;
    }
    resize(curimg_gray0, curimg_gray0,
           Size(detectzoom*curimg_gray0.cols, detectzoom*curimg_gray0.rows));

    double zoom_scale = std::min(model_maxwidth_size_/curimg_gray0.cols,
                                 model_maxwidth_size_/curimg_gray0.rows);
    resize(curimg_gray0, curimg_gray,
           Size(zoom_scale*curimg_gray0.cols, zoom_scale*curimg_gray0.rows));
    cout << "logo size: "<< curimg_gray.size() << endl;
    // logo image padding idea by Xilou
    Mat src = curimg_gray0.clone();
    Mat dst;
    int top = static_cast<int> (0.5*src.rows);
    int bottom = static_cast<int> (0.5*src.rows);
    int left = static_cast<int> (0.5*src.cols);
    int right = static_cast<int> (0.5*src.cols);
    int borderType = cv::BORDER_REPLICATE;
    copyMakeBorder(src, dst, top, bottom, left, right, borderType);
    vector<KeyPoint> K1;
    logo_detector_->detect(dst, K1);
    if (K1.size() == 0) {
      CoutToPc(string("logoimg have no keypoints..."));
      continue;
    }
    LogoFeature curlogo_feature;
    curlogo_feature.logoimg_ = curimg_gray.clone();
    curlogo_feature.logo_name_ = it->second.logo_name_;
    descriptorextractor_->compute(dst, K1,
                                  curlogo_feature.descriptors_logo_);
    for (int i = 0;
         i < static_cast<int>(K1.size()); i++) {
      KeyPoint k = K1[i];
      k.pt.x = (K1[i].pt.x - left)*zoom_scale;
      k.pt.y = (K1[i].pt.y - top)*zoom_scale;
      curlogo_feature.keypoints_logo_.push_back(k);
    }
    /*
    LogoFeature curlogo_feature;
    curlogo_feature.logoimg_ = curimg_gray.clone();
    curlogo_feature.logo_name_ = it->second.logo_name_;
    cout << "Detecting..." << endl;
    logo_detector_->detect(curimg_gray0, curlogo_feature.keypoints_logo_);
    cout << "curimg_gray0 size is: " << curimg_gray0.size() << endl;
    cout << curlogo_feature.keypoints_logo_.size() << endl;
    cout << "Detecting finish..." << endl;
    if (curlogo_feature.keypoints_logo_.size() == 0) {
      CoutToPc(string("logoimg have no keypoints..."));
      continue;
    }
    descriptorextractor_->compute(curimg_gray0, curlogo_feature.keypoints_logo_,
                                  curlogo_feature.descriptors_logo_);
    // add resize keypoints
    cout << curlogo_feature.keypoints_logo_.size() << endl;
    for (int i=0;
         i < static_cast<int>(curlogo_feature.keypoints_logo_.size()); i++) {
      curlogo_feature.keypoints_logo_[i].pt.x *= zoom_scale;
      curlogo_feature.keypoints_logo_[i].pt.y *= zoom_scale;
    }
    */
    // rootSift by Zhongjun
    RootSift(&(curlogo_feature.descriptors_logo_));

    Makelogocover(curimg_gray, &curlogo_feature);
    // add desc to matcher
    Mat tmp_matrix = curlogo_feature.descriptors_logo_.clone();
    // descriptormatcher_1->add(vector<Mat>(1, M1));
    // alllogo_desc.push_back(tmp_matrix);
    // logo_desc_combine_.push_back(tmp_matrix);

    countkey += curlogo_feature.descriptors_logo_.rows;

    ModeCoverInitial(&curlogo_feature);
    // cout<< it->first << endl;
    curlogo_feature.logo_info_ = it->second;

    logo_feature_list_.insert(
        map<string, LogoFeature>::value_type(Num2Str(logo_feature_list_.size()),
        curlogo_feature));
    Mat invcurimg_gray0;
    Mat invcurimg_gray;
    invcurimg_gray0 = 255 - curimg_gray0;
    invcurimg_gray = 255 - curimg_gray;
    dst = 255 - dst;
    LogoFeature curinvlogo_feature;

    curinvlogo_feature.logoimg_ = invcurimg_gray.clone();
    curinvlogo_feature.logo_name_ = it->second.logo_name_;
    // 监测特征点
    // logo_detector_->detect(invcurimg_gray0,
    //                        curinvlogo_feature.keypoints_logo_);
    logo_detector_->detect(dst, K1);
    // 计算特征向量
    // descriptorextractor_->compute(invcurimg_gray0,
    //                              curinvlogo_feature.keypoints_logo_,
    //                              curinvlogo_feature.descriptors_logo_);
    descriptorextractor_->compute(dst, K1,
                                  curinvlogo_feature.descriptors_logo_);
    /*
    for (int i = 0;
         i < static_cast<int>(curinvlogo_feature.keypoints_logo_.size());
         i++) {
      curinvlogo_feature.keypoints_logo_[i].pt.x *= zoom_scale;
      curinvlogo_feature.keypoints_logo_[i].pt.y *= zoom_scale;
    }*/
    for (int i=0;
         i < static_cast<int>(K1.size()); i++) {
      KeyPoint k = K1[i];
      k.pt.x = (K1[i].pt.x - left)*zoom_scale;
      k.pt.y = (K1[i].pt.y - top)*zoom_scale;
      curinvlogo_feature.keypoints_logo_.push_back(k);
    }

    // add desc to matcher
    Mat tmpdesc = curlogo_feature.descriptors_logo_.clone();
    // descriptormatcher_1->add(vector<Mat>(1, M2));
    // alllogo_desc.push_back(tmpdesc);
    // logo_desc_combine_.push_back(tmpdesc);

    countkey += curlogo_feature.descriptors_logo_.rows;

    // rootSift by Zhongjun
    RootSift(&(curinvlogo_feature.descriptors_logo_));
    // 抽取特征点附近的点
    Makelogocover(invcurimg_gray, &curinvlogo_feature);
    // 训练特征点的FLANN
    ModeCoverInitial(&curinvlogo_feature);
    // it->second.logo_.release();
    curinvlogo_feature.logo_info_ = it->second;
    logo_feature_list_.insert(
        map<string, LogoFeature>::value_type(Num2Str(logo_feature_list_.size()),
        curinvlogo_feature));
  }

  logo_desc_combine_.release();
  for (map<string, LogoFeature>::iterator it = logo_feature_list_.begin();
      it != logo_feature_list_.end(); it++) {
    for (int i = 0; i < it->second.descriptors_logo_.rows; i++) {
        key_logo_name_.push_back(it->first);
        key_logo_ind_.push_back(i);
    }
    Mat tmpdescriptions = it->second.descriptors_logo_;
    tmpdescriptions.convertTo(tmpdescriptions, CV_8UC1);
    logo_desc_combine_.push_back(tmpdescriptions);
  }

  clock_t start1, finish1;
  start1 = clock();
  SIMPLE_LOG_V1("train tree...");
  m_flann_ = new cv::flann::GenericIndex< Distance_U8 >(
      logo_desc_combine_, cvflann::KDTreeIndexParams(4));
  SIMPLE_LOG_V1("Train tree OK");
  finish1 = clock();
  SIMPLE_LOG_V1("Flann train time: %d ms", static_cast<int>(finish1 - start1));

  // 卸载conf结构中Mat内容以节省空间
  bsetupflag_ = true;
  return 1;
}

vector<LogoDetResult> LogoDetection::RunDet(const Mat &inputimg) {
  SIMPLE_LOG_V1("Start process queryimg");
  double start_sum, time_sum;
  start_sum = clock();
  LogoDetResult curdet_result;
  Mat curquery_imggray;
  vector<LogoDetResult> detlogos;
  // cout << "flag1" << endl;
  // imwrite("testkeypoint.jpg", inputimg);
  QueryFeature curqueryimg_feature;
  if (inputimg.data == NULL || inputimg.empty()) {
    curdet_result.status_ = 2;
    curdet_result.msg_ = "QueryImg is null.";
    SIMPLE_LOG_V1("QueryImg is null.");
    detlogos.push_back(curdet_result);
    return detlogos;
  }
  // cout << "inputimg.type():" << inputimg.type() << endl;
  // cout << "inputimg.channels():" << inputimg.channels() << endl;
  if (inputimg.channels() == 3) {
    cvtColor(inputimg, curquery_imggray, CV_RGB2GRAY);
  } else if (inputimg.channels() == 4) {
    vector<Mat> each_channels;
    Mat middle_img;
    inputimg.convertTo(middle_img, CV_8U);
    split(middle_img, each_channels);
    // cout << "each_channels[0].type()" << each_channels[0].type() << endl;
    middle_img.setTo(Scalar(255, 255, 255), 255 - each_channels[3]);
    cvtColor(middle_img, curquery_imggray, CV_RGBA2RGB);
    // imwrite("test.jpg", curquery_imggray);
  } else {
    curquery_imggray = inputimg.clone();
  }
  // cout << "curquery_imggray.type():" << curquery_imggray.type() << endl;
  double query_zoom_scale = std::min(query_maxsize_/curquery_imggray.cols,
                                     query_maxsize_/curquery_imggray.rows);
  if (query_zoom_scale > 1) {
      query_zoom_scale = 1.2;
  }
  Mat resizeaffine = Mat::eye(3, 3, CV_64F) / query_zoom_scale;
  resizeaffine.ptr<double>(2)[2] = 1;

  curdet_result.resize_haffine_ = resizeaffine;

  resize(curquery_imggray, curquery_imggray,
         Size(query_zoom_scale*curquery_imggray.cols,
         query_zoom_scale*curquery_imggray.rows));
  // cout << "QueryImg Size is " << curquery_imggray.size() << endl;
  curqueryimg_feature.queryimg_ = curquery_imggray;
  /*
  query_detector_->detect(curquery_imggray,
                          curqueryimg_feature.query_keypoints_);
  descriptorextractor_->compute(curquery_imggray,
                                curqueryimg_feature.query_keypoints_,
                                curqueryimg_feature.query_descriptors_);
  */
  Mat empty;
  double start_sift, start_match, time_sift, time_match;
  start_sift = clock();
  query_detector1_(curquery_imggray, empty,
    curqueryimg_feature.query_keypoints_,
    curqueryimg_feature.query_descriptors_);
  SIMPLE_LOG_V1("Sift detect & description cal finish...");
  // imwrite("testkeypoint.jpg", curquery_imggray);
  if (curqueryimg_feature.query_keypoints_.size() == 0) {
    // curdet_result.status_ = 0;
    // curdet_result.msg_ = "QueryImg have no keypoints.";
    SIMPLE_LOG_V1("QueryImg have no keypoints.");
    detlogos.push_back(curdet_result);
    return detlogos;
    // return curdet_result;
  }
  // rootsift by Zhongjun
  RootSift(&(curqueryimg_feature.query_descriptors_));
  time_sift = clock() - start_sift;
  /*
  descriptormatcher_->clear();
  descriptormatcher_->add(vector<Mat>(
        1,
        curqueryimg_feature.query_descriptors_));
  descriptormatcher_->train();
  */
  // important para, need to adjust accoring to logo num
  // 1w use 21, 688 use 3
  // int MatchK = 21;

  // clear match
  for (map<string, LogoFeature>::iterator it =
      logo_feature_list_.begin(); it != logo_feature_list_.end(); it++) {
    it->second.mperLogo_.resize(0);
  }

  // int MatchK = 2;
  int MatchK = 11;
  start_match = clock();
  Mat query_descriptors_cp = curqueryimg_feature.query_descriptors_.clone();
  vector<KeyPoint> query_keypoints_cp(curqueryimg_feature.query_keypoints_);

  curqueryimg_feature.query_descriptors_.convertTo
    (curqueryimg_feature.query_descriptors_, CV_8UC1);

  Mat m_indices(curqueryimg_feature.query_descriptors_.rows,
    MatchK, CV_32S);
  Mat m_dists(curqueryimg_feature.query_descriptors_.rows,
    MatchK, CV_32F);
  m_flann_->knnSearch(curqueryimg_feature.query_descriptors_,
    m_indices, m_dists, MatchK, cvflann::SearchParams(128));

  time_match = clock() - start_match;

  for (int i = 0; i < m_indices.rows; i++) {
    for (int j = 0; j < MatchK; j++) {
      DMatch m;
      m.queryIdx = key_logo_ind_[m_indices.at<unsigned int>(i, j)];
      m.trainIdx = i;
      m.distance = m_dists.at<float>(i, j);
      // cout << i << " " << m_indices.rows <<endl;
      /*
      cout << m.queryIdx << " " <<
        logo_feature_list_[key_logo_name_[m_indices.at<unsigned int>(i, j)]]
        .keypoints_logo_.size() << " " <<
        m.trainIdx << " " <<
        m_indices.rows << " " <<
        curqueryimg_feature.query_descriptors_.rows << " " <<
        curqueryimg_feature.query_keypoints_.size() << endl;
      */
      if (m.distance < siftmatchdistance_threshold_) {
        logo_feature_list_[key_logo_name_[m_indices.at
          <unsigned int>(i, j)]].mperLogo_.push_back(m);
      }
    }
  }

  // 图像没有任何内容Keypoint会为空，导致descriptor的类型异常
  RansacResult maxransacresult;

  // main loop
  int ind_logo = -1;
  curqueryimg_feature.query_descriptors_.convertTo
    (curqueryimg_feature.query_descriptors_, CV_32F);
  SIMPLE_LOG_V1("total logo num = %d",
      static_cast<int>(logo_feature_list_.size()));
  double time_pre = 0, time_bound = 0, time_tri = 0;
  for (map<string, LogoFeature>::iterator it = logo_feature_list_.begin();
    it != logo_feature_list_.end(); it++) {
    // if (it->first != "1016") {
        // continue;
    // }
    // cout << it->first << endl;
    ind_logo++;
    // vector< DMatch > pointmatches;
    string tmpName = it->second.logo_info_.logo_name_;

    vector< DMatch > filter_matches;
    // descriptormatcher_->match(it->second.descriptors_logo_, pointmatches);

    /*
    for (int i_cnt=0 ; i_cnt < static_cast<int>(pointmatches.size());
         i_cnt++) {
      if (pointmatches[i_cnt].distance < siftmatchdistance_threshold_) {
        filter_matches.push_back(pointmatches[i_cnt]);
      }
    }
    */

    filter_matches = it->second.mperLogo_;
    // cout << "filter_matches.size()= " << filter_matches.size() << endl;
    sort(filter_matches.begin(), filter_matches.end(), CompDMatch());
    Mat matchresult;

    // old
    // vector<vector<DMatch> > currentresult0 = ClassicRansac(
    //    filter_matches, curqueryimg_feature,
    //    it->second.logo_info_, it->second);

    // test show match
    /*
    for (unsigned int i = 0; i < filter_matches.size(); i++) {
        // DMatch m = filter_matches[i];
        DMatch m = it->second.mperLogo_[i];
        cout << m.queryIdx << " " <<
            it->second.keypoints_logo_.size() << " " <<
            m.trainIdx << " " <<
            curqueryimg_feature.query_keypoints_.size() << endl;
    }
    */
    // new
    // cout << "ClassicRansac_2Key" << endl;
    // cout << "filter_matches.size() " << filter_matches.size() << endl;
 /*   vector<vector<DMatch> > currentresult0 = ClassicRansac_2Key(
        filter_matches, curqueryimg_feature,
        it->second.logo_info_, it->second);*/

    // RansacResult currentresult;
    // cout << "ClusterRansac" << endl;
 /*   RansacResult currentresult = ClusterRansac(
      currentresult0, curqueryimg_feature,
      it->second.logo_info_, it->second);*/
    // cout << "ClusterRansac OK" << endl;

    cover_query_cnt_ = ind_logo;
    clock_t start_run, end_run, start_run2 = 0, end_run2 = 0;

#define FIRST 1
#define SECOND 2
#if 1
    vector<vector<double> > total_bounds;
    RansacResult currentresult;
    int function_state = FIRST;
    start_run = clock();
    bool return_state = TriangleRansac(
        filter_matches,
        curqueryimg_feature,
        it->second.logo_info_,
        it->second,
        function_state,
        &currentresult,
        &total_bounds);
    end_run = clock();
    time_pre += end_run - start_run;
//    remove the 0 in the nextline to enable prelocate
    if (0 && !return_state) {
      function_state = SECOND;
      it->second.descriptors_logo_.convertTo(
          it->second.descriptors_logo_, CV_32F);
      vector<Mat> tmp_descriptors;
      vector<vector<KeyPoint> > tmp_keypoints;
      start_run2 = clock();
      vector<vector<DMatch> > filter_matches_re =
          BoundsReMatch(total_bounds,
                        curqueryimg_feature,
                        it->second,
                        &descriptormatcher1_,
                        &tmp_descriptors,
                        &tmp_keypoints);
      end_run2 = clock();
      time_bound += end_run2 - start_run2;
      start_run = clock();
      for (int i = 0; i < static_cast<int>(filter_matches_re.size()); i++) {
        total_bounds.clear();
        bounds_query_cnt_ = i;
        curqueryimg_feature.query_descriptors_ = tmp_descriptors[i];
        curqueryimg_feature.query_keypoints_ = tmp_keypoints[i];
        TriangleRansac(filter_matches_re[i],
                       curqueryimg_feature,
                       it->second.logo_info_,
                       it->second,
                       function_state,
                       &currentresult,
                       &total_bounds);
        if (currentresult.find_logo_) {
          /*if(logo_conf_list_[LogoName].neg_info_list.size() > 0){
              //负样本抑制
          }*/
          SIMPLE_LOG_V1("second step ok");
          if (currentresult.best_cover_ratio_ >
              maxransacresult.best_cover_ratio_) {
            maxransacresult = currentresult;
          }
          SIMPLE_LOG_V1("currentresult: %s",
              currentresult.metaconf_.logo_name_.c_str());
          SIMPLE_LOG_V1("best_corr_: %f",
              currentresult.best_corr_);
          SIMPLE_LOG_V1("best_cover_ratio_: %f",
              currentresult.best_cover_ratio_);
          cout << "logoimg_.size:"
              << currentresult.logoimg_.size() << endl;
          LogoDetResult tmpdetresult;
          tmpdetresult.resize_haffine_ = resizeaffine;
          tmpdetresult.SetRansacResult(currentresult);
          detlogos.push_back(tmpdetresult);
          break;
        }
      }
      curqueryimg_feature.query_descriptors_ = query_descriptors_cp;
      curqueryimg_feature.query_keypoints_ = query_keypoints_cp;
      end_run = clock();
      time_tri += end_run - start_run;
    } else {
      if (currentresult.find_logo_) {
        /*if(logo_conf_list_[LogoName].neg_info_list.size() > 0){
            //负样本抑制
        }*/
        SIMPLE_LOG_V1("first step ok");
        if (currentresult.best_cover_ratio_ >
            maxransacresult.best_cover_ratio_) {
          maxransacresult = currentresult;
        }

        SIMPLE_LOG_V1("currentresult: %s",
            currentresult.metaconf_.logo_name_.c_str());
        SIMPLE_LOG_V1("best_corr_: %f",
            currentresult.best_corr_);
        SIMPLE_LOG_V1("best_cover_ratio_: %f",
            currentresult.best_cover_ratio_);
        cout << "logoimg_.size:"
            << currentresult.logoimg_.size() << endl;

        LogoDetResult tmpdetresult;
        tmpdetresult.resize_haffine_ = resizeaffine;
        tmpdetresult.SetRansacResult(currentresult);
        detlogos.push_back(tmpdetresult);
      }
    }
#endif

    sort(detlogos.begin(), detlogos.end(), CompLogoRestult());
    //}
  }
  if (detlogos.size() == 0) {
    detlogos.push_back(curdet_result);
  }
  time_sum = clock() - start_sum;
  SIMPLE_LOG_V1("Time info: ");
  cout << "tim_query_sift: " << time_sift / CLOCKS_PER_SEC << "s" << endl
       << "time_match: " << time_match / CLOCKS_PER_SEC << "s" << endl
       << "tim_first_tri:  " << time_pre / CLOCKS_PER_SEC << "s" << endl
       << "tim_bound:      " << time_bound / CLOCKS_PER_SEC << "s" << endl
       << "tim_second_tri: " << time_tri / CLOCKS_PER_SEC << "s" << endl
       << "tim_sum:" << time_sum / CLOCKS_PER_SEC << "s" << endl;

  return detlogos;
  // curdet_result.SetRansacResult(maxransacresult);
  // return curdet_result;
}
int LogoDetection::ModeCoverInitial(LogoFeature *logoimg_feature) {
  logoimg_feature->logocover_ = logoimg_feature->logoimg_;
  // 计算Model Cover的模版
  Size logosize = logoimg_feature->logocover_.size();
  cv::Scalar mean0, std0;
  Mat block;
  // logocover_mask_ = vector<Mat>(3, Mat::zeros(maskrows, maskcols, CV_8U));
  int size = model_cover_size_;

  int maskrows, maskcols;
  if ((logosize.height - size) < 0) {
    maskrows = 0;
  } else {
    maskrows = floor((logosize.height - size) / size) + 1;
  }
  if ((logosize.width - size) < 0) {
    maskcols = 0;
  } else {
    maskcols = floor((logosize.width - size) / size) + 1;
  }
  // logoimg_feature.logocover_mask_ = Mat::zeros(maskrows, maskcols, CV_8U);
  Mat tmp = Mat::zeros(maskrows, maskcols, CV_8U);
  Mat stdmatrix =  Mat::zeros(maskrows, maskcols, CV_64F);
  vector<double> stdvector;
  stdvector.reserve(maskrows * maskcols);
  for (int i_cnt=0; i_cnt < 1; i_cnt ++) {
    logoimg_feature->logocover_mask_.push_back(tmp.clone());
  }
  // cout << "maskrows "<<maskrows<<"maskcols "<<maskcols <<endl;
  int row_index, col_index;
  for (int i = 0; i < logosize.height - size + 1; i = i + size) {
    for (int j = 0; j < logosize.width - size + 1; j = j + size) {
      block = logoimg_feature->logocover_(Range(i, i + size),
                                          Range(j, j + size));
      meanStdDev(block, cv::noArray(), std0);
      col_index = j/size;
      row_index = i/size;
      stdmatrix.ptr<double>(row_index)[col_index] = std0[0];
      stdvector.push_back(std0[0]);
    }
  }
  std::sort(stdvector.begin(), stdvector.end(), std::greater<double>());
  // int stdthreshold = stdvector[floor(stdvector.size()/10)];
  // choose thresh to get top %
  int stdthreshold = stdvector[floor(stdvector.size()*0.9)];
  if (stdthreshold < 10) {
    stdthreshold = 10;
  }
  logoimg_feature->logocover_mask_[0] = (stdmatrix > stdthreshold)/255;
  // std_thresh = std_thresh * std_thresh_ratio;
  // }
  // for(int iter = 0; iter < 1; iter ++ ){
  //    cout << logoimg_feature.logocover_mask_[iter] << endl;
  // }
  return 1;
}

vector< vector<DMatch> > LogoDetection::ClassicRansac_2Key(
    const vector< DMatch > &filtermatches,
    const QueryFeature &queryimg_feature,
    const LogoConf &logoimg_conf,
    const LogoFeature &logoimg_feature) {
  vector< vector<DMatch> > detresult;
  vector< DMatch > filtermatches1;
  if (filtermatches.size() < 50) {
    filtermatches1 = filtermatches;
  } else {
    for (int i = 0; i < 50; i++) {
      filtermatches1.push_back(filtermatches[i]);
    }
  }
  int knummatch = filtermatches1.size();
  if (knummatch < 3) {
    return detresult;
  }
  double thresh_project = 40;

  vector<int> currentmatchidx;
  DMatch currenmatch;
  vector<vector<double> > matrixaffine(2, vector<double>(3, 0));
  vector<Point2f> matchLogopoints(3, Point2f(0.0, 0.0));
  vector<Point2f> matchquerypoints(3, Point2f(0.0, 0.0));
  Mat HAffine = Mat::zeros(3, 3, CV_64F);

  unsigned int I0, I1;
  unsigned int IL0, IL1;
  unsigned int IQ0, IQ1;

  // int size1 = logoimg_feature.keypoints_logo_.size();
  // int size2 = queryimg_feature.query_keypoints_.size();
  // int ind_delete[knummatch];
  vector<int> ind_delete;
  ind_delete.resize(knummatch);
  for (unsigned int i = 0; i < filtermatches1.size(); i++) {
    ind_delete[i] = 0;
  }

  // double ratio_threshlowerlimit = 0.75;
  // double ratio_threshuplimit = 1.5;
  for (I0 = 0; I0 < filtermatches1.size() - 2; I0++) {
    if (ind_delete[I0] >= 2) {
      continue;
    }
    // float d01, d02, d12, D01, D02, D12;
    // float x1, x2, x3, y1, y2, y3;
    float x1, x2, y1, y2;
    // float X1, X2, X3, Y1, Y2, Y3;
    float X1, X2, Y1, Y2;
    float m11, m12, m13, m21, m22, m23;
    m12 = 0.f;
    m21 = 0.f;

    currenmatch = filtermatches1[I0];
    IL0 = currenmatch.queryIdx;
    IQ0 = currenmatch.trainIdx;
    matchLogopoints[0] = logoimg_feature.keypoints_logo_[IL0].pt;
    matchquerypoints[0] = queryimg_feature.query_keypoints_[IQ0].pt;
    x1 = matchLogopoints[0].x;
    y1 = matchLogopoints[0].y;
    X1 = matchquerypoints[0].x;
    Y1 = matchquerypoints[0].y;
    for (I1 = I0 + 1; I1 < filtermatches1.size() - 1; I1++) {
      if (ind_delete[I1] >= 2) {
        continue;
      }
      currenmatch = filtermatches1[I1];
      IL1 = currenmatch.queryIdx;
      IQ1 = currenmatch.trainIdx;
      matchLogopoints[1] = logoimg_feature.keypoints_logo_[IL1].pt;
      matchquerypoints[1] = queryimg_feature.query_keypoints_[IQ1].pt;
      x2 = matchLogopoints[1].x;
      y2 = matchLogopoints[1].y;
      X2 = matchquerypoints[1].x;
      Y2 = matchquerypoints[1].y;

      // cal m
      float x12 = x1 - x2;
      float X12 = X1 - X2;
      float y12 = y1 - y2;
      float Y12 = Y1 - Y2;

      if (abs(x12) < 2 && abs(y12) < 2) {
        continue;
      }
      if ( (abs(x12) + abs(y12) <30 ) ) {
        // continue;
      }
      // estimate of m need protect div/0
      float A1 = 1 / x12;
      float B1 = -1 / y12;
      // float C1 = y2 / y12 - x2 / x12;
      float A2 = 1 / X12;
      float B2 = -1 / Y12;
      // float C2 = Y2 / Y12 - Y2 / Y12;

      float cos0 = (A1 * A2 + B1 * B2) /
        sqrt((A1 * A1 + B1 * B1) * (A2 * A2 + B2 * B2));
      float flag1 = x12 * X12 + y12 * Y12;
      if (flag1 >= 0) {
        cos0 = abs(cos0);
      } else {
        cos0 = -abs(cos0);
      }

      float sin0 = sqrt(1 - cos0 * cos0);  // can be neg
      float s = (X1 - X2) / (cos0 * x1 - cos0 * x2 -
        sin0 * y1 + sin0 * y2);
      float x0 = -(X1 + cos0 * cos0 * s * s * x1 +
        s * s * sin0 * sin0 * x2 - X1 * cos0 * s -
        Y2 * s * sin0 - cos0 * s* x1 + s * sin0 * y1 -
        cos0 * s * s * sin0 * y1 + cos0 * s * s * sin0 *y2) /
        (cos0 * cos0 * s * s - 2 * cos0 * s + s *s * sin0 * sin0 + 1);
      float y0 = -(Y2 + cos0 * cos0 * s * s * y2 +
        s * s * sin0 * sin0 * y1 - Y2 * cos0 * s +
        X1 * s * sin0 - cos0 * s* y2 - s * sin0 * x2 -
        cos0 * s * s * sin0 * x1 + cos0 * s * s * sin0 * x2) /
        (cos0 * cos0 * s * s - 2 * cos0 * s + s *s * sin0 * sin0 + 1);

      m11 = s * cos0;
      m12 = -1 * s * sin0;
      m13 = s * cos0 * x0 - s * sin0 * y0 - x0;
      m21 = s * sin0;
      m22 = s * cos0;
      m23 = s * sin0 * x0 + s * cos0 * y0 - y0;

      matrixaffine[0][0] = m11;
      matrixaffine[0][1] = m12;
      matrixaffine[0][2] = m13;
      matrixaffine[1][0] = m21;
      matrixaffine[1][1] = m22;
      matrixaffine[1][2] = m23;

      if (CheckHomo(matrixaffine, logoimg_feature.logoimg_,
          queryimg_feature.queryimg_) != 1) {
        continue;
      }

      float a = 1 / x12;
      float b = -1 / y12;
      float c = y2 / y12 - x2 / x12;
      float A = b * b - a * a;
      float B = a * a + b * b;

      vector <DMatch> M;
      vector <DMatch> M1;
      vector <int> ind_flag;
      vector <int> ind_flag1;
      for (unsigned int i = 0; i < filtermatches1.size(); i++) {
        if (ind_delete[i] >= 2) {
          continue;
        }
        // cout << i << " " << filtermatches1.size() << " " << endl;
        DMatch m = filtermatches1[i];

        /*
        cout << m.queryIdx << " " <<
            logoimg_feature.keypoints_logo_.size() << " " <<
            m.trainIdx << " " <<
            queryimg_feature.query_keypoints_.size() << endl;
        */
        // DMatch m = filtermatches1[i];
        float x1 = logoimg_feature.keypoints_logo_[m.queryIdx].pt.x;
        float y1 = logoimg_feature.keypoints_logo_[m.queryIdx].pt.y;
        float X1 = queryimg_feature.query_keypoints_[m.trainIdx].pt.x;
        float Y1 = queryimg_feature.query_keypoints_[m.trainIdx].pt.y;
        float X2 = m11 * x1 + m13;
        float Y2 = m22 * y1 + m23;
        if (abs(X1 - X2) < thresh_project && abs(Y1 - Y2) < thresh_project) {
          M.push_back(m);
          ind_flag.push_back(i);
        }
        x1 = (A * x1 - 2 * a * b * y1 - 2 * a * c) / B;
        y1 = (-A * y1 - 2 * a * b * x1 - 2 * b * c) / B;
        X2 = m11 * x1 + m13;
        Y2 = m22 * y1 + m23;
        if (abs(X1 - X2) < thresh_project && abs(Y1 - Y2) < thresh_project) {
          M1.push_back(m);
          ind_flag1.push_back(i);
        }
      }
      if (M.size() > 2) {
        detresult.push_back(M);
      }
      if (M1.size() > 2) {
        detresult.push_back(M1);
      }

      if (M.size() > 2) {
        for (unsigned int j = 0; j < ind_flag.size(); j++) {
          ind_delete[ind_flag[j]] += 1;
        }
      }
      if (M1.size() > 2) {
        for (unsigned int j = 0; j < ind_flag1.size(); j++) {
          ind_delete[ind_flag1[j]] += 1;
        }
      }
    }
  }
  return detresult;
}

vector< vector<DMatch> > LogoDetection::ClassicRansac(
    const vector< DMatch > &filter_matches,
    const QueryFeature &queryimg_feature,
    const LogoConf &logoimg_conf,
    const LogoFeature &logoimg_feature) {
  vector< vector<DMatch> > detresult;
  vector< DMatch > filter_matches1 = filter_matches;
  // SIMPLE_LOG("Ransac Start!");
  // cout <<  "Enter ClassicRansac..." << endl;
  // cout << logoimg_conf.logo_name << endl;
  // cout << "filter_matches: " << filter_matches.size() << endl;
  int knummatch = filter_matches1.size();
  if (knummatch < 3) {
    return detresult;
  }
  // double best_cover_ratio = 0;
  // double best_corr = -1;
  // double better_corr = -1;

  // int max_iterations_homo = 300;
  // int max_iterations_wcg = 300;
  // int max_iterations_corr = 30;
  // int max_iterations_coverratio = 10;
  double thresh_project = 30;

  vector<int> currentmatchidx;
  DMatch currenmatch;
  KeyPoint k_logo, k_query;
  vector<vector<double> > matrix_affine(2, vector<double>(3, 0));
  vector<Point2f> matchlogo_points(3, Point2f(0.0, 0.0));
  vector<Point2f> matchquery_points(3, Point2f(0.0, 0.0));
  Mat haffine = Mat::zeros(3, 3, CV_64F);
  // double initialthird[3] = {0.0, 0.0, 1.0};
  // imwrite("test_Query.jpg", drawQuery);

  // cout << "knummatch: "<< knummatch << endl;
  Mat warped_query;
  Mat logosmall;
  Mat warped_querysmall;

  // logo只用初始化一遍
  // int ModelSize = 200;

  for (/*int FindRansacCnt=0,*/ int indexcnt =0, iterations_homo = 0;
       /*iterations_wcg = 0,*/  /*iterations_corr = 0,*/
       /*iterations_coverratio = 0*/
        indexcnt < static_cast<int>(affine_index_list_.size());) {
        knummatch = filter_matches1.size();
    if (indexcnt < static_cast<int>(affine_index_list_.size())) {
      currentmatchidx = affine_index_list_[indexcnt];
    } else {
      break;
    }
    indexcnt++;
    if (currentmatchidx[2] >= knummatch) {
      continue;
    }
    if ((currentmatchidx[0] + currentmatchidx[1] + currentmatchidx[2])
        >= knummatch *3 - 6) {
      break;
    }

    currenmatch = filter_matches1[currentmatchidx[0]];
    k_logo = logoimg_feature.keypoints_logo_[currenmatch.queryIdx];
    k_query = queryimg_feature.query_keypoints_[currenmatch.trainIdx];
    // k_logo = logoimg_feature.keypoints_logo_[currenmatch.trainIdx];
    // k_query = queryimg_feature.keypoints[currenmatch.queryIdx];

    matchlogo_points[0] = k_logo.pt;
    matchquery_points[0] = k_query.pt;

    currenmatch = filter_matches1[currentmatchidx[1]];
    k_logo = logoimg_feature.keypoints_logo_[currenmatch.queryIdx];
    k_query = queryimg_feature.query_keypoints_[currenmatch.trainIdx];
    // k_logo = logoimg_feature.keypoints_logo_[currenmatch.trainIdx];
    // k_query = queryimg_feature.keypoints[currenmatch.queryIdx];
    matchlogo_points[1]= k_logo.pt;
    matchquery_points[1] = k_query.pt;

    currenmatch = filter_matches1[currentmatchidx[2]];
    k_logo = logoimg_feature.keypoints_logo_[currenmatch.queryIdx];
    k_query = queryimg_feature.query_keypoints_[currenmatch.trainIdx];
    // k_logo = logoimg_feature.keypoints_logo_[currenmatch.trainIdx];
    // k_query = queryimg_feature.keypoints[currenmatch.queryIdx];
    matchlogo_points[2]= k_logo.pt;
    matchquery_points[2] = k_query.pt;
    // cout << "logo "<< k_logo.pt << endl;
    // cout << "query " << k_query.pt << endl;
    if (CheckMatch(matchlogo_points, matchquery_points) != 1) {
      continue;
    }
    if (SolveAffine(matchlogo_points, matchquery_points,
          &matrix_affine) != 1) {
      continue;
    }
    // cout << currentmatchidx[0] <<" "
    //  << currentmatchidx[1] << " " << currentmatchidx[2] << endl;

    if (CheckHomo(matrix_affine, logoimg_feature.logoimg_,
          queryimg_feature.queryimg_) != 1) {
      continue;
    }

    iterations_homo++;
    // cout << currentmatchidx[0] <<" "
    //  << currentmatchidx[1] << " " << currentmatchidx[2] << endl;
    double m11 = matrix_affine[0][0];
    double m12 = matrix_affine[0][1];
    double m13 = matrix_affine[0][2];
    double m21 = matrix_affine[1][0];
    double m22 = matrix_affine[1][1];
    double m23 = matrix_affine[1][2];

    vector <DMatch> tmp_matrix;
    vector <int> ind_flag;
    for (int i = 0; i < static_cast<int>(filter_matches1.size()); i++) {
      DMatch m = filter_matches1[i];
      double x1 = logoimg_feature.keypoints_logo_[m.queryIdx].pt.x;
      double y1 = logoimg_feature.keypoints_logo_[m.queryIdx].pt.y;
      double query_x1 = queryimg_feature.query_keypoints_[m.trainIdx].pt.x;
      double query_y1 = queryimg_feature.query_keypoints_[m.trainIdx].pt.y;
      double query_x2 = m11*x1+m12*y1+m13;
      double query_y2 = m21*x1+m22*y1+m23;

      if (abs(query_x1 - query_x2) < thresh_project
          && abs(query_y1 - query_y2) < thresh_project) {
        tmp_matrix.push_back(m);
        ind_flag.push_back(i);
      }
    }
    if (tmp_matrix.size() > 2) {
      detresult.push_back(tmp_matrix);
      for (int j = 0; j < static_cast<int>(tmp_matrix.size()); j++) {
        // flag[ind_flag[j]] = true;
        vector<DMatch>::iterator iter =
            filter_matches1.begin() + ind_flag[j] - j;
        filter_matches1.erase(iter);
      }
    }
  }
    return detresult;
}

RansacResult LogoDetection::LogoRansac(
    const vector< DMatch > &filter_matches,
    const QueryFeature &queryimg_feature,
    const LogoConf &logoimg_conf,
    const LogoFeature &logoimg_feature) {
  RansacResult detresult;
  // SIMPLE_LOG("Ransac Start!");
  int knummatch = filter_matches.size();
  if (knummatch < 3) {
    return detresult;
  }
  double best_cover_ratio = 0;
  double best_corr = -1;
  double better_corr = -1;

  int max_iterations_homo = 300;
  int max_iterations_wcg = 300;
  int max_iterations_corr = 30;
  int max_iterations_coverratio = 10;

  vector<int> currentmatchidx;
  DMatch currenmatch;
  KeyPoint k_logo, k_query;
  vector<vector<double> > matrix_affine(2, vector<double>(3, 0));
  vector<Point2f> matchlogo_points(3, Point2f(0.0, 0.0));
  vector<Point2f> matchquery_points(3, Point2f(0.0, 0.0));
  Mat haffine = Mat::zeros(3, 3, CV_64F);
  double initialthird[3] = {0.0, 0.0, 1.0};

  // cout << "knummatch: "<< knummatch << endl;
  Mat warped_query;
  Mat logosmall;
  Mat warped_querysmall;

  // logo只用初始化一遍
  // int ModelSize = 200;

  for (int indexcnt =0, iterations_homo = 0, iterations_wcg = 0,
       iterations_corr = 0, iterations_coverratio = 0;
       indexcnt < static_cast<int>(affine_index_list_.size()) &&
       iterations_homo < max_iterations_homo &&
       iterations_wcg < max_iterations_wcg &&
       iterations_corr < max_iterations_corr &&
       iterations_coverratio < max_iterations_coverratio;) {
    if (indexcnt < static_cast<int>(affine_index_list_.size())) {
      currentmatchidx = affine_index_list_[indexcnt];
    } else {
      break;
    }
    indexcnt++;
    if (currentmatchidx[2] >= knummatch) {
      continue;
    }
    if ((currentmatchidx[0] + currentmatchidx[1]
        + currentmatchidx[2]) >= knummatch *3 - 6) {
      break;
    }

    currenmatch = filter_matches[currentmatchidx[0]];
    k_logo = logoimg_feature.keypoints_logo_[currenmatch.queryIdx];
    k_query = queryimg_feature.query_keypoints_[currenmatch.trainIdx];
    // k_logo = logoimg_feature.keypoints_logo_[currenmatch.trainIdx];
    // k_query = queryimg_feature.keypoints[currenmatch.queryIdx];

    matchlogo_points[0]= k_logo.pt;
    matchquery_points[0] = k_query.pt;

    currenmatch = filter_matches[currentmatchidx[1]];
    k_logo = logoimg_feature.keypoints_logo_[currenmatch.queryIdx];
    k_query = queryimg_feature.query_keypoints_[currenmatch.trainIdx];
    // k_logo = logoimg_feature.keypoints_logo_[currenmatch.trainIdx];
    // k_query = queryimg_feature.keypoints[currenmatch.queryIdx];
    matchlogo_points[1]= k_logo.pt;
    matchquery_points[1] = k_query.pt;

    currenmatch = filter_matches[currentmatchidx[2]];
    k_logo = logoimg_feature.keypoints_logo_[currenmatch.queryIdx];
    k_query = queryimg_feature.query_keypoints_[currenmatch.trainIdx];
    // k_logo = logoimg_feature.keypoints_logo_[currenmatch.trainIdx];
    // k_query = queryimg_feature.keypoints[currenmatch.queryIdx];
    matchlogo_points[2] = k_logo.pt;
    matchquery_points[2] = k_query.pt;
    // cout << "logo "<< k_logo.pt << endl;
    // cout << "query " << k_query.pt << endl;
    // cout << "flag2" <<endl;
    if (CheckMatch(matchlogo_points, matchquery_points) != 1) {
      continue;
    }

    if (SolveAffine(matchlogo_points,
                    matchquery_points,
                    &matrix_affine) != 1) {
      continue;
    }

    if (CheckHomo(matrix_affine,
                  logoimg_feature.logoimg_,
                  queryimg_feature.queryimg_) != 1) {
      continue;
    }
    iterations_homo++;

    haffine.row(0) = Mat(1 , 3, CV_64F, &matrix_affine[0].front()) + 0.0;
    haffine.row(1) = Mat(1 , 3, CV_64F, &matrix_affine[1].front()) + 0.0;
    haffine.row(2) = Mat(1 , 3, CV_64F, initialthird) + 0.0;
    Mat haffineallinverse = haffine.inv();
    Mat haffineinverse = haffineallinverse(Range(0, 2), Range(0, 3));
    // cout << "haffine" << haffine << endl;
    // cout << queryimg_feature.queryimg_.size() << endl;
    // cout << logoimg_feature.logoimg.size() << endl;
    // Mat warped_query;
    warpAffine(queryimg_feature.queryimg_, warped_query,
        haffineinverse, logoimg_feature.logoimg_.size(), cv::INTER_NEAREST);

    double logocorr = CalCorr(warped_query, logoimg_feature);
    if (logocorr > better_corr) {
      better_corr = logocorr;
    }
    if (logocorr < logoimg_conf.corr_thresh_) {
      continue;
    }
    iterations_corr++;
    resize(warped_query, warped_querysmall,
        logoimg_feature.logocover_.size(), 0, 0, cv::INTER_NEAREST);

    double coverratio = Match2Block(logoimg_feature.logocover_,
                                    warped_querysmall,
                                    logoimg_feature.logocover_mask_);
    iterations_coverratio++;
    if (coverratio >= best_cover_ratio) {
      best_cover_ratio = coverratio;
      best_corr = logocorr;
      if (best_corr > logoimg_conf.corr_thresh_ &&
        best_cover_ratio > logoimg_conf.cover_ratio_thresh_) {
        detresult.best_corr_ = best_corr;
        detresult.best_cover_ratio_ = best_cover_ratio;
        detresult.max_corr_ = better_corr;
        detresult.m11_ = matrix_affine[0][0];
        detresult.m12_ = matrix_affine[0][1];
        detresult.m13_ = matrix_affine[0][2];
        detresult.m21_ = matrix_affine[1][0];
        detresult.m22_ = matrix_affine[1][1];
        detresult.m23_ = matrix_affine[1][2];
        detresult.find_logo_ = true;
        detresult.logo_index_ = logoimg_conf.logo_index_;
        cout << "logo_name is "<< logoimg_conf.logo_name_ <<endl;
        // 不用返回warp后的小图
        detresult.best_warped_query_small_ = warped_querysmall.clone();
        // detresult.logo_name_ = logoimg_conf.logo_name_;
        // detresult.brand_name_ = logoimg_conf.brand_name_;
        detresult.logoimg_ = logoimg_feature.logoimg_;
        detresult.metaconf_ = logoimg_conf;
        break;
      }
    }
  }
  return detresult;
}

RansacResult LogoDetection::ClusterRansac(
    const vector< vector <DMatch > > &filter_matches0,
    const QueryFeature &queryimg_feature,
    const LogoConf &logoimg_conf,
    const LogoFeature &logoimg_feature) {
  RansacResult detresult;
  // SIMPLE_LOG("Ransac Start!");
  // cout << logoimg_conf.logo_name << endl;
  // cout << "filter_matches0: " << filter_matches0.size() << endl;
  double best_cover_ratio = 0;
  double best_corr = -1;
  double better_corr = -1;

  int max_iterations_homo = 300;
  int max_iterations_wcg = 300;
  int max_iterations_corr = 30;
  int max_iterations_coverratio = 10;

  vector<int> currentmatchidx;
  DMatch currenmatch;
  KeyPoint k_logo, k_query;
  vector<vector<double> > matrix_affine(2, vector<double>(3, 0));
  vector<Point2f> matchlogo_points(3, Point2f(0.0, 0.0));
  vector<Point2f> matchquery_points(3, Point2f(0.0, 0.0));
  Mat haffine = Mat::zeros(3, 3, CV_64F);
  double initialthird[3] = {0.0, 0.0, 1.0};

  // cout << "knummatch: "<< knummatch << endl;
  Mat warped_query;
  Mat logosmall;
  Mat warped_querysmall;

  for (int ind_cluster = 0;
       ind_cluster < static_cast<int>(filter_matches0.size());
       ind_cluster++) {
    vector <DMatch > filter_matches = filter_matches0[ind_cluster];
    int knummatch = filter_matches.size();
    if (knummatch < 3) {
      return detresult;
    }

    // logo只用初始化一遍
    // int ModelSize = 200;
    // int Modelrows = (int)(logoimg_feature.logoimg.rows
    // * ModelSize/logoimg_feature.logoimg.cols);
    // int Modelcols = ModelSize;
    // Size dsize = Size(Modelcols, Modelrows);
    // resize(logoimg_feature.logoimg,
    // logosmall, dsize, 0, 0, INTER_NEAREST);

    for (int indexcnt =0, iterations_homo = 0, iterations_wcg = 0,
         iterations_corr = 0, iterations_coverratio = 0;
      indexcnt < static_cast<int>(affine_index_list_.size()) &&
      iterations_homo < max_iterations_homo &&
      iterations_wcg < max_iterations_wcg &&
      iterations_corr < max_iterations_corr &&
      iterations_coverratio < max_iterations_coverratio;) {
      knummatch = filter_matches.size();
      currentmatchidx.resize(3);

      if (indexcnt < static_cast<int>(affine_index_list_.size())) {
          currentmatchidx = affine_index_list_[indexcnt];
      } else {
        break;
      }
      indexcnt++;
      if (currentmatchidx[2] >= knummatch) {
        continue;
      }
      if ((currentmatchidx[0] + currentmatchidx[1] + currentmatchidx[2])
          >= knummatch *3 - 6) {
        break;
      }
      // cout << currentmatchidx[0] <<" "
      // << currentmatchidx[1] << " " <<currentmatchidx[2]<<endl;
      currenmatch = filter_matches[currentmatchidx[0]];
      k_logo = logoimg_feature.keypoints_logo_[currenmatch.queryIdx];
      k_query = queryimg_feature.query_keypoints_[currenmatch.trainIdx];
      // k_logo = logoimg_feature.keypoints_logo_[currenmatch.trainIdx];
      // k_query = queryimg_feature.keypoints[currenmatch.queryIdx];

      matchlogo_points[0]= k_logo.pt;
      matchquery_points[0] = k_query.pt;

      currenmatch = filter_matches[currentmatchidx[1]];
      k_logo = logoimg_feature.keypoints_logo_[currenmatch.queryIdx];
      k_query = queryimg_feature.query_keypoints_[currenmatch.trainIdx];
      // k_logo = logoimg_feature.keypoints_logo_[currenmatch.trainIdx];
      // k_query = queryimg_feature.keypoints[currenmatch.queryIdx];
      matchlogo_points[1] = k_logo.pt;
      matchquery_points[1] = k_query.pt;

      currenmatch = filter_matches[currentmatchidx[2]];
      k_logo = logoimg_feature.keypoints_logo_[currenmatch.queryIdx];
      k_query = queryimg_feature.query_keypoints_[currenmatch.trainIdx];
      // k_logo = logoimg_feature.keypoints_logo_[currenmatch.trainIdx];
      // k_query = queryimg_feature.keypoints[currenmatch.queryIdx];
      matchlogo_points[2]= k_logo.pt;
      matchquery_points[2] = k_query.pt;

      if (CheckMatch(matchlogo_points, matchquery_points) != 1) {
        continue;
      }

      if (SolveAffine(matchlogo_points,
                      matchquery_points,
                      &matrix_affine) != 1) {
        continue;
      }

      if (CheckHomo(matrix_affine,
                    logoimg_feature.logoimg_,
                    queryimg_feature.queryimg_) != 1) {
        continue;
      }
      iterations_homo++;

      // cout << currentmatchidx[0] << " " << currentmatchidx[1]
      //   << " " << currentmatchidx[2] << endl;
      haffine.row(0) = Mat(1 , 3, CV_64F, &matrix_affine[0].front()) + 0.0;
      haffine.row(1) = Mat(1 , 3, CV_64F, &matrix_affine[1].front()) + 0.0;
      haffine.row(2) = Mat(1 , 3, CV_64F, initialthird) + 0.0;
      Mat haffineallinverse = haffine.inv();
      Mat haffineinverse = haffineallinverse(Range(0, 2), Range(0, 3));
      // cout << "haffine" << haffine << endl;
      // cout << queryimg_feature.queryimg_.size() << endl;
      // cout << logoimg_feature.logoimg.size() << endl;
      // Mat warped_query;
      warpAffine(queryimg_feature.queryimg_, warped_query,
                 haffineinverse, logoimg_feature.logocover_.size(),
                 cv::INTER_NEAREST);

      double logocorr = CalCorr(warped_query, logoimg_feature);
      if (logocorr > better_corr) {
        better_corr = logocorr;
      }
      if (logocorr < logoimg_conf.corr_thresh_) {
        continue;
      }
      iterations_corr++;
      // int ModelSize = 200;
      // int Modelcols = ModelSize;
      // Size dsize = Size(Modelcols, Modelrows);
      // Mat logosmall;
      // resize(logoimg_feature.logoimg,
      // logosmall, dsize, 0, 0, INTER_NEAREST);
      // Mat warped_querysmall;
      // resize(warped_query, warped_querysmall,
      // logoimg_feature.logocover_.size(), 0, 0, INTER_NEAREST);
      warped_querysmall = warped_query;
      // cout <<"warped_query size is: "<< warped_query.size()<<endl;
      // cout << "logoimg_feature.logocover_ size is: "
      //     << logoimg_feature.logocover_.size() << endl;
      //  cout << "warped_querysmall size is: " <<
      //  warped_querysmall.size() << endl;
      double coverratio = Match2Block(logoimg_feature.logocover_,
          warped_querysmall, logoimg_feature.logocover_mask_);
      // cout << "coverratio: " << coverratio << endl;
      iterations_coverratio++;
      if (coverratio >= best_cover_ratio) {
        best_cover_ratio = coverratio;
        best_corr = logocorr;
        // if(best_corr > logoimg_conf.corr_thresh
        // && best_cover_ratio > logoimg_conf.cover_ratio_thresh){
        if (best_cover_ratio > logoimg_conf.cover_ratio_thresh_) {
          detresult.best_corr_ = best_corr;
          detresult.best_cover_ratio_ = best_cover_ratio;
          detresult.max_corr_ = better_corr;
          detresult.m11_ = matrix_affine[0][0];
          detresult.m12_ = matrix_affine[0][1];
          detresult.m13_ = matrix_affine[0][2];
          detresult.m21_ = matrix_affine[1][0];
          detresult.m22_ = matrix_affine[1][1];
          detresult.m23_ = matrix_affine[1][2];
          detresult.find_logo_ = true;
          detresult.logo_index_ = logoimg_conf.logo_index_;
          // cout << "logo_name was "<< logoimg_conf.logo_name <<endl;
          // 不用返回warp后的小图
          detresult.best_warped_query_small_ = warped_querysmall.clone();
          // detresult.logo_name_ = logoimg_conf.logo_name_;
          // detresult.brand_name_ = logoimg_conf.brand_name_;
          detresult.logoimg_ = logoimg_feature.logoimg_;
          detresult.metaconf_ = logoimg_conf;
          // detresult.brand_id_ = logoimg_conf.brand_id_;
          return detresult;
        }
      }
    }
  }

  return detresult;
}
vector<vector<DMatch> > LogoDetection::BoundsReMatch(
    const vector<vector<double> >&total_bounds,
    const QueryFeature &queryimg_feature,
    const LogoFeature &logofeature_info,
    Ptr<DescriptorMatcher> *descriptormatcher1,
    vector<Mat> *tmp_descriptors,
    vector<vector<KeyPoint> > *tmp_keypoints) {
  vector<DMatch> point_matches;
  vector<vector<DMatch> > filter_matches_re;
  for (int kk = 0; kk < static_cast<int>(total_bounds.size()); kk++) {
    int pt_len = queryimg_feature.query_keypoints_.size();
    vector<ImgKeyPoint> vec_points;
    for (int ii = 0; ii < pt_len; ii++) {
      ImgKeyPoint single_point(queryimg_feature.query_keypoints_[ii], ii);
      vec_points.push_back(single_point);
    }
    sort(vec_points.begin(), vec_points.end(), CompXImgKeyPoint());
    int left_idx = BinarySearchX(
        vec_points, 0, pt_len - 1, total_bounds[kk][0]);
    int right_idx = BinarySearchX(
        vec_points, 0, pt_len - 1, total_bounds[kk][1]);
    vector<ImgKeyPoint> vec_points2(
        vec_points.begin() + left_idx, vec_points.begin() + right_idx);
    int pt_len2 = vec_points2.size();
    sort(vec_points2.begin(), vec_points2.end(), CompYImgKeyPoint());
    int up_idx = BinarySearchY(
        vec_points2, 0, pt_len2 - 1, total_bounds[kk][2]);
    int down_idx = BinarySearchY(
        vec_points2, 0, pt_len2 - 1, total_bounds[kk][3]);
    vector<ImgKeyPoint> vec_points3(
        vec_points2.begin() + up_idx, vec_points2.begin() + down_idx);

    (*descriptormatcher1)->clear();
    Mat tmp_desc, single_tmp_desc;
    vector<KeyPoint> new_keypoints;
    for (int ii = 0; ii < static_cast<int>(vec_points3.size()); ii++) {
      queryimg_feature.query_descriptors_.row(vec_points3[ii].idx_).copyTo(
          single_tmp_desc);
      tmp_desc.push_back(single_tmp_desc);
      new_keypoints.push_back(vec_points3[ii].key_point_);
    }
    (*tmp_descriptors).push_back(tmp_desc);
    (*tmp_keypoints).push_back(new_keypoints);
    (*descriptormatcher1)->add(vector<Mat>(1, tmp_desc));
    (*descriptormatcher1)->match(logofeature_info.descriptors_logo_,
                              point_matches);
    vector<DMatch> single_filter_matches;
    for (int i_cnt = 0;
         i_cnt < static_cast<int>(point_matches.size());
         i_cnt++) {
      if (point_matches[i_cnt].distance < 400)
        single_filter_matches.push_back(point_matches[i_cnt]);
    }
    filter_matches_re.push_back(single_filter_matches);
  }
  return filter_matches_re;
}
// #define PRINT_DEBUG 1
// #define DRAW_IMAGE 1
bool LogoDetection::TriangleRansac(
    const vector <DMatch > &filter_matches,
    const QueryFeature &queryimg_feature,
    const LogoConf &logoimg_conf,
    const LogoFeature &logoimg_feature,
    int function_state,
    RansacResult *detresult,
    vector<vector<double> >* total_bounds) {
  double best_cover_ratio = 0;
  double best_corr = -1;
  double better_corr = -1;
  double logocorr = 0.0;
  Mat warped_query;
  Mat logosmall;
  Mat warped_querysmall;

  DMatch cur_match1, cur_match2;
  int num_match = filter_matches.size();
  num_match = num_match > 100 ? 100 : num_match;
  vector <Point2f> edgelogo_points(2, Point2f(0.0f, 0.0f));
  vector <Point2f> edgequery_points(2, Point2f(0.0f, 0.0f));
  vector <Point2f> trilogo_points(3, Point2f(0.0f, 0.0f));
  vector <Point2f> triquery_points(3, Point2f(0.0f, 0.0f));
  vector <double> desclogo_oris(2, 0.0f);
  vector <double> descquery_oris(2, 0.0f);
  vector <double> edgelogo_oris(2, 0.0f);
  vector <double> edgequery_oris(2, 0.0f);
  vector <double> trilogo_oris(3, 0.0f);
  vector <double> triquery_oris(3, 0.0f);
  KeyPoint k_logo, k_query;
  double edge_ori_inter_diff_sum = 0.0f;
  double edge_ori_intra_diff_std = 0.0f;
  vector <Edge> valid_edges;
  // Edge single_edge;
  vector <int> valid_nodes;

  double nodelogo_meter, nodequery_meter;
  double tmp_nodelogo_meter, tmp_nodequery_meter;
  double nodeintermeter_ratio1, nodeintermeter_ratio2;
  double edgelen_inter_ratio;
  double edgelogo_len, edgequery_len;
  double edgeintrameter_logo_ratio, edgeintrameter_query_ratio;
#ifdef PRINT_DEBUG
    size_t name_len = logoimg_conf.logo_name_.size();
    string ref_logo_name = logoimg_conf.logo_name_.substr(0, name_len - 1);
    size_t sepa_idx = input_test_.find_first_of("/", 0);
    string query_logo_name = input_test_.substr(0, sepa_idx - 1);
#endif
  for (int i = 0; i < num_match; ++i) {
    cur_match1 = filter_matches[i];
    k_logo = logoimg_feature.keypoints_logo_[cur_match1.queryIdx];
    k_query = queryimg_feature.query_keypoints_[cur_match1.trainIdx];
    edgelogo_points[0] = k_logo.pt;
    edgequery_points[0] = k_query.pt;
    desclogo_oris[0] = k_logo.angle;
    descquery_oris[0] = k_query.angle;
    nodelogo_meter = k_logo.size;
    nodequery_meter = k_query.size;
    tmp_nodelogo_meter = nodelogo_meter;
    tmp_nodequery_meter = nodequery_meter;
    nodeintermeter_ratio1 = nodelogo_meter / nodequery_meter;
    for (int j = i + 1; j < num_match; ++j) {
      cur_match2 = filter_matches[j];
      k_logo = logoimg_feature.keypoints_logo_[cur_match2.queryIdx];
      k_query = queryimg_feature.query_keypoints_[cur_match2.trainIdx];
      edgelogo_points[1] = k_logo.pt;
      edgequery_points[1] = k_query.pt;
      desclogo_oris[1] = k_logo.angle;
      descquery_oris[1] = k_query.angle;
      nodelogo_meter = k_logo.size;
      nodequery_meter = k_query.size;
      nodeintermeter_ratio2 = nodelogo_meter / nodequery_meter;
      edgeintrameter_logo_ratio = tmp_nodelogo_meter / nodelogo_meter;
      edgeintrameter_query_ratio = tmp_nodequery_meter / nodequery_meter;
      EdgeOri(edgelogo_points, desclogo_oris, &edgelogo_oris);
      EdgeOri(edgequery_points, descquery_oris, &edgequery_oris);
      edge_ori_inter_diff_sum =
        EdgeOriInterDiffSum(edgelogo_oris, edgequery_oris);
      edge_ori_intra_diff_std =
        EdgeOriIntraDiffStd(edgelogo_oris, edgequery_oris);

      edgelogo_len = EdgeLen(edgelogo_points);
      edgequery_len = EdgeLen(edgequery_points);

      if (edgelogo_len < 1e-6 || edgequery_len < 1e-6)
        continue;
      edgelen_inter_ratio = edgelogo_len / edgequery_len;
      if (edgelogo_len < 7
        || edge_ori_inter_diff_sum > 65 || edge_ori_intra_diff_std > 15
        || nodeintermeter_ratio2 < nodeintermeter_ratio1 * 0.7
        || nodeintermeter_ratio2 > nodeintermeter_ratio1 * 1.4
        || edgeintrameter_query_ratio < edgeintrameter_logo_ratio * 0.7
        || edgeintrameter_query_ratio > edgeintrameter_logo_ratio * 1.4)
        continue;
      Edge single_edge;
      single_edge.idx1_ = i;
      single_edge.idx2_ = j;
      single_edge.len_ratio_ = edgelen_inter_ratio;
      valid_edges.push_back(single_edge);
      if (valid_nodes.size() == 0 || valid_nodes.back() != i) {
        valid_nodes.push_back(i);
      }
    }
  }

#if DRAW_IMAGE
    /*
    Mat img_draw_match;
    drawMatches(logoimg_feature.logoimg_,
                logoimg_feature.keypoints_logo_,
                queryimg_feature.queryimg_,
                queryimg_feature.query_keypoints_,
                *edge_matches,
                img_draw_match);
    if (query_logo_name == ref_logo_name) {
        imwrite("prelocate_img_line1/edge_match_" + Num2Str(cur_query_cnt_)
                + "_" + Num2Str(cover_query_cnt_) + "_"
                + Num2Str(bounds_query_cnt_)
                + ".jpg", img_draw_match);
    }
    */
#endif
#ifdef PRINT_DEBUG
  if (query_logo_name == ref_logo_name) {
    printf("--cover_query = %d\n", cover_query_cnt_);
    printf("----valid_node_num = %zu, valid_edge_num = %zu\n",
        valid_nodes.size(), valid_edges.size());
  }
#endif
  map<int, vector<int> > node_adj_nodes;
  for (int i = 0; i < static_cast<int>(valid_edges.size()); i++) {
    node_adj_nodes[valid_edges[i].idx1_].push_back(valid_edges[i].idx2_);
  }
  // node union-find method
  vector <int> node_idxs(num_match + 1, 0);
  for (int i = 0; i < static_cast<int>(node_idxs.size()); i++)
    node_idxs[i] = i;
  for (int i = 0; i < static_cast<int>(valid_edges.size()); i++)
    NodeUnion(valid_edges[i].idx1_, valid_edges[i].idx2_, &node_idxs);
  // find out edge sets
  map<int, vector<Edge> > node_adj_edges;
  for (int i = 0; i < static_cast<int>(valid_edges.size()); i++) {
    int cur_idx1 = NodeFind(valid_edges[i].idx1_, &node_idxs);
    if (node_adj_edges.find(cur_idx1) == node_adj_edges.end()) {
      vector <Edge> tmp_edges;
      // tmp_edges.push_back(valid_edges[i]);
      // node_adj_edges[cur_idx1] = tmp_edges;
      // node_adj_edges[cur_idx1].clear();
      // node_adj_edges[cur_idx1].assign(tmp_edges.begin(),
      // tmp_edges.end());
      node_adj_edges.insert(map<int, vector<Edge> >::value_type(cur_idx1,
            tmp_edges));
    }
    node_adj_edges[cur_idx1].push_back(valid_edges[i]);
  }
  vector <int> four_nodes(4, 0);
  vector <int> tri_nodes(3, 0);
  vector <double> trilogo_angles_oris(6, 0.0f);
  vector <double> triquery_angles_oris(6, 0.0f);
  vector <double> cp_trilogo_angles_oris(3, 0.0f);
  vector <double> cp_triquery_angles_oris(3, 0.0f);
  vector <double> trilogo_edgelens(3, 0.0f);
  vector <double> triquery_edgelens(3, 0.0f);
  vector<vector<double> > matrix_affine(2, vector<double>(3, 0));
  vector <set <int> > total_matches_sets;
  vector<vector<vector<double> > > total_affine_matrixs;
  vector <int> total_para_vote_cnt;
  vector <AffinePara> total_affine_paras;
  int total_max_vote = 0;
  unordered_set <int> triangle_hash;
  map <int, vector <Edge> >::iterator node2edges_iter;
  Mat haffine = Mat::zeros(3, 3, CV_64F);
  double initialthird[3] = {0.0, 0.0, 1.0};
#ifdef PRINT_DEBUG
  if (query_logo_name == ref_logo_name) {
    printf("----group_num = %zu\n", node_adj_edges.size());
  }
#endif
  int group_cnt = -1;
  for (node2edges_iter = node_adj_edges.begin();
       node2edges_iter != node_adj_edges.end();
       node2edges_iter++) {
    group_cnt++;
    vector <Edge> edge_groups;
    edge_groups.assign(node2edges_iter->second.begin(),
        node2edges_iter->second.end());
    // vector <Edge> edge_groups(node2edges_iter->second);
    // vector <Edge> edge_groups = node2edges_iter->second;
    /*
    for (int i_cnt = 0; i_cnt <
        static_cast<int>(node2edges_iter->second.size()); i_cnt++) {
      cout << "i_cnt:" << i_cnt << "value"
        << edge_groups[i_cnt].len_ratio_ << " "
        << "idx1_:" << edge_groups[i_cnt].idx1_
        << "idx2_:" << edge_groups[i_cnt].idx2_
        << endl;
    }*/
    if (edge_groups.size() < 2)  continue;
    // sort from bigger ratio to small ratio
    std::sort(edge_groups.begin(), edge_groups.end(), EdgeRatioCmp());

    /*
    for (int i_cnt = 0; i_cnt < static_cast<int>(edge_groups.size()); i_cnt++) {
      cout << "i_cnt:" << i_cnt << "value:"
        << edge_groups[i_cnt].len_ratio_ << " "
        << "idx1_:" << edge_groups[i_cnt].idx1_
        << "idx2_:" << edge_groups[i_cnt].idx2_
        << endl;
    }
    */

    vector <AffinePara> affine_paras;
    vector<vector<vector<double> > > affine_matrixs;
    vector <int> para_vote_cnt;
    vector <set <int> > matches_sets;
    int cur_max_vote = 0;
    AffinePara single_para, back_para;
    for (int i = 0; i < (static_cast<int>(edge_groups.size()) - 1); i++) {
      if (edge_groups[i].len_ratio_ * 0.9 > edge_groups[i + 1].len_ratio_
        || edge_groups[i].len_ratio_ < 0.5)
        continue;
      bool valid_tri_flag = false;
      for (int j = i + 1;
           j < static_cast<int>(edge_groups.size())
        && edge_groups[i].len_ratio_ * 0.9 < edge_groups[j].len_ratio_;
           j++) {
        four_nodes[0] = edge_groups[i].idx1_;
        four_nodes[1] = edge_groups[i].idx2_;
        four_nodes[2] = edge_groups[j].idx1_;
        four_nodes[3] = edge_groups[j].idx2_;
        sort(four_nodes.begin(), four_nodes.end());
        int hash1 = four_nodes[0]*10001 + four_nodes[2]*101 + four_nodes[3];
        int hash2 = four_nodes[0]*10001 + four_nodes[1]*101 + four_nodes[3];
        if (four_nodes[0] == four_nodes[1]) {
          if (triangle_hash.find(hash1) == triangle_hash.end()) {
            triangle_hash.insert(hash1);
            tri_nodes[0] = four_nodes[0];
            tri_nodes[1] = four_nodes[2];
            tri_nodes[2] = four_nodes[3];
            valid_tri_flag = true;
            break;
          }
        } else if (four_nodes[1] == four_nodes[2]
                || four_nodes[2] == four_nodes[3]) {
          if (triangle_hash.find(hash2) == triangle_hash.end()) {
            triangle_hash.insert(hash2);
            tri_nodes[0] = four_nodes[0];
            tri_nodes[1] = four_nodes[1];
            tri_nodes[2] = four_nodes[3];
            valid_tri_flag = true;
            break;
          }
        }
      }
      if (!valid_tri_flag)  continue;
      for (int k = 0; k < 3; k++) {
        cur_match1 = filter_matches[tri_nodes[k]];
        k_logo = logoimg_feature.keypoints_logo_[cur_match1.queryIdx];
        k_query = queryimg_feature.query_keypoints_[cur_match1.trainIdx];
        trilogo_points[k] = k_logo.pt;
        triquery_points[k] = k_query.pt;
        trilogo_oris[k] = k_logo.angle;
        triquery_oris[k] = k_query.angle;
      }
      bool logo_valid = TriangleAngleOri(trilogo_points,
                                         trilogo_oris,
                                         &trilogo_angles_oris);
      bool query_valid = TriangleAngleOri(triquery_points,
                                         triquery_oris,
                                         &triquery_angles_oris);
      double minlogoangles = 0, maxlogoangles = 0;
      double minqueryangles = 0, maxqueryangles = 0;
      if (logo_valid && query_valid) {
        double angle_inter_diff_sum =
            TriangleAngleInterDiffSum(trilogo_angles_oris,
                                      triquery_angles_oris);
        double ori_inter_diff_std =
            TriangleOriInterDiffStd(trilogo_angles_oris,
                                    triquery_angles_oris);
        if (angle_inter_diff_sum > 20 || ori_inter_diff_std > 15)
          continue;
        for (int j = 0; j < 3; j++) {
          cp_trilogo_angles_oris[j] = trilogo_angles_oris[j] > 180 ?
              360 - trilogo_angles_oris[j] : trilogo_angles_oris[j];
          cp_triquery_angles_oris[j] = triquery_angles_oris[j] > 180 ?
              360 - triquery_angles_oris[j] : triquery_angles_oris[j];
        }
        sort(cp_trilogo_angles_oris.begin(),
             cp_trilogo_angles_oris.begin() + 3);
        sort(cp_triquery_angles_oris.begin(),
             cp_triquery_angles_oris.begin() + 3);
        minlogoangles = cp_trilogo_angles_oris[0];
        maxlogoangles = cp_trilogo_angles_oris[2];
        minqueryangles = cp_triquery_angles_oris[0];
        maxqueryangles = cp_triquery_angles_oris[2];
      //  if (maxlogoangles > 165 || minlogoangles < 5
      //  || maxqueryangles > 165 || minqueryangles < 5)
      //    continue;
      } else {
        continue;
      }
      TriangleEdgeLen(trilogo_points, &trilogo_edgelens);
      TriangleEdgeLen(triquery_points, &triquery_edgelens);
      if (logo_valid && query_valid)
        CutTrianglePointsVerti(trilogo_edgelens,
                               triquery_edgelens,
                               &trilogo_points,
                               &triquery_points);
      sort(trilogo_edgelens.begin(), trilogo_edgelens.end());
      sort(triquery_edgelens.begin(), triquery_edgelens.end());
      double minlogolen = trilogo_edgelens[0];
      double maxlogolen = trilogo_edgelens[2];
      double minquerylen = triquery_edgelens[0];
      double maxquerylen = triquery_edgelens[2];
      double tot_ratio;
      int join_num = 3;
      if (logo_valid && query_valid) {
        if (maxlogoangles > 165 || minlogoangles < 5
        || maxqueryangles > 165 || minqueryangles < 5) {
          if (maxlogolen < 12 || maxquerylen < 5)
            continue;
          if (SolveSimi(trilogo_points, triquery_points, &matrix_affine) != 1)
            continue;
          join_num = 2;
          tot_ratio = maxlogolen / maxquerylen;
        } else {
          if (maxlogolen < 16 || minlogolen < 5
          || maxquerylen < 8 || minquerylen < 2)
            continue;
          if (SolveAffine(trilogo_points, triquery_points, &matrix_affine) != 1)
            continue;
          tot_ratio = (trilogo_edgelens[0] + trilogo_edgelens[1]
                      + trilogo_edgelens[2]) /
                      (triquery_edgelens[0] + triquery_edgelens[1]
                      + triquery_edgelens[2]);
        }
      }
      single_para.rotate_angle_ = SolveRotSimple(matrix_affine);
      single_para.trans_x_ = matrix_affine[0][2];
      single_para.trans_y_ = matrix_affine[1][2];
      single_para.len_ratio_ = tot_ratio;
      if (affine_paras.size() != 0) {
        bool unify_flag = false;
        for (int j = 0; j < static_cast<int>(affine_paras.size()); j++) {
          back_para = affine_paras[j];
          if (abs(single_para.rotate_angle_ - back_para.rotate_angle_) < 8  // 3
          && abs(single_para.trans_x_ - back_para.trans_x_)
             < (18 / back_para.len_ratio_)  // 8
          && abs(single_para.trans_y_ - back_para.trans_y_)
             < (18 / back_para.len_ratio_)  // 8
          && back_para.len_ratio_ * 0.9 < single_para.len_ratio_ ) {
            back_para.rotate_angle_ = (
                             back_para.rotate_angle_ * para_vote_cnt[j]
                          + single_para.rotate_angle_) / (para_vote_cnt[j] + 1);
            back_para.trans_x_ = (back_para.trans_x_ * para_vote_cnt[j]
                             + single_para.trans_x_) / (para_vote_cnt[j] + 1);
            back_para.trans_y_ = (back_para.trans_y_ * para_vote_cnt[j]
                             + single_para.trans_y_) / (para_vote_cnt[j] + 1);
            back_para.len_ratio_ = (back_para.len_ratio_ * para_vote_cnt[j]
                             + single_para.len_ratio_) / (para_vote_cnt[j] + 1);
            para_vote_cnt[j]++;
            unify_flag = true;
            if (para_vote_cnt[j] > cur_max_vote) {
              cur_max_vote = para_vote_cnt[j];
            }
            for (int jj = 0; jj < join_num; jj++)
              matches_sets[j].insert(tri_nodes[jj]);
            break;
          }
        }
        if (unify_flag)
          continue;
      }
      haffine.row(0) = Mat(1 , 3, CV_64F, &matrix_affine[0].front()) + 0.0;
      haffine.row(1) = Mat(1 , 3, CV_64F, &matrix_affine[1].front()) + 0.0;
      haffine.row(2) = Mat(1 , 3, CV_64F, initialthird) + 0.0;
      Mat haffineallinverse = haffine.inv();
      Mat haffineinverse = haffineallinverse(Range(0, 2), Range(0, 3));
      warpAffine(queryimg_feature.queryimg_, warped_query,
                 haffineinverse, logoimg_feature.logocover_.size(),
                 cv::INTER_NEAREST);

      logocorr = CalCorr(warped_query, logoimg_feature);
      if (logocorr > better_corr) {
        better_corr = logocorr;
      }
      if (logocorr < 0.1) {
        continue;
      }
      affine_paras.push_back(single_para);
      para_vote_cnt.push_back(1);
      set <int> single_matches_set;
      for (int jj = 0; jj < join_num; jj++)
        single_matches_set.insert(tri_nodes[jj]);
      matches_sets.push_back(single_matches_set);
      affine_matrixs.push_back(matrix_affine);
    }
#ifdef PRINT_DEBUG
    if (query_logo_name == ref_logo_name) {
      printf("------group_cnt = %d, para_vote_cnt\n",
          group_cnt);
      for (int kk = 0; kk < static_cast<int>(para_vote_cnt.size()); kk++)
        printf("%d:%zu   ", para_vote_cnt[kk], matches_sets[kk].size());
      printf("\n");
    }
#endif
    vector <int> vote_idxs;    int max_vote = -1;
    for (int i = 0; i < static_cast<int>(matches_sets.size()); i++) {
      if (para_vote_cnt[i] > max_vote) {
        max_vote = para_vote_cnt[i];
        vote_idxs.clear(); vote_idxs.push_back(i);
        total_max_vote = max(total_max_vote, max_vote);
      } else if (para_vote_cnt[i] == max_vote) {
        vote_idxs.push_back(i);
      }
    }
    for (int j = 0; j < static_cast<int>(vote_idxs.size()); j++) {
      total_para_vote_cnt.push_back(para_vote_cnt[vote_idxs[j]]);
      total_matches_sets.push_back(matches_sets[vote_idxs[j]]);
      total_affine_paras.push_back(affine_paras[vote_idxs[j]]);
      total_affine_matrixs.push_back(affine_matrixs[vote_idxs[j]]);
    }
  }
  // deal with bound and group match
  vector<vector<double> > bounds_result;
  double bounds_init[4] = {9999999.0, -1.0, 9999999.0, -1.0};
  int best_coverratio_idx = -1;
  for (int i = 0; i < static_cast<int>(total_matches_sets.size()); i++) {
    vector <Point2f> multilogo_points;
    vector <Point2f> multiquery_points;
    vector <DMatch> tmpp_matches;
#ifdef DRAW_IMAGE
    Mat img_draw_match;
#endif
    set <int>::iterator match_sets_iter;
    for (match_sets_iter = total_matches_sets[i].begin();
         match_sets_iter != total_matches_sets[i].end(); match_sets_iter++) {
      cur_match1 = filter_matches[*match_sets_iter];
      k_logo = logoimg_feature.keypoints_logo_[cur_match1.queryIdx];
      k_query = queryimg_feature.query_keypoints_[cur_match1.trainIdx];
      multilogo_points.push_back(k_logo.pt);
      multiquery_points.push_back(k_query.pt);
      tmpp_matches.push_back(cur_match1);
    }
    int pt_len = multilogo_points.size();
    if (pt_len > 3)
      SolveMultiAffine(multilogo_points, multiquery_points, &matrix_affine);
    else if (pt_len == 3)
      SolveAffine(multilogo_points, multiquery_points, &matrix_affine);
    else if (pt_len == 2)
      SolveSimi(multilogo_points, multiquery_points, &matrix_affine);
    else
      continue;
    haffine.row(0) = Mat(1 , 3, CV_64F, &matrix_affine[0].front()) + 0.0;
    haffine.row(1) = Mat(1 , 3, CV_64F, &matrix_affine[1].front()) + 0.0;
    haffine.row(2) = Mat(1 , 3, CV_64F, initialthird) + 0.0;
    Mat haffineallinverse = haffine.inv();
    Mat haffineinverse = haffineallinverse(Range(0, 2), Range(0, 3));
    warpAffine(queryimg_feature.queryimg_, warped_query,
               haffineinverse, logoimg_feature.logocover_.size(),
               cv::INTER_NEAREST);
    double coverratio = Match2Block(logoimg_feature.logocover_,
        warped_query, logoimg_feature.logocover_mask_,
        total_affine_paras[i].len_ratio_);
#ifdef DRAW_IMAGE
    /*
    drawMatches(logoimg_feature.logoimg_,
                logoimg_feature.keypoints_logo_,
                queryimg_feature.queryimg_,
                queryimg_feature.query_keypoints_,
                tmpp_matches,
                img_draw_match);
    if (query_logo_name == ref_logo_name) {
      if (coverratio > logoimg_conf.cover_ratio_thresh_)
        imwrite("prelocate_img_line1/Match_got_" + Num2Str(cur_query_cnt_)
                + "_" + Num2Str(cover_query_cnt_) + "_"
                + Num2Str(bounds_query_cnt_) + "_" + Num2Str(i)
                + ".jpg", img_draw_match);
      else
        imwrite("prelocate_img_line1/Match_nogot_" + Num2Str(cur_query_cnt_)
                + "_" + Num2Str(cover_query_cnt_) + "_"
                + Num2Str(bounds_query_cnt_) + "_" + Num2Str(i)
                + ".jpg", img_draw_match);
    }
    */
#endif
#ifdef PRINT_DEBUG
    /*
    if (query_logo_name == ref_logo_name) {
      if (coverratio > logoimg_conf.cover_ratio_thresh_)
        printf("--------points = %zu, pass, coverratio = %f, thresh = %f\n",
            multilogo_points.size(),
            coverratio,
            logoimg_conf.cover_ratio_thresh_);
      else
        printf("--------points = %zu, not pass, coverratio = %f, thresh = %f\n",
            multilogo_points.size(),
            coverratio,
            logoimg_conf.cover_ratio_thresh_);
    }
    */
#endif
    if (coverratio >= best_cover_ratio) {
      best_coverratio_idx = i;
      best_cover_ratio = coverratio;
      // if(best_corr > logoimg_conf.corr_thresh
      // && best_cover_ratio > logoimg_conf.cover_ratio_thresh){
      if (best_cover_ratio > logoimg_conf.cover_ratio_thresh_) {
        (*detresult).best_corr_ = best_corr;
        (*detresult).best_cover_ratio_ = best_cover_ratio;
        (*detresult).max_corr_ = better_corr;
        (*detresult).m11_ = matrix_affine[0][0];
        (*detresult).m12_ = matrix_affine[0][1];
        (*detresult).m13_ = matrix_affine[0][2];
        (*detresult).m21_ = matrix_affine[1][0];
        (*detresult).m22_ = matrix_affine[1][1];
        (*detresult).m23_ = matrix_affine[1][2];
        (*detresult).find_logo_ = true;
        (*detresult).logo_index_ = logoimg_conf.logo_index_;
        // cout << "logo_name was "<< logoimg_conf.logo_name <<endl;
        // 不用返回warp后的小图
        // (*detresult).best_warped_query_small_ = warped_querysmall.clone();
        // (*detresult).logo_name_ = logoimg_conf.logo_name_;
        // (*detresult).brand_name_ = logoimg_conf.brand_name_;
        (*detresult).logoimg_ = logoimg_feature.logoimg_;
        // (*detresult).brand_id_ = logoimg_conf.brand_id_;
        (*detresult).metaconf_ = logoimg_conf;
        return true;
      }
    }
    if (function_state == FIRST) {
      vector <double> bounds(bounds_init, bounds_init + 4);
      BoundPointAffine(total_affine_matrixs[i],
                       logoimg_feature.logoimg_,
                       queryimg_feature.queryimg_,
                       &bounds);
      bounds_result.push_back(bounds);
    }
  }
  int bounds_len = static_cast<int>(bounds_result.size());
  if (function_state == SECOND) {
    return false;
  } else {
    if (bounds_len <= 0)
      return true;
  }
  if (best_coverratio_idx != -1)
    (*total_bounds).push_back(bounds_result[best_coverratio_idx]);
  /*
  vector<bool> bounds_flag(bounds_len, true);
  for (int i = 0; i < bounds_len; i++) {
    if (bounds_flag[i]) {
      double cxi = (bounds_result[i][0] + bounds_result[i][1]) / 2;
      double cyi = (bounds_result[i][2] + bounds_result[i][3]) / 2;
      for (int j = i + 1; j < bounds_len; j++) {
        if (cxi < bounds_result[j][1] && cxi > bounds_result[j][0]
        &&  cyi < bounds_result[j][3] && cyi > bounds_result[j][2]) {
          bounds_flag[j] = false;
          bounds_result[i][0] = min(bounds_result[i][0],
                                    bounds_result[j][0]);
          bounds_result[i][1] = max(bounds_result[i][1],
                                    bounds_result[j][1]);
          bounds_result[i][2] = min(bounds_result[i][2],
                                    bounds_result[j][2]);
          bounds_result[i][3] = max(bounds_result[i][3],
                                    bounds_result[j][3]);
        }
      }
    }
  }
  for (int i = 0; i < bounds_len; i++) {
    if (bounds_flag[i]) {
      (*total_bounds).push_back(bounds_result[i]);
#ifdef DRAW_IMAGE
      Point rook_points[1][4];
      rook_points[0][0] = Point(bounds_result[i][0], bounds_result[i][2]);
      rook_points[0][1] = Point(bounds_result[i][1], bounds_result[i][2]);
      rook_points[0][2] = Point(bounds_result[i][0], bounds_result[i][3]);
      rook_points[0][3] = Point(bounds_result[i][1], bounds_result[i][3]);
      const Point* ppt[1] = { rook_points[0] };
      int npt[] = {4};
      polylines(queryimg_cp, ppt, npt, 1, 1, CV_RGB(0, 255, 0), 2, 8, 0);
#endif
    }
  }
  */
  return false;
}
void LogoDetection::PointAffine(
    const vector<vector <double> > &matrix_affine,
    const double &ori_x, const double &ori_y,
    double *x, double *y) {
  *x = matrix_affine[0][0] * ori_x
      + matrix_affine[0][1] * ori_y
      + matrix_affine[0][2];
  *y = matrix_affine[1][0] * ori_x
      + matrix_affine[1][1] * ori_y
      + matrix_affine[1][2];
  return;
}
void LogoDetection::BoundPointAffine(
                      const vector<vector <double> > &matrix_affine,
                      const Mat& logoimg, const Mat& queryimg,
                      vector <double> *bounds) {
  double logo_width = static_cast<double>(logoimg.cols);
  double logo_height = static_cast<double>(logoimg.rows);
  double query_width = static_cast<double>(queryimg.cols);
  double query_height = static_cast<double>(queryimg.rows);
  double x, y, X, Y;
  double bleft = (*bounds)[0], bright = (*bounds)[1];
  double bup = (*bounds)[2], bdown = (*bounds)[3];
  vector <vector <double> > cp_haffine = matrix_affine;
  x = 0.0f, y = 0.0f;
  PointAffine(cp_haffine, x, y, &X, &Y);
  bleft = min(bleft, X);  bright = max(bright, X);
  bup = min(bup, Y); bdown = max(bdown, Y);

  x = logo_width, y = 0.0f;
  PointAffine(cp_haffine, x, y, &X, &Y);
  bleft = min(bleft, X);  bright = max(bright, X);
  bup = min(bup, Y); bdown = max(bdown, Y);

  x = 0.0f, y = logo_height;
  PointAffine(cp_haffine, x, y, &X, &Y);
  bleft = min(bleft, X);  bright = max(bright, X);
  bup = min(bup, Y); bdown = max(bdown, Y);

  x = logo_width, y = logo_height;
  PointAffine(cp_haffine, x, y, &X, &Y);
  bleft = min(bleft, X);  bright = max(bright, X);
  bup = min(bup, Y); bdown = max(bdown, Y);

  double ibleft = max(0.0, bleft);
  double ibright = min(query_width - 1, bright);

  double ibup = max(0.0, bup);
  double ibdown = min(query_height - 1, bdown);

  (*bounds)[0] = ibleft; (*bounds)[1] = ibright;
  (*bounds)[2] = ibup;   (*bounds)[3] = ibdown;
  return;
}
int LogoDetection::CheckMatch(const vector<Point2f> &matchlogo_points,
                              const vector<Point2f> &matchquery_points) {
  double x1, x2, x3, y1, y2, y3, qx1, qx2, qx3, qy1, qy2, qy3;
  x1 = matchlogo_points[0].x;
  y1 = matchlogo_points[0].y;

  x2 = matchlogo_points[1].x;
  y2 = matchlogo_points[1].y;

  x3 = matchlogo_points[2].x;
  y3 = matchlogo_points[2].y;

  qx1 = matchquery_points[0].x;
  qy1 = matchquery_points[0].y;

  qx2 = matchquery_points[1].x;
  qy2 = matchquery_points[1].y;

  qx3 = matchquery_points[2].x;
  qy3 = matchquery_points[2].y;

  double d1 = sqrt((x1-x2)*(x1-x2)+(y1-y2)*(y1-y2));
  double d2 = sqrt((x1-x3)*(x1-x3)+(y1-y3)*(y1-y3));
  double d3 = sqrt((x3-x2)*(x3-x2)+(y3-y2)*(y3-y2));

  double qd1 = sqrt((qx1-qx2)*(qx1-qx2)+(qy1-qy2)*(qy1-qy2));
  double qd2 = sqrt((qx1-qx3)*(qx1-qx3)+(qy1-qy3)*(qy1-qy3));
  double qd3 = sqrt((qx3-qx2)*(qx3-qx2)+(qy3-qy2)*(qy3-qy2));

  double disthresh_logo = 3*3;
  double disthresh_query = 2*2;
  if (d1 < disthresh_logo || d2 < disthresh_logo
    || d3 < disthresh_logo || qd1 < disthresh_query
    || qd2 < disthresh_query || qd3 < disthresh_query) {
    return 0;
  }
  double trianglelogocircle = d1 + d2 + d3;
  double trianglequerycircle = qd1 + qd2 + qd3;
  double circleratio = trianglelogocircle/trianglequerycircle;

  double d11 = qd1 * circleratio;
  double d21 = qd2 * circleratio;
  double d31 = qd3 * circleratio;
  double ratio_threshlowerlimit = 0.75;
  double ratio_threshuplimit = 1.5;
  if (d1< d11 * ratio_threshlowerlimit  || d1 > d11 * ratio_threshuplimit
    || d2 < d21*ratio_threshlowerlimit  || d2 > d21 * ratio_threshuplimit
    || d3 < d31 * ratio_threshlowerlimit
    || d3 > d31 * ratio_threshuplimit) {
    return 0;
  }
  return 1;
}

double LogoDetection::CalCorr(
    const Mat &warped_query,
    const LogoFeature &logofeature_info) {
  double corr = -1;
  double queryvaluemean = 0;
  int countcover = logofeature_info.feature_point_list_.size();
  vector<FeaturePointInfo> fpi = logofeature_info.feature_point_list_;
  // 重复分配可作为成员private变量
  vector<double> queryvalue(countcover, 0);
  for (int i_cnt = 0; i_cnt < countcover; i_cnt++) {
    queryvalue[i_cnt] = warped_query.ptr<uchar>
      (fpi[i_cnt].y_)[fpi[i_cnt].x_];
    queryvaluemean += queryvalue[i_cnt];
  }
  queryvaluemean = queryvaluemean/countcover;

  double sumxy = 0;
  double sumxx = 0;
  double sumyy = 0;

  double querydiff, logodiff;
  for (int i_cnt=0; i_cnt < countcover; i_cnt++) {
    querydiff = queryvalue[i_cnt] - queryvaluemean;
    logodiff = fpi[i_cnt].value_ - logofeature_info.feature_point_valuemean_;
    sumxy += querydiff * logodiff;
    sumxx += querydiff * querydiff;
    sumyy += logodiff * logodiff;
  }
  if (sumxx * sumyy > 0) {
    corr = sumxy/sqrt(sumxx * sumyy);
  }
  return corr;
}

int LogoDetection::SolveAffine(
    const vector<Point2f> &matchlogo_points,
    const vector<Point2f> &matchquery_points,
    vector<vector<double> > *matrix_affine) {
  double x1, x2, x3, y1, y2, y3, qx1, qx2, qx3, qy1, qy2, qy3;
  double m11, m12, m13, m21, m22, m23;
  x1 = matchlogo_points[0].x;
  y1 = matchlogo_points[0].y;

  x2 = matchlogo_points[1].x;
  y2 = matchlogo_points[1].y;

  x3 = matchlogo_points[2].x;
  y3 = matchlogo_points[2].y;

  qx1 = matchquery_points[0].x;
  qy1 = matchquery_points[0].y;

  qx2 = matchquery_points[1].x;
  qy2 = matchquery_points[1].y;

  qx3 = matchquery_points[2].x;
  qy3 = matchquery_points[2].y;

  double b = x1*y2 - x2*y1 - x1*y3 + x3*y1 + x2*y3 - x3*y2;
  if (b == 0) {
    return 0;
  }
  // 法1,直接求解三元一次方程
  m11 =(qx1*y2 - qx2*y1 - qx1*y3 + qx3*y1 + qx2*y3 - qx3*y2)/b;
  m12 =-(qx1*x2 - qx2*x1 - qx1*x3
      + qx3*x1 + qx2*x3 - qx3*x2)/b;
  m13 =(qx1*x2*y3 - qx1*x3*y2 - qx2*x1*y3
      + qx2*x3*y1 + qx3*x1*y2 - qx3*x2*y1)/b;
  m21 =(qy1*y2 - qy2*y1 - qy1*y3 + qy3*y1
      + qy2*y3 - qy3*y2)/b;
  m22 =-(qy1*x2 - qy2*x1 - qy1*x3 + qy3*x1
      + qy2*x3 - qy3*x2)/b;
  m23 =(qy1*x2*y3 - qy1*x3*y2 - qy2*x1*y3
      + qy2*x3*y1 + qy3*x1*y2 - qy3*x2*y1)/b;
  (*matrix_affine)[0][0] = m11;
  (*matrix_affine)[0][1] = m12;
  (*matrix_affine)[0][2] = m13;
  (*matrix_affine)[1][0] = m21;
  (*matrix_affine)[1][1] = m22;
  (*matrix_affine)[1][2] = m23;
  // cout<< m11 << " " << m12 << " " << m13 <<endl;
  // cout<< m21 << " " << m22 << " " << m23 <<endl;
  // 法2,矩阵广义逆求解(可能计算开销较大)
  return 1;
}

int LogoDetection::CheckHomo(const vector<vector<double> > &matrix_affine,
                             const Mat &logo,
                             const Mat &query) {
  double logo_x1, logo_y1, logo_x2, logo_y2,
    logo_x3, logo_y3, logo_x4, logo_y4;
  double query_x1, query_y1, query_x2, query_y2,
    query_x3, query_y3, query_x4, query_y4;
  double m11, m12, m13, m21, m22, m23;
  double logosize_thresh, logo_x_threshlowerlimit,
    logo_y_threshlowerlimit, logo_x_threshupperlimit,
    logo_y_threshupperlimit;

  m11 = matrix_affine[0][0];
  m12 = matrix_affine[0][1];
  m13 = matrix_affine[0][2];
  m21 = matrix_affine[1][0];
  m22 = matrix_affine[1][1];
  m23 = matrix_affine[1][2];
  // 可优化，对同一logo不用重复计算可作为输入传入
  logosize_thresh = 100;
  logo_x_threshlowerlimit = 0 - logosize_thresh;
  logo_y_threshlowerlimit = 0 - logosize_thresh;
  logo_x_threshupperlimit = query.cols + logosize_thresh;
  logo_y_threshupperlimit = query.rows + logosize_thresh;
  // 可优化，对同一logo不用重复计算
  logo_x1 = 0, logo_y1 = 0;
  logo_x2 = 0, logo_y2 = logo.rows;
  logo_x3 = logo.cols, logo_y3 = 0;
  logo_x4 = logo.cols, logo_y4 = logo.rows;

  query_x1 = (m11*logo_x1+m12*logo_y1+m13);
  query_y1 = (m21*logo_x1+m22*logo_y1+m23);

  query_x2 = (m11*logo_x2+m12*logo_y2+m13);
  query_y2 = (m21*logo_x2+m22*logo_y2+m23);

  query_x3 = (m11*logo_x3+m12*logo_y3+m13);
  query_y3 = (m21*logo_x3+m22*logo_y3+m23);

  query_x4 = (m11*logo_x4+m12*logo_y4+m13);
  query_y4 = (m21*logo_x4+m22*logo_y4+m23);

  if (query_x1 < logo_x_threshlowerlimit
    || query_x2 < logo_x_threshlowerlimit
    || query_x3 < logo_x_threshlowerlimit
    || query_x4 < logo_x_threshlowerlimit) {
    return 0;
  }

  if (query_x1 > logo_x_threshupperlimit
    || query_x2 > logo_x_threshupperlimit
    || query_x3 > logo_x_threshupperlimit
    || query_x4 > logo_x_threshupperlimit) {
    return 0;
  }

  if (query_y1 < logo_y_threshlowerlimit
    || query_y2 < logo_y_threshlowerlimit
    || query_y3 < logo_y_threshlowerlimit
    || query_y4 < logo_y_threshlowerlimit) {
    return 0;
  }

  if (query_y1 > logo_y_threshupperlimit
    || query_y2 > logo_y_threshupperlimit
    || query_y3 > logo_y_threshupperlimit
    || query_y4 > logo_y_threshupperlimit) {
    return 0;
  }
  double param11, param12, param21, param22;

  double width_logo = 500;

  vector<double> params(4, 0);

  SolveRot(matrix_affine, &params);
  param11 = params[0];
  param12 = params[1];
  param21 = params[2];
  param22 = params[3];
  if (abs(param11) >= 1.5 || abs(param22) >= 1.5) {
  // if (abs(M11) >= 2 || abs(M22) >= 2){
    return 0;
  }
  if (abs(param11) < 0.1 || abs(param22) < 0.1) {
    return 0;
  }

  if (abs(param12) > 0.15 || abs(param21) > 0.15) {
    return 0;
  }

  double asp = abs(param11/param22);

  if (asp >= 1.5 || asp <= 0.6) {
    return 0;
  }
  if (m13 < width_logo*(-0.5) || m13 > width_logo*1.5) {
    return 0;
  }
  if (m23 < width_logo*(-0.5) || m23 > width_logo*1.5) {
    return 0;
  }
  return 1;
}

double LogoDetection::SolveRot(
  const  vector<vector<double> > &matrix_affine,
  vector<double> *matrix_out) {
  double m_ori11, m_ori12, m_ori21, m_ori22;
  double m11, m12, m21, m22;
  m11 = matrix_affine[0][0];
  m12 = matrix_affine[0][1];
  m21 = matrix_affine[1][0];
  m22 = matrix_affine[1][1];

  double b2;
  // double b1;
  // b1 = -m21/m22;
  b2 = m12/m11;
  double a = atan(b2);
  double cosa = cos(a);
  double sina = sin(a);

  m_ori11 = m11*cosa+m12*sina;
  m_ori12 = -m11*sina+m12*cosa;
  m_ori21 = m21*cosa+m22*sina;
  m_ori22 = -m21*sina+m22*cosa;

  double angle = static_cast<double>(a*180./kpi_);

  if (m_ori11 < 0) {
    m_ori11 = (-1) * m_ori11;
    m_ori12 = (-1) * m_ori12;
    m_ori21 = (-1) * m_ori21;
    m_ori22 = (-1) * m_ori22;
    angle = angle+180;
  }
  (*matrix_out)[0] = m_ori11;
  (*matrix_out)[1] = m_ori12;
  (*matrix_out)[2] = m_ori21;
  (*matrix_out)[3] = m_ori22;
  return angle;
}

int LogoDetection::InitialAffineMatchIndex() {
  // int maxAffineMatchindex = 10000;
  int maxkeypointtriple = 50;
  int maxindex_cnt = maxkeypointtriple * (maxkeypointtriple - 1)
    * (maxkeypointtriple -2) / 6;
  int maxsum_index = 200;

  for (int indexcnt =0, sumindex_cnt = 3;
       indexcnt < maxindex_cnt && sumindex_cnt < maxsum_index;
       sumindex_cnt ++) {
    for (int i=0; i < maxkeypointtriple; i++) {
      for (int j = i+1; j < maxkeypointtriple; j++) {
        for (int k=j+1; k < maxkeypointtriple; k++) {
          int cursum_index = i + j + k;
          if (cursum_index == sumindex_cnt) {
            affine_index_list_.push_back(vector<int>(0, 0));
            affine_index_list_.back().push_back(i);
            affine_index_list_.back().push_back(j);
            affine_index_list_.back().push_back(k);
            indexcnt++;
          }
        }
      }
    }
  }
  return 1;
}

double LogoDetection::Match2Block(
    const Mat &logoimg,
    const Mat &queryimg,
    const vector<Mat> &logomask,
    double tot_ratio) {
  double match_ratio = 0;
  // cout << "Match Flag1" << endl;
  // cout << logoimg.size() << endl;
  // cout << queryimg.size() << endl;
  if (logoimg.rows != queryimg.rows || logoimg.cols != queryimg.cols) {
    // cout << "logoimg.size()" << logoimg.size() << endl;
    // cout << " queryimg.size()" <<  queryimg.size() << endl;
    return match_ratio;
  }
  // cout << "Match Flag3" << endl;
  if (logoimg.channels() != 1 || queryimg.channels() != 1) {
    // cout << "Match Flag3" << endl;
    return match_ratio;
  }
  // cout << "Match Flag4" << endl;
  if (logoimg.type() != queryimg.type()) {
    // cout << "Match Flag4" << endl;
    return match_ratio;
  }
  // cout << "Match Flag5" << endl;
  // if(logoimg.type() != CV_32F){
  //    return match_ratio;
  // }
  // cout << "Match Flag2" << endl;
  int size = model_cover_size_;
  int range = 2;

  double std_thresh = model_cover_stdthresh_;
  int count_texture = 0;
  int count_match = 0;

  // double match_thresh = 0.8;
  double match_thresh = 0.7;
//  double match_thresh = -0.03 * (2 - 1/tot_ratio) * (2 - 1/tot_ratio)
//                        + 0.74;
//  match_thresh = min(0.7, match_thresh);

  Mat result, block, roi;
  cv::Scalar mean0, std0;

  // int max_iter = 2;
  int min_count_texture = model_cover_mincounttexture_;
  double std_thresh_ratio = model_cover_threshratio_;
  double maxvalue, minvalue;
  for (int iter = 0; iter < 1; iter++) {
    // for(int iter = 0; iter < max_model_coveriter_; iter ++ ){
    if (count_texture > min_count_texture) {
      break;
    }
    // cout << logomask[iter] << endl;
    for (int i = 0; i < logoimg.rows - size; i = i + size) {
      for (int j = 0; j < logoimg.cols - size; j = j + size) {
        int x1 = i - range;
        int y1 = j - range;
        int x2 = i + size + range;
        int y2 = j + size + range;

        if (x1 < 0) {
          x1 = 0;
        }
        if (y1 < 0) {
          y1 = 0;
        }
        if (x2 >= logoimg.rows) {
          x2 = logoimg.rows - 1;
        }
        if (y2 >= logoimg.cols) {
          y2 = logoimg.cols - 1;
        }
        block = logoimg(Range(i, i + size), Range(j, j + size));
        // meanStdDev(block, noArray(), std0);
        // if(std0[0] < std_thresh){
        int row_index = i/size;
        int col_index = j/size;
        if (logomask[0].ptr<uchar>(row_index)[col_index] == 0) {
          continue;
        } else {
          count_texture++;
        }
        roi = queryimg(Range(x1, x2), Range(y1, y2));
        matchTemplate(roi, block, result, CV_TM_CCOEFF_NORMED);
        minMaxLoc(result, &minvalue, &maxvalue, NULL, NULL);

        if (maxvalue >= match_thresh) {
          count_match++;
        }
      }
    }
    std_thresh = std_thresh * std_thresh_ratio;
  }
  if (count_texture > 0) {
    match_ratio = (static_cast<double>(count_match))
      /(static_cast<double>(count_texture));
  } else {
    match_ratio = 0;
  }
  // cout <<"count_texture" << count_texture<<endl;
  // cout <<"count_match" << count_match <<endl;
  return match_ratio;
}

int LogoDetection::Makelogocover(const Mat &logo,
                                 LogoFeature *logofeature_info) {
  int x, y;
  vector<FeaturePointInfo>  middle_logofeature;
  int count_cover = 0;
  for (int keypoint_cnt = 0;
       keypoint_cnt < static_cast<int>(
           logofeature_info->keypoints_logo_.size());
       keypoint_cnt++) {
    x = static_cast<int>(logofeature_info->
      keypoints_logo_[keypoint_cnt].pt.x);
    y = static_cast<int>(logofeature_info->
      keypoints_logo_[keypoint_cnt].pt.y);
    int r_size = static_cast<int>(logofeature_info->
      keypoints_logo_[keypoint_cnt].size * siftcover_rate_);
    int left_x = x - r_size;
    int left_y = y - r_size;
    int right_x = x + r_size;
    int right_y = y + r_size;
    if (left_x < 0) {
      left_x = 0;
    }
    if (left_y < 0) {
      left_y = 0;
    }
    if (right_x > logo.cols - 1) {
      right_x = logo.cols - 1;
    }
    if (right_y > logo.rows - 1) {
      right_y = logo.rows - 1;
    }
    for (int col_cnt = left_x; col_cnt < right_x; col_cnt ++) {
      for (int row_cnt = left_y; row_cnt < right_y; row_cnt ++) {
        count_cover++;
        FeaturePointInfo curfeaturepoint;
        curfeaturepoint.x_ = col_cnt;
        curfeaturepoint.y_ = row_cnt;
        curfeaturepoint.value_ =
          logo.ptr<uchar>(row_cnt)[col_cnt];
        middle_logofeature.push_back(curfeaturepoint);
      }
    }
  }
  double logo_v_maen = 0.0;
  double interval_cnt = count_cover/sum_cover_;
  if (interval_cnt < 1) {
    interval_cnt = 1;
  }
  for (int i_cnt=0; i_cnt * interval_cnt < count_cover; i_cnt++) {
    int index = interval_cnt * i_cnt;
    logo_v_maen += middle_logofeature[index].value_;
    logofeature_info->feature_point_list_
      .push_back(middle_logofeature[index]);
  }
  logo_v_maen = logo_v_maen/logofeature_info->feature_point_list_.size();
  logofeature_info->feature_point_valuemean_ = logo_v_maen;
  return 1;
}

int LogoDetection::CheckConfName(
    string logo_name,
    string brand_name) {
  if (logo_conf_list_.find(logo_name) != logo_conf_list_.end()) {
    return 0;
  }
  return 1;
}
int LogoDetection::CheckConfParam(
    double corr_thresh,
    double cover_ratio_thresh) {
  if (corr_thresh <0 || corr_thresh > 1) {
    return 0;
  }
  if (cover_ratio_thresh < 0 || cover_ratio_thresh > 1) {
    return 0;
  }
  return 1;
}
double LogoDetection::SolveRotSimple
    (const vector<vector<double> > &matrix_affine) {
  double M11, M12, M21, M22;
  double m11, m12, m21, m22;
  m11 = matrix_affine[0][0];
  m12 = matrix_affine[0][1];
  m21 = matrix_affine[1][0];
  m22 = matrix_affine[1][1];

  double b1, b2;
  b1 = -m21 / m22;
  b2 = m12 / m11;
  double a = atan(b2);
  double cosa = cos(a);
  double sina = sin(a);

  M11 = m11 * cosa + m12 * sina;
  M12 = -m11 * sina + m12 * cosa;
  M21 = m21 * cosa + m22 * sina;
  M22 = -m21 * sina + m22 * cosa;

  double angle = (a*180/kpi_);

  if (M11 < 0) {
    M11 = (-1)*M11;
    M12 = (-1)*M12;
    M21 = (-1)*M21;
    M22 = (-1)*M22;
    angle = angle + 180;
  }
  return angle;
}
void LogoDetection::EdgeOri(
    const vector<Point2f> &edge_points,
    const vector<double> &descriptor_oris,
    vector<double> *edge_oris) {
  double x1 = edge_points[0].x, x2 = edge_points[1].x;
  double y1 = edge_points[0].y, y2 = edge_points[1].y;
  // double d12 = sqrt((y2 - y1)*(y2 - y1) + (x2 - x1)*(x2 - x1));
  double anv21;
  if (abs(x2 - x1) > 1e-6) {
    anv21 = atan((y2 - y1) / (x2 - x1)) * 180.0 / kpi_;
  } else {
    return;
  }
  anv21 = anv21 + ((x2 - x1) < 0 ? 180.0 : 0);

  double ori1 = descriptor_oris[0];
  double ori2 = descriptor_oris[1];
  if (ori1 >= 270 && ori1 <= 360)
    ori1 = ori1 - 360;
  if (ori2 >= 270 && ori2 <= 360)
    ori2 = ori2 - 360;
  double delta1 = ori1 - anv21;
  if (delta1 < 0)
    delta1 = delta1 + 360.0;
  double delta2 = ori2 - anv21;
  if (delta2 < 0)
    delta2 = delta2 + 360.0;
  (*edge_oris)[0] = delta1;
  (*edge_oris)[1] = delta2;
  return;
}

double LogoDetection::EdgeOriInterDiffSum(
    const vector<double> &left,
    const vector<double> &right) {
  double tmp[2] = {0.0};
  for (int i = 0; i < 2; ++i) {
    tmp[i] = left[i] - right[i];
    if (tmp[i] > 180)
      tmp[i] = tmp[i] - 360;
    else if (tmp[i] < -180)
      tmp[i] = tmp[i] + 360;
    tmp[i] = abs(tmp[i]);
  }
  return tmp[0] + tmp[1];
}

double LogoDetection::EdgeOriIntraDiffStd(
    const vector<double> &left,
    const vector<double> &right) {
  double deltaL, deltaR;
  deltaL = left[0] - left[1];
  if (deltaL > 180)
    deltaL = deltaL - 360;
  else if (deltaL < -180)
    deltaL = deltaL + 360;
  deltaR = right[0] - right[1];

  if (deltaR > 180)
    deltaR = deltaR - 360;
  else if (deltaR < -180)
    deltaR = deltaR + 360;

  double delta = abs(deltaL - deltaR);
  return delta;
}
/* function: TriangleAngleOri
 * triangle_angles_oris[0 - 2] represents triangle angles
 * have values range in [0, 360]
 * triangle_angles_oris[3 - 5] represents triangle oris
 * have values range in [0, 360]
 */
bool LogoDetection::TriangleAngleOri(
    const vector<Point2f> &triangle_points,
    const vector<double> &descriptor_oris,
    vector<double> *triangle_angles_oris) {
  double x1 = triangle_points[0].x;
  double x2 = triangle_points[1].x;
  double x3 = triangle_points[2].x;
  double y1 = triangle_points[0].y;
  double y2 = triangle_points[1].y;
  double y3 = triangle_points[2].y;
// printf("x1 = %f, x2 = %f, x3 = %f\n", x1, x2, x3);
// printf("y1 = %f, y2 = %f, y3 = %f\n", y1, y2, y3);
  double ori1 = descriptor_oris[0];
  double ori2 = descriptor_oris[1];
  double ori3 = descriptor_oris[2];
// printf("ori1 = %f, ori2 = %f, ori3 = %f\n", ori1, ori2, ori3
  if (ori1 >= 270 && ori1 <= 360)
    ori1 = ori1 - 360;
  if (ori2 >= 270 && ori2 <= 360)
    ori2 = ori2 - 360;
  if (ori3 >= 270 && ori3 <= 360)
    ori3 = ori3 - 360;
  double anv21, anv12, anv32, anv23, anv13, anv31;
  double anv312, anv123, anv231;
  double delta1, delta2, delta3;
  if (abs(x2 - x1) > 1e-6) {
    anv21 = atan((y2 - y1) / (x2 - x1)) * 180.0 / kpi_;
    anv12 = anv21;
  } else {
    return false;
  }
  if (abs(x3 - x2) > 1e-6) {
    anv32 = atan((y3 - y2) / (x3 - x2)) * 180.0 / kpi_;
    anv23 = anv32;
  } else {
    return false;
  }
  if (abs(x1 - x3) > 1e-6) {
    anv13 = atan((y1 - y3) / (x1 - x3)) * 180.0 / kpi_;
    anv31 = anv13;
  } else {
    return false;
  }
  anv21 = anv21 + ((x2 - x1) < 0 ? 180.0 : 0);
  anv12 = anv12 + ((x2 - x1) > 0 ? 180.0 : 0);
  anv32 = anv32 + ((x3 - x2) < 0 ? 180.0 : 0);
  anv23 = anv23 + ((x3 - x2) > 0 ? 180.0 : 0);
  anv13 = anv13 + ((x1 - x3) < 0 ? 180.0 : 0);
  anv31 = anv31 + ((x1 - x3) > 0 ? 180.0 : 0);

  anv312 = anv21 - anv31;
  if (anv312 < 0)  anv312 = anv312 + 360.0;
  anv123 = anv32 - anv12;
  if (anv123 < 0)  anv123 = anv123 + 360.0;
  anv231 = anv13 - anv23;
  if (anv231 < 0)  anv231 = anv231 + 360.0;
  delta1 = ori1 - anv31;
  if (delta1 < 0)  delta1 = delta1 + 360.0;
  delta2 = ori2 - anv12;
  if (delta2 < 0)  delta2 = delta2 + 360.0;
  delta3 = ori3 - anv23;
  if (delta3 < 0)  delta3 = delta3 + 360.0;

  (*triangle_angles_oris)[0] = anv312;
  (*triangle_angles_oris)[1] = anv123;
  (*triangle_angles_oris)[2] = anv231;
  (*triangle_angles_oris)[3] = delta1;
  (*triangle_angles_oris)[4] = delta2;
  (*triangle_angles_oris)[5] = delta3;
  return true;
}

double LogoDetection::TriangleAngleInterDiffSum(
    const vector<double> &left, const vector<double> &right) {
  vector <double> tmp(6, 0.0f);
  for (int i = 0; i < 6; ++i) {
    tmp[i] = left[i] - right[i];
    if (tmp[i] > 180)
      tmp[i] = tmp[i] - 360;
    else if (tmp[i] < -180)
      tmp[i] = tmp[i] + 360;
    tmp[i] = abs(tmp[i]);
  }
  sort(tmp.begin(), tmp.begin() + 3);
//  sort(tmp.begin() + 3, tmp.end());
  return tmp[0] + tmp[1];
}
double LogoDetection::TriangleOriInterDiffStd(
    const vector<double> &left, const vector<double> &right) {
  vector <double> tmp(6, 0.0f);
  double sum = 0.0f;
  for (int i = 3; i < 6; ++i) {
      tmp[i] = left[i] - right[i];
      if (tmp[i] > 180)
        tmp[i] = tmp[i] - 360;
      else if (tmp[i] < -180)
        tmp[i] = tmp[i] + 360;
      sum += tmp[i];
  }
  double avg = sum / 3;
  double var = 0.0f;
  var = sqrt(((tmp[3] - avg) * (tmp[3] - avg) +
              (tmp[4] - avg) * (tmp[4] - avg) +
              (tmp[5] - avg) * (tmp[5] - avg)) / 3);
  return var;
}

int LogoDetection::NodeFind(
    const int query_idx, vector <int> *node_idx) {
  if (query_idx == (*node_idx)[query_idx]) {
    return query_idx;
  } else {
    (*node_idx)[query_idx] = NodeFind((*node_idx)[query_idx], node_idx);
    return (*node_idx)[query_idx];
  }
}

void LogoDetection::NodeUnion(
    const int idx1, const int idx2, vector <int> *node_idx) {
  int act_idx1 = NodeFind(idx1, node_idx);
  int act_idx2 = NodeFind(idx2, node_idx);
  if (act_idx1 != act_idx2)
    (*node_idx)[act_idx1] = act_idx2;
}

void LogoDetection::TriangleEdgeLen(
    const vector<Point2f> &triangle_points,
    vector<double> *triangle_edge_lens) {
  (*triangle_edge_lens)[0] = sqrt(
    (triangle_points[0].x - triangle_points[1].x)*
    (triangle_points[0].x - triangle_points[1].x) +
    (triangle_points[0].y - triangle_points[1].y)*
    (triangle_points[0].y - triangle_points[1].y));
    (*triangle_edge_lens)[1] = sqrt(
    (triangle_points[1].x - triangle_points[2].x)*
    (triangle_points[1].x - triangle_points[2].x) +
    (triangle_points[1].y - triangle_points[2].y)*
    (triangle_points[1].y - triangle_points[2].y));
    (*triangle_edge_lens)[2] = sqrt(
    (triangle_points[0].x - triangle_points[2].x)*
    (triangle_points[0].x - triangle_points[2].x) +
    (triangle_points[0].y - triangle_points[2].y)*
    (triangle_points[0].y - triangle_points[2].y));
}

int LogoDetection::BinarySearchX(
    const vector<ImgKeyPoint> &img_key_points,
    const int begin,
    const int end,
    const double val) {
  int mid, left = begin, right = end;
  while (left <= right) {
    mid = left + (right - left) / 2;
    if (img_key_points[mid].key_point_.pt.x >= val)
      right = mid - 1;
    else
      left = mid + 1;
  }
  return left;
}
int LogoDetection::BinarySearchY(
    const vector<ImgKeyPoint> &img_key_points,
    const int begin,
    const int end,
    const double val) {
  int mid, left = begin, right = end;
  while (left <= right) {
    mid = left + (right - left) / 2;
    if (img_key_points[mid].key_point_.pt.y >= val)
      right = mid - 1;
    else
      left = mid + 1;
  }
  return left;
}
int LogoDetection::SolveSimi(
    const vector<Point2f> &matchlogo_points,
    const vector<Point2f> &matchquery_points,
    vector<vector<double> > *matrix_affine) {
  double x1, x2, y1, y2, x1b, x2b, y1b, y2b;
  double m11, m12, m13, m23;
  x1 = matchlogo_points[0].x;
  y1 = matchlogo_points[0].y;
  x2 = matchlogo_points[1].x;
  y2 = matchlogo_points[1].y;
  x1b = matchquery_points[0].x;
  y1b = matchquery_points[0].y;
  x2b = matchquery_points[1].x;
  y2b = matchquery_points[1].y;
  double b = (x1*x1 - 2*x1*x2 + x2*x2 + y1*y1 - 2*y1*y2 + y2*y2);
  if (b == 0)     return 0;
  m11 = (x1*x1b - x1*x2b - x2*x1b + x2*x2b +
         y1*y1b - y1*y2b - y2*y1b + y2*y2b) / b;
  m12 = -(x1*y1b - x1b*y1 - x1*y2b - x2*y1b +
         x1b*y2 + x2b*y1 + x2*y2b - x2b*y2) / b;
  m13 = (x1*x1*x2b + x2*x2*x1b + x1b*y2*y2 +
         x2b*y1*y1 - x1*x2*x1b - x1*x2*x2b +
         x1*y2*y1b - x2*y1*y1b - x1b*y1*y2 -
         x1*y2*y2b + x2*y1*y2b - x2b*y1*y2) / b;
  m23 = (x1*x1*y2b + x2*x2*y1b + y1*y1*y2b +
         y2*y2*y1b - x1*x2*y1b - x1*x1b*y2 +
         x2*x1b*y1 - x1*x2*y2b + x1*x2b*y2 -
         x2*x2b*y1 - y1*y2*y1b - y1*y2*y2b) / b;
  (*matrix_affine)[0][0] = m11;
  (*matrix_affine)[0][1] = m12;
  (*matrix_affine)[0][2] = m13;
  (*matrix_affine)[1][0] = -m12;
  (*matrix_affine)[1][1] = m11;
  (*matrix_affine)[1][2] = m23;
  return 1;
}
int LogoDetection::SolveMultiAffine(
    const vector<Point2f> &matchlogo_points,
    const vector<Point2f> &matchquery_points,
    vector<vector<double> > *matrix_affine) {
  int pt_len = matchlogo_points.size();
  Mat Db = Mat::zeros(pt_len, 2, CV_64F);
  Mat D = Mat::zeros(pt_len, 3, CV_64F);
  Mat M = Mat::zeros(3, 2, CV_64F);
  for (int i = 0; i < pt_len; ++i) {
    Db.ptr<double>(i)[0] = matchquery_points[i].x;
    Db.ptr<double>(i)[1] = matchquery_points[i].y;
    D.ptr<double>(i)[0] = matchlogo_points[i].x;
    D.ptr<double>(i)[1] = matchlogo_points[i].y;
    D.ptr<double>(i)[2] = 1.0;
  }
  solve(D, Db, M, DECOMP_SVD);
  (*matrix_affine)[0][0] = M.ptr<double>(0)[0];
  (*matrix_affine)[0][1] = M.ptr<double>(1)[0];
  (*matrix_affine)[0][2] = M.ptr<double>(2)[0];
  (*matrix_affine)[1][0] = M.ptr<double>(0)[1];
  (*matrix_affine)[1][1] = M.ptr<double>(1)[1];
  (*matrix_affine)[1][2] = M.ptr<double>(2)[1];
  return 1;
}

void LogoDetection::MySwap(
    Point2f *a, Point2f *b) {
  Point2f tmp = *a;
  *a = *b;
  *b = tmp;
  return;
}

void LogoDetection::CutTriangle(
    bool logo_valid,
    bool query_valid,
    vector<Point2f> *matchlogo_points,
    vector<Point2f> *matchquery_points) {
  if (logo_valid == 0) {
    if (abs((*matchlogo_points)[0].x - (*matchlogo_points)[1].x) < 1e-6) {
      MySwap(&((*matchlogo_points)[0]), &((*matchlogo_points)[2]));
      MySwap(&((*matchquery_points)[0]), &((*matchquery_points)[2]));
    }
  } else if (query_valid == 0) {
    if (abs((*matchquery_points)[0].x - (*matchquery_points)[1].x) < 1e-6) {
      MySwap(&((*matchlogo_points)[0]), &((*matchlogo_points)[2]));
      MySwap(&((*matchquery_points)[0]), &((*matchquery_points)[2]));
    }
  }
  return;
}

void LogoDetection::CutTrianglePointsVerti(
    const vector<double> &trilogo_edgelens,
    const vector<double> &triquery_edgelens,
    vector<Point2f> *matchlogo_points,
    vector<Point2f> *matchquery_points) {
  if (trilogo_edgelens[1] > trilogo_edgelens[0]
      && trilogo_edgelens[1] > trilogo_edgelens[2]) {
    MySwap(&((*matchlogo_points)[0]), &((*matchlogo_points)[2]));
    MySwap(&((*matchquery_points)[0]), &((*matchquery_points)[2]));
  } else if (trilogo_edgelens[2] > trilogo_edgelens[0]
             && trilogo_edgelens[2] > trilogo_edgelens[1]) {
    MySwap(&((*matchlogo_points)[1]), &((*matchlogo_points)[2]));
    MySwap(&((*matchquery_points)[1]), &((*matchquery_points)[2]));
  }
  return;
}

double LogoDetection::EdgeLen(const vector<Point2f> &edge_points) {
  return sqrt((edge_points[0].x - edge_points[1].x)*
              (edge_points[0].x - edge_points[1].x) +
              (edge_points[0].y - edge_points[1].y)*
              (edge_points[0].y - edge_points[1].y));
}
void LogoDetection::RootSift(Mat *descriptors) {
  int trow = (*descriptors).rows;
  int tcol = (*descriptors).cols;
  (*descriptors).convertTo((*descriptors), CV_32FC1);
  CvMat cvsingle;
  Mat single;
  for (int cnt = 0; cnt < trow; ++cnt) {
    single = (*descriptors)(Range(cnt, cnt + 1), Range(0, tcol));
    cvsingle = single;
    cvNormalize(&cvsingle, &cvsingle, 1, 0, CV_L1);
    for (int j = 0; j < tcol; ++j) {
      single.at<float>(0, j) = sqrt(single.at<float>(0, j));
    }
    cvNormalize(&cvsingle, &cvsingle, 1, 0, CV_L2);
    single = single * 2 * 255;
  }
  return;
}

string LogoDetection::LogoRst2Json(vector<LogoDetResult> multiredet,
    Mat queryimg) {
  string strres;
  Document document;
  document.SetObject();
  Document::AllocatorType& allocator = document.GetAllocator();
  Value ret(kObjectType);

  try {
    int queryimg_width = queryimg.cols;
    int queryimg_height = queryimg.rows;
    Value img_meta_info(kObjectType);
    img_meta_info.AddMember("width", queryimg_width, allocator);
    img_meta_info.AddMember("height", queryimg_height, allocator);
    ret.AddMember("metainfo", img_meta_info, allocator);

    LogoDetResult redet = multiredet[0];
    string msg = redet.msg_;

    if (redet.status_ == 1) {
      Value logoinfo(kObjectType);
      Value logoresults(kArrayType);
      for (int i_cnt = 0; i_cnt < static_cast<int>(multiredet.size());
        i_cnt ++) {
        Value logooneresult(kObjectType);
        Value logoloc(kArrayType);
        LogoDetResult tmpredet = multiredet[i_cnt];

        string logoname = tmpredet.metaconf_.logo_name_;
        string brandname = tmpredet.metaconf_.brand_name_;
        string brandid = tmpredet.metaconf_.brand_id_;
        string logoid = tmpredet.metaconf_.logo_id_;
        double coveragerate = tmpredet.coveragerate_;

        int x_topleft = tmpredet.topleft_x_;
        int y_topleft = tmpredet.topleft_y_;
        int x_topright = tmpredet.topright_x_;
        int y_topright = tmpredet.topright_y_;
        int x_bottomleft = tmpredet.bottomleft_x_;
        int y_bottomleft = tmpredet.bottomleft_y_;
        int x_bottomright = tmpredet.bottomright_x_;
        int y_bottomright = tmpredet.bottomright_y_;

        logoloc.PushBack(x_topleft, allocator);
        logoloc.PushBack(y_topleft, allocator);
        logoloc.PushBack(x_topright, allocator);
        logoloc.PushBack(y_topright, allocator);
        logoloc.PushBack(x_bottomright, allocator);
        logoloc.PushBack(y_bottomright, allocator);
        logoloc.PushBack(x_bottomleft, allocator);
        logoloc.PushBack(y_bottomleft, allocator);

        logooneresult.AddMember("brand",
            Value(brandname.c_str(), allocator).Move(), allocator);
        logooneresult.AddMember("oldname",
            Value(logoname.c_str(), allocator).Move(), allocator);
        logooneresult.AddMember("brandid",
            Value(brandid.c_str(), allocator).Move(), allocator);
        logooneresult.AddMember("logoid",
            Value(logoid.c_str(), allocator).Move(), allocator);
        logooneresult.AddMember("loc", logoloc, allocator);
        logooneresult.AddMember("score", coveragerate, allocator);
        logoresults.PushBack(logooneresult, allocator);
      }
      ret.AddMember("results", logoresults, allocator);
      ret.AddMember("algodate",
        Value(algodate_.c_str(), allocator).Move(), allocator);
    } else if (redet.status_ == 0) {
      Value exception(kArrayType);
      Value logoinfo(kObjectType);
      Value emptyresult(kArrayType);

      ret.AddMember("results", emptyresult, allocator);
      ret.AddMember("algodate",
        Value(algodate_.c_str(), allocator).Move(), allocator);
    } else {
      // Value exception(kArrayType);
      Value logoinfo(kObjectType);
      Value emptyresult(kArrayType);

      // exception.PushBack(Value(msg.c_str(), allocator).Move(), allocator);

      ret.AddMember("exception",
          Value(msg.c_str(), allocator).Move(), allocator);
      // ret.AddMember("results", emptyresult, allocator);
      ret.AddMember("algodate",
        Value(algodate_.c_str(), allocator).Move(), allocator);
      // ret.AddMember("logo", logoinfo, allocator);
    }
    StringBuffer buffer;
    Writer<StringBuffer> writer(buffer);
    ret.Accept(writer);
    strres = buffer.GetString();
    SIMPLE_LOG_V1("strres: %s", strres.c_str());
  } catch (...) {
    // Value ret(kObjectType);
    SIMPLE_LOG_V1("Process exception!\n");
    Value exception(kArrayType);
    Value logoinfo(kObjectType);
    Value emptyresult(kArrayType);

    string hfsmsg = string("HSF Process exception");
    // exception.PushBack(1, allocator);
    // exception.PushBack("aaaa", allocator);
    exception.PushBack(Value(hfsmsg.c_str(), allocator).Move(), allocator);
    // exception.PushBack(Value(msg.c_str(), allocator).Move(), allocator);

    // logoinfo.AddMember("exception", exception, allocator);
    // logoinfo.AddMember("results", emptyresult, allocator);
    ret.AddMember("exception", exception, allocator);
    // ret.AddMember("results", emptyresult, allocator);
    ret.AddMember("algodate", Value(algodate_.c_str(),
      allocator).Move(), allocator);
    // ret.AddMember("logo", logoinfo, allocator);

    StringBuffer buffer;
    Writer<StringBuffer> writer(buffer);
    ret.Accept(writer);
    strres = buffer.GetString();
  }
  return strres;
  return "";
}

void LogoDetection::CoutToPc(string outmsg) {
  cout << outmsg << endl;
}
